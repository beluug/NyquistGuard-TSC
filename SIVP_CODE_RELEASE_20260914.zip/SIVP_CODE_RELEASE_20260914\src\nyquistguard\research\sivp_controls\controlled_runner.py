"""Validation-only 2 x 2 ordinary/physical by nominal/multirate comparison."""

from __future__ import annotations

import argparse
from dataclasses import dataclass
from datetime import datetime, timezone
import hashlib
import json
import math
from pathlib import Path
import random
import shutil
import time
from typing import Any

import numpy as np
from sklearn.metrics import f1_score
import torch
from torch import nn
from torch.utils.data import DataLoader, TensorDataset
import yaml

from nyquistguard.data import SplitData, full_cache_path, resample_antialiased
from nyquistguard.experiments.pilot import _resolved_model_config
from nyquistguard.losses.filter_regularization import FilterBankRegularization
from nyquistguard.research.v5_dual_path import DualPathNyquistGuardTSC
from .models import MatchedOrdinaryDualPath, exact_parameter_match


@dataclass(frozen=True)
class DevelopmentDataset:
    dataset_id: str
    sampling_rate_hz: float
    class_names: tuple[str, ...]
    train: SplitData
    validation: SplitData


CELLS = (
    ("ordinary", "nominal"),
    ("ordinary", "multirate"),
    ("physical", "nominal"),
    ("physical", "multirate"),
)

# Numerical amendment for the formal validation run started under the parent
# protocol hash below.  The parent runner stopped immediately on any non-finite
# gradient, so a completed parent cell necessarily used zero overflow retries.
AMP_RETRY_AMENDMENT_ID = "amp_same_batch_rng_replay_v1"
AMP_RETRY_PARENT_PROTOCOL_HASHES = frozenset({
    "17b4017c2c275a8e7c46cc84e7725a89b8a6ae5593c2ee52080a1b9b02028a26",
})
AMP_MAX_RETRIES = 8
AMP_MIN_SCALE = 1.0

DOWNSTREAM_MODULES = (
    "encoder", "physical_summary", "spatial_projection", "spatial_encoder",
    "spatial_summary", "fusion_controller", "cross_path_residual", "fusion_norm",
    "classifier",
)


def _json(path: Path, value: object) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(
        json.dumps(value, indent=2, ensure_ascii=False, allow_nan=False), encoding="utf-8"
    )
    temporary.replace(path)


def _validate_config(config: dict) -> None:
    common = {
        "automatic_test_stage": False,
        "model_families": ["ordinary", "physical"],
        "training_regimes": ["nominal", "multirate"],
        "batch_size": 32,
        "learning_rate": 0.001,
        "weight_decay": 0.0001,
        "gradient_clip_norm": 1.0,
        "amp_initial_scale": 1024.0,
        "amp_growth_interval": 2000,
        "antialias_fir_taps": 31,
        "antialias_rolloff": 0.90,
        "multirate_uniform_min": 0.3,
        "multirate_uniform_max": 0.75,
        "validation_rates": [1.0, 0.9, 0.6, 0.4, 0.3],
        "selection_full_rate_weight": 0.5,
        "selection_mean_unseen_weight": 0.5,
        "physical_filter_regularization_weight": 0.01,
        "threads": 4,
    }
    specifications = {
        "sivp_decisive_controls_validation_v1": {
            "scope": "train_validation_only",
            "datasets": [
                "basicmotions_uea", "epilepsy_uea", "pamap2_uci", "mhealth_uci",
                "hapt_uci", "daily_sports_uci", "hydraulic_uci",
                "sleep_edfx_physionet", "eegmmi_physionet",
                "mitbih_arrhythmia_physionet",
            ],
            "seeds": [17, 42, 2026],
            "max_epochs": 45,
            "protocol_wide_extension_epochs": 60,
            "preflight_output": "reports/sivp_decisive_controls/preflight.json",
        },
        "sivp_decisive_controls_smoke_v1": {
            "scope": "train_validation_smoke_only",
            "datasets": ["basicmotions_uea", "pamap2_uci"],
            "seeds": [17],
            "max_epochs": 2,
            "protocol_wide_extension_epochs": 2,
            "preflight_output": "reports/sivp_decisive_controls/smoke_preflight.json",
        },
    }
    version = config.get("protocol_version")
    if version not in specifications:
        raise ValueError("unknown decisive-control protocol")
    expected = {**common, **specifications[version]}
    for key, value in expected.items():
        if config.get(key) != value:
            raise ValueError(f"decisive-control protocol changed: {key}")
    if len(set(config["datasets"])) != len(config["datasets"]):
        raise ValueError("decisive-control datasets must be unique")
    boundaries = config.get("scientific_boundaries", {})
    required_false = ("test_accessed", "cbe_enabled", "selective_head_enabled", "reliability_enabled")
    required_true = (
        "equal_forward_count", "equal_backward_count", "fixed_epoch_budget",
        "exact_active_parameter_match", "no_dummy_parameters",
    )
    if any(boundaries.get(key) is not False for key in required_false):
        raise ValueError("a disabled scientific boundary was changed")
    if any(boundaries.get(key) is not True for key in required_true):
        raise ValueError("a required scientific boundary was changed")
    if version.endswith("smoke_v1") and boundaries.get("inferential_use") is not False:
        raise ValueError("smoke results must not be used inferentially")


def load_development_cache(path: Path) -> DevelopmentDataset:
    """Materialize TRAIN/validation members only; TEST keys are never requested."""

    with np.load(path, allow_pickle=False) as payload:
        required = {
            "dataset_id", "sampling_rate_hz", "class_names",
            "train_x", "train_y", "train_ids",
            "validation_x", "validation_y", "validation_ids",
        }
        missing = sorted(required - set(payload.files))
        if missing:
            raise ValueError(f"development cache missing keys: {missing}")
        dataset_id = str(payload["dataset_id"].item())
        rate = float(payload["sampling_rate_hz"].item())
        classes = tuple(payload["class_names"].astype(str).tolist())
        train = SplitData(payload["train_x"], payload["train_y"], payload["train_ids"].astype(str))
        validation = SplitData(
            payload["validation_x"], payload["validation_y"], payload["validation_ids"].astype(str)
        )
    if not math.isfinite(rate) or rate <= 0 or len(classes) < 2:
        raise ValueError("invalid development metadata")
    if set(train.ids.tolist()) & set(validation.ids.tolist()):
        raise ValueError("TRAIN and validation IDs overlap")
    for name, split in (("train", train), ("validation", validation)):
        if (
            split.x.ndim != 3 or split.x.dtype != np.float32 or split.y.ndim != 1
            or split.ids.ndim != 1 or len(split.x) != len(split.y) or len(split.y) != len(split.ids)
            or not np.isfinite(split.x).all() or not np.issubdtype(split.y.dtype, np.integer)
        ):
            raise ValueError(f"invalid {name} arrays")
        if set(np.unique(split.y).tolist()) - set(range(len(classes))):
            raise ValueError(f"{name} labels outside class vocabulary")
    if set(np.unique(train.y).tolist()) != set(range(len(classes))):
        raise ValueError("TRAIN lacks a configured class")
    return DevelopmentDataset(dataset_id, rate, classes, train, validation)


def _fingerprint(data: DevelopmentDataset) -> str:
    digest = hashlib.sha256()
    digest.update(f"{data.dataset_id}:{data.sampling_rate_hz}:{data.class_names}".encode())
    for split_name in ("train", "validation"):
        split = getattr(data, split_name)
        for name in ("x", "y", "ids"):
            value = np.ascontiguousarray(getattr(split, name))
            digest.update(f"{split_name}:{name}:{value.dtype}:{value.shape}".encode())
            digest.update(value.tobytes())
    return digest.hexdigest()


def _seed(seed: int) -> None:
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)


def _state_hash(model: nn.Module, module_names: tuple[str, ...] | None = None) -> str:
    digest = hashlib.sha256()
    state_items = []
    if module_names is None:
        state_items = list(model.state_dict().items())
    else:
        for module_name in module_names:
            state_items.extend(
                (f"{module_name}.{name}", value)
                for name, value in getattr(model, module_name).state_dict().items()
            )
    for name, value in state_items:
        array = value.detach().cpu().contiguous().numpy()
        digest.update(f"{name}:{array.dtype}:{array.shape}".encode())
        digest.update(array.tobytes())
    return digest.hexdigest()


def _model(
    data: DevelopmentDataset,
    base_config: dict,
    family: str,
    seed: int,
    device: torch.device,
) -> nn.Module:
    _seed(seed)
    kwargs = _resolved_model_config(data, base_config, "no_selective_head")
    kwargs["use_selective_head"] = False
    cls = DualPathNyquistGuardTSC if family == "physical" else MatchedOrdinaryDualPath
    if family not in {"physical", "ordinary"}:
        raise ValueError("unknown model family")
    return cls(**kwargs, initial_gate_floor=0.5, spatial_channels=24).to(device)


def scheduled_ratio(config: dict, seed: int, epoch: int, batch_index: int) -> float:
    """Pure deterministic ratio schedule shared by both model families."""

    sequence = np.random.SeedSequence([int(seed), int(epoch), int(batch_index), 20260908])
    generator = np.random.default_rng(sequence)
    return float(generator.uniform(config["multirate_uniform_min"], config["multirate_uniform_max"]))


def _view(x: torch.Tensor, rate: float, ratio: float, config: dict) -> tuple[torch.Tensor, float]:
    values, actual_rate, _ = resample_antialiased(
        x,
        rate,
        ratio,
        taps=int(config["antialias_fir_taps"]),
        rolloff=float(config["antialias_rolloff"]),
    )
    return values, actual_rate


def _filter_regularizer(model: nn.Module, base_config: dict) -> FilterBankRegularization:
    objective = base_config["objective"]
    bank = model.filterbank
    return FilterBankRegularization(
        min_center_hz=bank.min_center_hz,
        max_center_hz=bank.max_center_hz,
        min_sigma_seconds=bank.min_sigma_seconds,
        max_sigma_seconds=bank.max_sigma_seconds,
        minimum_spacing_fraction=float(objective["regularization_minimum_spacing_fraction"]),
        spacing_weight=float(objective["regularization_spacing_weight"]),
        coverage_weight=float(objective["regularization_coverage_weight"]),
        bounds_weight=float(objective["regularization_bounds_weight"]),
        gate_degeneracy_weight=float(objective["regularization_gate_weight"]),
        minimum_gate_softness=float(objective["regularization_minimum_gate_softness"]),
    )


@torch.inference_mode()
def evaluate(
    model: nn.Module,
    data: DevelopmentDataset,
    config: dict,
    device: torch.device,
) -> dict:
    model.eval()
    per_rate = {}
    for ratio in config["validation_rates"]:
        probabilities = []
        for start in range(0, len(data.validation.y), config["batch_size"]):
            x = torch.from_numpy(data.validation.x[start : start + config["batch_size"]]).to(device)
            viewed, rate = _view(x, data.sampling_rate_hz, float(ratio), config)
            probabilities.append(model(viewed, rate)["logits"].float().softmax(-1).cpu().numpy())
        probs = np.concatenate(probabilities)
        prediction = probs.argmax(axis=1)
        per_rate[str(float(ratio))] = {
            "macro_f1": float(f1_score(
                data.validation.y, prediction, labels=np.arange(len(data.class_names)),
                average="macro", zero_division=0,
            )),
            "accuracy": float(np.mean(prediction == data.validation.y)),
            "prediction_class_count": int(len(np.unique(prediction))),
        }
    unseen = [per_rate[str(float(ratio))]["macro_f1"] for ratio in config["validation_rates"][1:]]
    full = per_rate["1.0"]["macro_f1"]
    mean_unseen = float(np.mean(unseen))
    score = (
        config["selection_full_rate_weight"] * full
        + config["selection_mean_unseen_weight"] * mean_unseen
    )
    return {
        "per_rate": per_rate,
        "full_rate_macro_f1": full,
        "mean_unseen_macro_f1": mean_unseen,
        "worst_unseen_macro_f1": float(min(unseen)),
        "selection_score": float(score),
    }


def _undertrained(history: list[dict], best_epoch: int, config: dict) -> dict:
    rule = config["undertraining"]
    reached_maximum = len(history) >= int(config["max_epochs"])
    best_in_final = best_epoch > len(history) - int(rule["best_epoch_in_final_n"])
    window = history[-int(rule["final_window_epochs"]):]
    relative_decrease = 0.0
    if len(window) == int(rule["final_window_epochs"]):
        first = float(np.mean([row["train_loss"] for row in window[:2]]))
        last = float(np.mean([row["train_loss"] for row in window[-2:]]))
        relative_decrease = (first - last) / max(abs(first), 1e-12)
    loss_still_decreasing = relative_decrease > float(rule["minimum_relative_loss_decrease"])
    flagged = reached_maximum and (best_in_final or loss_still_decreasing)
    return {
        "flagged": bool(flagged),
        "reached_maximum_epochs": reached_maximum,
        "best_epoch_in_final_window": bool(best_in_final),
        "final_loss_relative_decrease": relative_decrease,
        "loss_still_decreasing": bool(loss_still_decreasing),
        "allowed_remedy": (
            f"protocol_wide_extension_to_{config['protocol_wide_extension_epochs']}_epochs_before_any_TEST"
            if flagged else None
        ),
    }


def _capture_rng_state(device: torch.device) -> tuple[torch.Tensor, torch.Tensor | None]:
    return (
        torch.get_rng_state(),
        torch.cuda.get_rng_state(device) if device.type == "cuda" else None,
    )


def _restore_rng_state(
    device: torch.device, cpu_state: torch.Tensor, cuda_state: torch.Tensor | None
) -> None:
    torch.set_rng_state(cpu_state)
    if cuda_state is not None:
        torch.cuda.set_rng_state(cuda_state, device)


def _next_amp_scale(scale: float, attempt: int, device: torch.device) -> float | None:
    if device.type != "cuda" or attempt >= AMP_MAX_RETRIES or scale <= AMP_MIN_SCALE:
        return None
    return max(AMP_MIN_SCALE, scale / 2.0)


def train_cell(
    data: DevelopmentDataset,
    base_config: dict,
    config: dict,
    family: str,
    regime: str,
    seed: int,
    directory: Path,
    device: torch.device,
    protocol_hash: str,
) -> dict:
    if directory.exists():
        raise FileExistsError("decisive-control cells are immutable; use a new protocol run")
    directory.mkdir(parents=True)
    if device.type == "cuda":
        torch.cuda.reset_peak_memory_stats(device)
    model = _model(data, base_config, family, seed, device)
    initial_hash = _state_hash(model)
    downstream_initial_hash = _state_hash(model, DOWNSTREAM_MODULES)
    optimizer = torch.optim.AdamW(
        model.parameters(), lr=config["learning_rate"], weight_decay=config["weight_decay"]
    )
    scaler = torch.amp.GradScaler(
        "cuda",
        enabled=device.type == "cuda",
        init_scale=float(config["amp_initial_scale"]),
        growth_interval=int(config["amp_growth_interval"]),
    )
    filter_regularizer = _filter_regularizer(model, base_config) if family == "physical" else None
    training = TensorDataset(torch.from_numpy(data.train.x), torch.from_numpy(data.train.y).long())
    history = []
    best_score = -math.inf
    best_epoch = 0
    schedule_rows = []
    numerical_retries = []
    started = time.monotonic()
    for epoch in range(1, int(config["max_epochs"]) + 1):
        loader = DataLoader(
            training,
            batch_size=int(config["batch_size"]),
            shuffle=True,
            generator=torch.Generator().manual_seed(seed + epoch - 1),
            num_workers=0,
        )
        model.train()
        total_loss = 0.0
        total_ce = 0.0
        total_regularization = 0.0
        batches = 0
        for batch_index, (x_cpu, y_cpu) in enumerate(loader):
            x = x_cpu.to(device)
            targets = y_cpu.to(device)
            scheduled = scheduled_ratio(config, seed, epoch - 1, batch_index)
            applied_ratio = 1.0 if regime == "nominal" else scheduled
            high, high_rate = _view(x, data.sampling_rate_hz, 1.0, config)
            second, second_rate = _view(x, data.sampling_rate_hz, applied_ratio, config)
            cpu_rng_state, cuda_rng_state = _capture_rng_state(device)
            for attempt in range(AMP_MAX_RETRIES + 1):
                # Replaying the pre-forward RNG state keeps dropout masks and all
                # other stochastic forward choices identical across AMP retries.
                _restore_rng_state(device, cpu_rng_state, cuda_rng_state)
                optimizer.zero_grad(set_to_none=True)
                with torch.amp.autocast("cuda", dtype=torch.float16, enabled=device.type == "cuda"):
                    high_output = model(high, high_rate)
                    second_output = model(second, second_rate)
                    ce = 0.5 * (
                        nn.functional.cross_entropy(high_output["logits"], targets)
                        + nn.functional.cross_entropy(second_output["logits"], targets)
                    )
                    regularization = ce.new_zeros(())
                    if filter_regularizer is not None:
                        regularization = filter_regularizer(
                            model.filterbank.center_frequencies_hz,
                            model.filterbank.time_scales_seconds,
                            torch.cat((high_output["nyquist_gate"], second_output["nyquist_gate"]), dim=0),
                        )["total"]
                    loss = ce + config["physical_filter_regularization_weight"] * regularization
                if not torch.isfinite(loss):
                    raise FloatingPointError(
                        "non-finite decisive-control forward loss: "
                        f"dataset={data.dataset_id}, family={family}, regime={regime}, "
                        f"seed={seed}, epoch={epoch}, batch={batch_index}"
                    )
                scale_before = float(scaler.get_scale())
                scaler.scale(loss).backward()
                scaler.unscale_(optimizer)
                nonfinite_parameters = [
                    name for name, parameter in model.named_parameters()
                    if parameter.grad is not None and not torch.isfinite(parameter.grad).all()
                ]
                if not nonfinite_parameters:
                    nn.utils.clip_grad_norm_(
                        model.parameters(), config["gradient_clip_norm"], error_if_nonfinite=True
                    )
                    scaler.step(optimizer)
                    scaler.update()
                    break
                scale_after = _next_amp_scale(scale_before, attempt, device)
                if scale_after is None:
                    raise FloatingPointError(
                        "non-finite decisive-control gradient after AMP retries: "
                        f"dataset={data.dataset_id}, family={family}, regime={regime}, "
                        f"seed={seed}, epoch={epoch}, batch={batch_index}, "
                        f"attempt={attempt}, amp_scale={scale_before}, "
                        f"parameters={nonfinite_parameters[:8]}"
                    )
                event = {
                    "epoch": epoch,
                    "batch_index": batch_index,
                    "retry_number": attempt + 1,
                    "scale_before": scale_before,
                    "scale_after": scale_after,
                    "nonfinite_parameters": nonfinite_parameters[:8],
                }
                numerical_retries.append(event)
                print(
                    f"{data.dataset_id} {family}_{regime} seed{seed} AMP retry "
                    f"epoch {epoch} batch {batch_index}: {scale_before:g}->{scale_after:g}",
                    flush=True,
                )
                scaler.update(new_scale=scale_after)
            total_loss += float(loss.detach().cpu())
            total_ce += float(ce.detach().cpu())
            total_regularization += float(regularization.detach().cpu())
            batches += 1
            schedule_rows.append({
                "epoch": epoch,
                "batch_index": batch_index,
                "scheduled_ratio": scheduled,
                "applied_ratio": applied_ratio,
            })
        validation = evaluate(model, data, config, device)
        row = {
            "epoch": epoch,
            "train_loss": total_loss / batches,
            "cross_entropy": total_ce / batches,
            "filter_regularization": total_regularization / batches,
            "validation_selection_score": validation["selection_score"],
            "validation_full_rate_macro_f1": validation["full_rate_macro_f1"],
            "validation_mean_unseen_macro_f1": validation["mean_unseen_macro_f1"],
        }
        history.append(row)
        if validation["selection_score"] > best_score + 1e-12:
            best_score = validation["selection_score"]
            best_epoch = epoch
            torch.save(model.state_dict(), directory / "checkpoint_best.pt")
        torch.save({
            "model": model.state_dict(),
            "optimizer": optimizer.state_dict(),
            "scaler": scaler.state_dict(),
            "epoch": epoch,
            "best_score": best_score,
            "best_epoch": best_epoch,
            "protocol_hash": protocol_hash,
            "numerical_amendment_id": AMP_RETRY_AMENDMENT_ID,
            "numerical_retries": numerical_retries,
        }, directory / "checkpoint_last.pt")
        _json(directory / "history.json", {"history": history})
        print(
            f"{data.dataset_id} {family}_{regime} seed{seed} epoch {epoch}: "
            f"loss={row['train_loss']:.4f} val={row['validation_selection_score']:.4f}",
            flush=True,
        )
    model.load_state_dict(torch.load(directory / "checkpoint_best.pt", map_location=device, weights_only=True))
    validation = evaluate(model, data, config, device)
    schedule_hash = hashlib.sha256(json.dumps(schedule_rows, sort_keys=True).encode()).hexdigest()
    result = {
        "status": "completed",
        "protocol_hash": protocol_hash,
        "dataset_id": data.dataset_id,
        "family": family,
        "regime": regime,
        "seed": seed,
        "initial_state_hash": initial_hash,
        "downstream_initial_state_hash": downstream_initial_hash,
        "parameters": sum(p.numel() for p in model.parameters() if p.requires_grad),
        "schedule_hash": schedule_hash,
        "epochs_completed": len(history),
        "best_epoch": best_epoch,
        "undertraining": _undertrained(history, best_epoch, config),
        "numerical_amendment_id": AMP_RETRY_AMENDMENT_ID,
        "numerical_retry_count": len(numerical_retries),
        "numerical_retries": numerical_retries,
        "validation": validation,
        "history": history,
        "seconds": time.monotonic() - started,
        "peak_cuda_allocated_mib": (
            float(torch.cuda.max_memory_allocated(device) / (1024 ** 2))
            if device.type == "cuda" else 0.0
        ),
        "test_accessed": False,
    }
    _json(directory / "metrics.json", result)
    _json(directory / "schedule.json", {"schedule": schedule_rows, "schedule_hash": schedule_hash})
    return result


def _protocol_hash(root: Path, config_path: Path) -> str:
    digest = hashlib.sha256()
    for path in (
        config_path,
        root / "docs/SIVP_DECISIVE_CONTROLS_PROTOCOL.md",
        root / "scripts/run_sivp_decisive_controls.py",
        Path(__file__),
        Path(__file__).with_name("models.py"),
    ):
        digest.update(str(path.relative_to(root)).encode())
        digest.update(path.read_bytes())
    return digest.hexdigest()


def _resume_hash_is_compatible(stored_hash: object, current_hash: str) -> bool:
    """Accept the exact protocol or the one explicitly superseded by this amendment."""
    return stored_hash == current_hash or stored_hash in AMP_RETRY_PARENT_PROTOCOL_HASHES


def _completed_cell_hash_is_compatible(row: dict, current_hash: str) -> bool:
    stored_hash = row.get("protocol_hash")
    if stored_hash == current_hash:
        return True
    return (
        stored_hash in AMP_RETRY_PARENT_PROTOCOL_HASHES
        and int(row.get("numerical_retry_count", 0)) == 0
    )


def preflight(root: Path, config: dict, base_config: dict) -> dict:
    checks = {}
    for dataset_id in config["datasets"]:
        data = load_development_cache(full_cache_path(root, dataset_id))
        if data.dataset_id != dataset_id:
            raise ValueError("cache dataset identity mismatch")
        cpu = torch.device("cpu")
        physical = _model(data, base_config, "physical", config["seeds"][0], cpu)
        ordinary = _model(data, base_config, "ordinary", config["seeds"][0], cpu)
        match = exact_parameter_match(physical, ordinary)
        if not match["exact"] or match["dummy_parameters"] != 0:
            raise ValueError("ordinary and physical models are not exactly active-parameter matched")
        physical_downstream = _state_hash(physical, DOWNSTREAM_MODULES)
        ordinary_downstream = _state_hash(ordinary, DOWNSTREAM_MODULES)
        if physical_downstream != ordinary_downstream:
            raise ValueError("ordinary and physical downstream initializations differ")
        checks[dataset_id] = {
            "development_fingerprint": _fingerprint(data),
            "sampling_rate_hz": data.sampling_rate_hz,
            "classes": list(data.class_names),
            "train_shape": list(data.train.x.shape),
            "validation_shape": list(data.validation.x.shape),
            "train_class_counts": np.bincount(data.train.y, minlength=len(data.class_names)).tolist(),
            "validation_class_counts": np.bincount(data.validation.y, minlength=len(data.class_names)).tolist(),
            "parameter_match": match,
            "downstream_initial_state_hash": physical_downstream,
            "downstream_initialization_exact": True,
            "test_accessed": False,
        }
        del data, physical, ordinary
    return {"status": "passed", "datasets": checks, "test_accessed": False, "training_started": False}


def run(
    root: Path,
    config_path: Path,
    *,
    execute: bool = False,
    preflight_only: bool = False,
    device_name: str = "auto",
    resume_directory: Path | None = None,
) -> dict:
    root = root.resolve()
    config_path = config_path.resolve()
    config = yaml.safe_load(config_path.read_text(encoding="utf-8"))
    _validate_config(config)
    plan = {
        "protocol_version": config["protocol_version"],
        "scope": config["scope"],
        "datasets": config["datasets"],
        "seeds": config["seeds"],
        "cells": [f"{family}_{regime}" for family, regime in CELLS],
        "expected_training_cells": len(config["datasets"]) * len(config["seeds"]) * len(CELLS),
        "execution_requested": execute,
        "preflight_requested": preflight_only,
        "automatic_test_stage": False,
        "test_accessed": False,
        "resume_requested": resume_directory is not None,
    }
    if resume_directory is not None and (not execute or preflight_only):
        raise ValueError("resume requires --execute and cannot be combined with --preflight")
    if not execute and not preflight_only:
        return plan
    if execute and preflight_only:
        raise ValueError("choose preflight or execute")
    base_path = root / config["base_config"]
    base_config = yaml.safe_load(base_path.read_text(encoding="utf-8"))
    checked = preflight(root, config, base_config)
    plan["preflight"] = checked
    if preflight_only:
        preflight_path = (root / config["preflight_output"]).resolve()
        if root not in preflight_path.parents:
            raise ValueError("preflight output escapes project")
        _json(preflight_path, {
            **plan,
            "status": "passed",
            "training_started": False,
            "test_accessed": False,
        })
        plan["preflight_report"] = str(preflight_path)
        return plan

    protocol_hash = _protocol_hash(root, config_path)
    resume_parent_protocol_hash = None
    output_root = (root / config["output_root"]).resolve()
    if root not in output_root.parents:
        raise ValueError("output root escapes project")
    if resume_directory is None:
        stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S%fZ")
        directory = output_root / f"validation__{stamp}"
        directory.mkdir(parents=True, exist_ok=False)
        shutil.copy2(config_path, directory / "config_frozen.yaml")
    else:
        directory = resume_directory.resolve()
        if output_root not in directory.parents or not directory.is_dir():
            raise ValueError("resume directory is outside the configured output root or missing")
        frozen_config = directory / "config_frozen.yaml"
        if not frozen_config.is_file() or frozen_config.read_bytes() != config_path.read_bytes():
            raise ValueError("resume config does not match the frozen run config")
        prior_manifest = json.loads((directory / "manifest.json").read_text(encoding="utf-8"))
        resume_parent_protocol_hash = prior_manifest.get("protocol_hash")
        if not _resume_hash_is_compatible(resume_parent_protocol_hash, protocol_hash):
            raise ValueError("resume protocol hash mismatch")
        if prior_manifest.get("test_accessed") is not False:
            raise ValueError("resume rejected because TEST-access state is not false")
    _json(directory / "manifest.json", {
        **plan, "status": "running", "protocol_hash": protocol_hash,
        "resumed": resume_directory is not None,
        "numerical_amendment_id": AMP_RETRY_AMENDMENT_ID,
        "amendment_parent_protocol_hash": resume_parent_protocol_hash,
        "test_accessed": False,
    })
    torch.set_num_threads(config["threads"])
    device = torch.device(
        "cuda" if device_name == "auto" and torch.cuda.is_available()
        else "cpu" if device_name == "auto" else device_name
    )
    rows = []
    reused_cells = 0
    execution_started = time.monotonic()
    try:
        for dataset_id in config["datasets"]:
            data = load_development_cache(full_cache_path(root, dataset_id))
            if _fingerprint(data) != checked["datasets"][dataset_id]["development_fingerprint"]:
                raise ValueError("development cache changed after preflight")
            for seed in config["seeds"]:
                paired = {}
                for family, regime in CELLS:
                    key = f"{family}_{regime}"
                    cell_directory = directory / f"{dataset_id}__{key}__seed{seed}"
                    metrics_path = cell_directory / "metrics.json"
                    if metrics_path.is_file():
                        row = json.loads(metrics_path.read_text(encoding="utf-8"))
                        identity = (
                            row.get("status") == "completed"
                            and _completed_cell_hash_is_compatible(row, protocol_hash)
                            and row.get("dataset_id") == dataset_id
                            and row.get("family") == family
                            and row.get("regime") == regime
                            and row.get("seed") == seed
                            and row.get("epochs_completed") == config["max_epochs"]
                            and row.get("test_accessed") is False
                        )
                        required = (
                            cell_directory / "checkpoint_best.pt",
                            cell_directory / "checkpoint_last.pt",
                            cell_directory / "history.json",
                            cell_directory / "schedule.json",
                        )
                        if not identity or not all(path.is_file() for path in required):
                            raise ValueError(f"completed cell failed immutable resume checks: {cell_directory.name}")
                        reused_cells += 1
                    else:
                        if cell_directory.exists():
                            archive_root = directory / "incomplete_attempts"
                            archive_root.mkdir(exist_ok=True)
                            archived = archive_root / (
                                cell_directory.name + "__" +
                                datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S%fZ")
                            )
                            if directory not in cell_directory.resolve().parents or directory not in archived.resolve().parents:
                                raise ValueError("incomplete-cell archive escapes run directory")
                            cell_directory.rename(archived)
                        row = train_cell(
                            data, base_config, config, family, regime, seed,
                            cell_directory, device, protocol_hash,
                        )
                    rows.append(row)
                    paired[key] = row
                    _json(directory / "partial.json", {"rows": rows, "test_accessed": False})
                for family in ("ordinary", "physical"):
                    left = paired[f"{family}_nominal"]
                    right = paired[f"{family}_multirate"]
                    if left["initial_state_hash"] != right["initial_state_hash"]:
                        raise RuntimeError("training-view pair did not share initialization")
                    # Scheduled ratios are recorded even when nominal cells apply identity.
                    nominal_schedule = json.loads((directory / f"{dataset_id}__{family}_nominal__seed{seed}" / "schedule.json").read_text(encoding="utf-8"))["schedule"]
                    multi_schedule = json.loads((directory / f"{dataset_id}__{family}_multirate__seed{seed}" / "schedule.json").read_text(encoding="utf-8"))["schedule"]
                    if [row["scheduled_ratio"] for row in nominal_schedule] != [row["scheduled_ratio"] for row in multi_schedule]:
                        raise RuntimeError("training-view pair did not share scheduled ratios")
                if len({row["downstream_initial_state_hash"] for row in paired.values()}) != 1:
                    raise RuntimeError("the four cells did not share downstream initialization")
                schedules = []
                for family, regime in CELLS:
                    schedule_path = directory / f"{dataset_id}__{family}_{regime}__seed{seed}" / "schedule.json"
                    schedule = json.loads(schedule_path.read_text(encoding="utf-8"))["schedule"]
                    schedules.append([row["scheduled_ratio"] for row in schedule])
                if any(schedule != schedules[0] for schedule in schedules[1:]):
                    raise RuntimeError("the four cells did not share the ratio schedule")
            del data
            if device.type == "cuda":
                torch.cuda.empty_cache()
        undertrained = [
            f"{row['dataset_id']}/{row['family']}_{row['regime']}/seed{row['seed']}"
            for row in rows if row["undertraining"]["flagged"]
        ]
        report = {
            **plan,
            "status": "completed_validation_undertrained" if undertrained else "completed_validation",
            "protocol_hash": protocol_hash,
            "rows": rows,
            "undertrained_cells": undertrained,
            "retrospective_test_permitted": (
                config["scope"] == "train_validation_only" and not undertrained
            ),
            "retrospective_test_started": False,
            "runtime": {"device": str(device), "torch": torch.__version__, "numpy": np.__version__},
            "execution_session_seconds": time.monotonic() - execution_started,
            "reused_completed_cells": reused_cells,
            "numerical_amendment_id": AMP_RETRY_AMENDMENT_ID,
            "amendment_parent_protocol_hash": resume_parent_protocol_hash,
            "numerical_retry_count": sum(
                int(row.get("numerical_retry_count", 0)) for row in rows
            ),
            "run_directory": str(directory),
            "test_accessed": False,
        }
        _json(directory / "report.json", report)
        _json(directory / "manifest.json", {
            **plan,
            "status": report["status"],
            "protocol_hash": protocol_hash,
            "undertrained_cells": undertrained,
            "reused_completed_cells": reused_cells,
            "numerical_amendment_id": AMP_RETRY_AMENDMENT_ID,
            "amendment_parent_protocol_hash": resume_parent_protocol_hash,
            "numerical_retry_count": report["numerical_retry_count"],
            "test_accessed": False,
        })
        return report
    except BaseException as error:
        _json(directory / "manifest.json", {
            **plan,
            "status": "failed",
            "protocol_hash": protocol_hash,
            "completed_cells": len(rows),
            "numerical_amendment_id": AMP_RETRY_AMENDMENT_ID,
            "amendment_parent_protocol_hash": resume_parent_protocol_hash,
            "error": f"{type(error).__name__}: {error}",
            "test_accessed": False,
        })
        raise


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", default="configs/experiments/sivp_decisive_controls_validation.yaml")
    parser.add_argument("--execute", action="store_true")
    parser.add_argument("--preflight", action="store_true")
    parser.add_argument("--device", choices=("auto", "cpu", "cuda"), default="auto")
    parser.add_argument("--resume", type=Path, help="Resume an interrupted run with the identical frozen protocol")
    args = parser.parse_args()
    root = Path(__file__).resolve().parents[4]
    result = run(
        root, root / args.config, execute=args.execute,
        preflight_only=args.preflight, device_name=args.device,
        resume_directory=args.resume,
    )
    print(json.dumps({key: value for key, value in result.items() if key not in {"rows", "preflight"}}, indent=2))


if __name__ == "__main__":
    main()
