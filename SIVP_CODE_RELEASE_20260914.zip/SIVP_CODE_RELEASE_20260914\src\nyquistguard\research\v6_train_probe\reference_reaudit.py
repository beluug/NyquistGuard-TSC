"""Re-evaluate saved TRAIN-only OOF checkpoints with one fixed high reference."""

from __future__ import annotations

import argparse
import csv
from datetime import datetime, timezone
import hashlib
import json
import math
from pathlib import Path
import shutil
import time

import numpy as np
from sklearn.metrics import f1_score
import torch
import yaml

from nyquistguard.research.v6.runner import make_model
from nyquistguard.research.v6_envelope.runner import OPTIONS
from .core import error_masks, fingerprint, folds, load_train, standardize_fit
from .fixed_reference import CommonSupport, fixed_common_support_views
from .runner import FAMILY, validate_config as validate_source_config


RATIO_VIEWS = (
    "filtered_dense", "canonical_low", "lifted_low",
    "phase_only", "filter_only", "joint", "window_only",
)


def _json(path: Path, value: object) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(
        json.dumps(value, indent=2, ensure_ascii=False, allow_nan=False),
        encoding="utf-8",
    )
    temporary.replace(path)


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def _protocol_hash(root: Path, config_path: Path, source_manifest: Path) -> str:
    digest = hashlib.sha256()
    for path in (
        config_path,
        Path(__file__),
        Path(__file__).with_name("fixed_reference.py"),
        root / "scripts/run_v6_oof_reference_reaudit.py",
        source_manifest,
    ):
        digest.update(str(path.relative_to(root)).encode())
        digest.update(path.read_bytes())
    return digest.hexdigest()


def _validate_config(config: dict) -> None:
    expected = {
        "protocol_version": "v6_train_oof_fixed_reference_reaudit_v1",
        "scope": "train_only_oof_saved_checkpoint_re_evaluation",
        "automatic_followup": False,
        "source_run": "runs/v6_train_probe/oof__20260908T065355191630Z",
        "source_config": "configs/experiments/v6_train_oof_probe.yaml",
        "output_root": "runs/v6_train_probe",
        "evaluation_rates": [0.9, 0.6, 0.4, 0.3],
        "common_support_rule": "longest_endpoint_aligned_span_on_ratio_denominator_lcm",
        "batch_size": 16,
        "threads": 4,
        "maximum_cuda_allocated_gib": 2,
    }
    for key, value in expected.items():
        if config.get(key) != value:
            raise ValueError(f"fixed-reference re-audit config changed: {key}")
    boundaries = config.get("scientific_boundaries", {})
    required_true = {
        "train_arrays_only", "reuse_saved_fold_checkpoints", "retraining_forbidden",
        "reference_evaluated_once_per_window", "all_low_rate_grids_share_reference_endpoints",
    }
    if any(boundaries.get(key) is not True for key in required_true):
        raise ValueError("fixed-reference scientific boundary changed")
    if boundaries.get("validation_read") is not False or boundaries.get("test_read") is not False:
        raise ValueError("validation/TEST access must remain false")


def _metrics(probabilities: np.ndarray, labels: np.ndarray, classes: int) -> dict:
    predictions = probabilities.argmax(axis=1)
    return {
        "probabilities": probabilities.tolist(),
        "predictions": predictions.tolist(),
        "accuracy": float(np.mean(predictions == labels)),
        "macro_f1": float(f1_score(
            labels, predictions, labels=np.arange(classes), average="macro", zero_division=0
        )),
    }


def _same_standardization(expected: dict, observed: dict) -> bool:
    return (
        expected.get("zeroed_channels") == observed.get("zeroed_channels")
        and np.allclose(expected.get("mean"), observed.get("mean"), rtol=0, atol=1e-12)
        and np.allclose(expected.get("std"), observed.get("std"), rtol=0, atol=1e-12)
    )


@torch.inference_mode()
def _evaluate_cell(
    model: torch.nn.Module,
    x: np.ndarray,
    labels: np.ndarray,
    source_rate_hz: float,
    ratios: tuple[float, ...],
    batch_size: int,
    device: torch.device,
) -> tuple[dict, CommonSupport]:
    model.eval()
    collected: dict[str, list[np.ndarray]] = {"high_reference": []}
    layout: CommonSupport | None = None
    for start in range(0, len(labels), batch_size):
        batch = torch.from_numpy(x[start : start + batch_size]).to(device)
        high, by_ratio, current_layout = fixed_common_support_views(batch, source_rate_hz, ratios)
        if layout is None:
            layout = current_layout
        elif layout != current_layout:
            raise RuntimeError("fixed common support changed between batches")
        collected["high_reference"].append(
            model(high[0], high[1])["logits"].float().softmax(-1).cpu().numpy()
        )
        for ratio in ratios:
            for view, (values, rate) in by_ratio[ratio].items():
                key = f"{ratio}/{view}"
                collected.setdefault(key, []).append(
                    model(values, rate)["logits"].float().softmax(-1).cpu().numpy()
                )
    if layout is None:
        raise ValueError("empty held-out cell")
    result = {
        key: _metrics(np.concatenate(parts), labels, model.num_classes)
        for key, parts in collected.items()
    }
    return result, layout


def _support(mask: np.ndarray, ids: np.ndarray, groups: np.ndarray) -> dict:
    return {
        "observations": int(mask.sum()),
        "unique_windows": int(len(set(ids[mask].tolist()))),
        "groups": int(len(set(groups[mask].tolist()))),
    }


def _summarize(cells: list[dict], ratios: tuple[float, ...], classes: int) -> tuple[dict, list[dict]]:
    labels = np.concatenate([np.asarray(cell["held_labels"], dtype=np.int64) for cell in cells])
    ids = np.concatenate([np.asarray(cell["held_ids"], dtype=str) for cell in cells])
    groups = np.concatenate([
        np.repeat(str(cell["group"]), len(cell["held_ids"])) for cell in cells
    ])
    folds_array = np.concatenate([
        np.repeat(int(cell["fold"]), len(cell["held_ids"])) for cell in cells
    ])
    if len(set(ids.tolist())) != len(ids):
        raise ValueError("corrected OOF summary has repeated windows")
    high_probabilities = np.concatenate([
        np.asarray(cell["conditions"]["high_reference"]["probabilities"], dtype=np.float64)
        for cell in cells
    ])
    high_predictions = high_probabilities.argmax(axis=1)
    high_correct = high_predictions == labels
    records: list[dict] = []
    per_rate: dict[str, dict] = {}
    combined_masks: dict[str, list[np.ndarray]] = {
        name: [] for name in (*error_masks({name: np.ones(1, dtype=bool) for name in FAMILY}),)
    }
    all_low_wrong_lift_right = 0
    all_low_right_lift_wrong = 0
    subject_accumulator: dict[str, dict[str, list]] = {}
    for ratio in ratios:
        probabilities = {"high_reference": high_probabilities}
        for view in RATIO_VIEWS:
            probabilities[view] = np.concatenate([
                np.asarray(cell["conditions"][f"{ratio}/{view}"]["probabilities"], dtype=np.float64)
                for cell in cells
            ])
        predictions = {name: value.argmax(axis=1) for name, value in probabilities.items()}
        correct = {name: value == labels for name, value in predictions.items()}
        masks = error_masks(correct)
        for name, values in masks.items():
            combined_masks.setdefault(name, []).append(values)
        low_correct = correct["canonical_low"]
        lift_correct = correct["lifted_low"]
        low_wrong_lift_right = ~low_correct & lift_correct
        low_right_lift_wrong = low_correct & ~lift_correct
        all_low_wrong_lift_right += int(low_wrong_lift_right.sum())
        all_low_right_lift_wrong += int(low_right_lift_wrong.sum())
        oracle_predictions = predictions["lifted_low"].copy()
        remaining = masks["rate_added"] & ~lift_correct
        oracle_predictions[remaining] = labels[remaining]
        transition = {
            "high_right_low_right": int((high_correct & low_correct).sum()),
            "high_right_low_wrong": int((high_correct & ~low_correct).sum()),
            "high_wrong_low_right": int((~high_correct & low_correct).sum()),
            "high_wrong_low_wrong": int((~high_correct & ~low_correct).sum()),
        }
        per_rate[str(ratio)] = {
            "n_windows": len(labels),
            "counts": {name: int(values.sum()) for name, values in masks.items()},
            "transition_high_vs_canonical_low": transition,
            "views": {
                name: {
                    "accuracy": float(np.mean(prediction == labels)),
                    "macro_f1": float(f1_score(
                        labels, prediction, labels=np.arange(classes), average="macro", zero_division=0
                    )),
                }
                for name, prediction in predictions.items()
            },
            "low_wrong_lift_right": int(low_wrong_lift_right.sum()),
            "low_right_lift_wrong": int(low_right_lift_wrong.sum()),
            "limited_oracle_macro_f1": float(f1_score(
                labels, oracle_predictions, labels=np.arange(classes), average="macro", zero_division=0
            )),
        }
        for index, window_id in enumerate(ids):
            record = {
                "fold": int(folds_array[index]),
                "group": str(groups[index]),
                "window_id": str(window_id),
                "ratio": ratio,
                "true_label": int(labels[index]),
                "high_reference_prediction": int(high_predictions[index]),
                "high_reference_probabilities": high_probabilities[index].tolist(),
            }
            for view in RATIO_VIEWS:
                record[f"{view}_prediction"] = int(predictions[view][index])
                record[f"{view}_probabilities"] = probabilities[view][index].tolist()
            for name, values in masks.items():
                record[name] = bool(values[index])
            records.append(record)
            subject = subject_accumulator.setdefault(str(groups[index]), {
                "labels": [], "canonical": [], "lifted": [], "repairs": [], "introduced": [],
            })
            subject["labels"].append(int(labels[index]))
            subject["canonical"].append(int(predictions["canonical_low"][index]))
            subject["lifted"].append(int(predictions["lifted_low"][index]))
            subject["repairs"].append(bool(low_wrong_lift_right[index]))
            subject["introduced"].append(bool(low_right_lift_wrong[index]))

    combined = {name: np.concatenate(values) for name, values in combined_masks.items() if values}
    repeated_ids = np.tile(ids, len(ratios))
    repeated_groups = np.tile(groups, len(ratios))
    partition = {name: int(combined[name].sum()) for name in (
        "baseline_wrong", "rate_added", "nuisance_added", "stable"
    )}
    observations = len(labels) * len(ratios)
    if sum(partition.values()) != observations:
        raise RuntimeError("corrected partition is not complete")
    if partition["baseline_wrong"] % len(ratios) != 0:
        raise RuntimeError("fixed reference did not produce divisible repeated baseline count")
    mean_low = float(np.mean([per_rate[str(r)]["views"]["canonical_low"]["macro_f1"] for r in ratios]))
    mean_lift = float(np.mean([per_rate[str(r)]["views"]["lifted_low"]["macro_f1"] for r in ratios]))
    mean_oracle = float(np.mean([per_rate[str(r)]["limited_oracle_macro_f1"] for r in ratios]))
    subject_summary = {}
    for group, values in subject_accumulator.items():
        group_labels = np.asarray(values["labels"])
        group_low = np.asarray(values["canonical"])
        group_lift = np.asarray(values["lifted"])
        repaired = int(np.sum(values["repairs"]))
        introduced = int(np.sum(values["introduced"]))
        subject_summary[group] = {
            "observations": len(group_labels),
            "repair_count": repaired,
            "introduced_error_count": introduced,
            "net_error_reduction": repaired - introduced,
            "canonical_low_macro_f1": float(f1_score(
                group_labels, group_low, labels=np.arange(classes), average="macro", zero_division=0
            )),
            "lifted_low_macro_f1": float(f1_score(
                group_labels, group_lift, labels=np.arange(classes), average="macro", zero_division=0
            )),
        }
    rate_mask = combined["rate_added"]
    nuisance_mask = combined["nuisance_added"]
    repair_mask = combined["rate_lift_repaired"]
    high_correct_rows = np.tile(high_correct, len(ratios))
    high_and_low = high_correct_rows & ~combined["rate_added"]
    return {
        "independent_windows": len(labels),
        "dependent_window_rate_observations": observations,
        "fixed_high_reference_accuracy": float(np.mean(high_correct)),
        "fixed_high_reference_correct_windows": int(high_correct.sum()),
        "partition": partition,
        "high_correct_window_rate_observations": int(high_correct_rows.sum()),
        "rate_support": _support(rate_mask, repeated_ids, repeated_groups),
        "nuisance_support": _support(nuisance_mask, repeated_ids, repeated_groups),
        "lift_repair_support": _support(repair_mask, repeated_ids, repeated_groups),
        "rate_conditional_fraction": float(rate_mask.sum() / max(1, high_correct_rows.sum())),
        "nuisance_conditional_fraction": float(nuisance_mask.sum() / max(1, high_and_low.sum())),
        "lift_repair_fraction_of_rate_added": float(repair_mask.sum() / max(1, rate_mask.sum())),
        "remaining_rate_added_after_lift": int((rate_mask & ~combined["rate_lift_repaired"]).sum()),
        "filtered_dense_wrong_among_rate_added": int(combined["rate_filter_wrong"].sum()),
        "low_wrong_lift_right": all_low_wrong_lift_right,
        "low_right_lift_wrong": all_low_right_lift_wrong,
        "net_error_reduction": all_low_wrong_lift_right - all_low_right_lift_wrong,
        "mean_macro_f1": {
            "canonical_low": mean_low,
            "lifted_low": mean_lift,
            "lift_gain": mean_lift - mean_low,
            "limited_oracle": mean_oracle,
            "limited_oracle_gain_over_lifted": mean_oracle - mean_lift,
        },
        "per_rate": per_rate,
        "by_group": subject_summary,
    }, records


def _write_records(path: Path, records: list[dict]) -> None:
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(records[0]))
        writer.writeheader()
        for record in records:
            writer.writerow({
                key: json.dumps(value, separators=(",", ":")) if isinstance(value, list) else value
                for key, value in record.items()
            })


def run(root: Path, config_path: Path, *, execute: bool = False, device_name: str = "auto") -> dict:
    root = root.resolve()
    config_path = config_path.resolve()
    config = yaml.safe_load(config_path.read_text(encoding="utf-8"))
    _validate_config(config)
    plan = {
        "protocol_version": config["protocol_version"],
        "scope": config["scope"],
        "execution_requested": execute,
        "retraining": False,
        "validation_read": False,
        "test_read": False,
    }
    if not execute:
        return plan

    source_run = (root / config["source_run"]).resolve()
    output_boundary = (root / config["output_root"]).resolve()
    if output_boundary not in source_run.parents and source_run != output_boundary:
        raise ValueError("source run escapes registered OOF boundary")
    source_manifest_path = source_run / "manifest.json"
    source_manifest = json.loads(source_manifest_path.read_text(encoding="utf-8"))
    if source_manifest.get("status") != "completed":
        raise ValueError("source OOF run is incomplete")
    source_config_path = (root / config["source_config"]).resolve()
    source_config = yaml.safe_load(source_config_path.read_text(encoding="utf-8"))
    validate_source_config(source_config)
    protocol_hash = _protocol_hash(root, config_path, source_manifest_path)
    stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S%fZ")
    output = output_boundary / f"fixed_reference_reaudit__{stamp}"
    output.mkdir(parents=True, exist_ok=False)
    shutil.copy2(config_path, output / "config_frozen.yaml")
    _json(output / "manifest.json", {
        **plan,
        "status": "running",
        "protocol_hash": protocol_hash,
        "source_manifest_sha256": _sha256(source_manifest_path),
    })
    torch.set_num_threads(int(config["threads"]))
    device = torch.device(
        "cuda" if device_name == "auto" and torch.cuda.is_available()
        else "cpu" if device_name == "auto" else device_name
    )
    if device.type == "cuda":
        torch.cuda.reset_peak_memory_stats(device)
    started = time.monotonic()
    ratios = tuple(float(value) for value in config["evaluation_rates"])
    all_cells: list[dict] = []
    all_records: list[dict] = []
    summaries: dict[str, dict] = {}
    layouts: dict[str, dict] = {}
    try:
        for dataset_id in source_config["datasets"]:
            data = load_train(
                root / source_config["cache_root"] / f"{dataset_id}.npz",
                source_config["train_cap"],
                source_config["cap_seed"],
            )
            if fingerprint(data) != source_manifest["preflight"][dataset_id]["fingerprint"]:
                raise ValueError(f"{dataset_id}: TRAIN fingerprint changed")
            partitions = folds(data, source_config["seed"])
            for arm in source_config["arms"]:
                arm_cells: list[dict] = []
                for fold, (fit, held, group) in enumerate(partitions):
                    source_cell = source_run / f"{dataset_id}__fold{fold}__{arm}"
                    source_metrics = json.loads((source_cell / "metrics.json").read_text(encoding="utf-8"))
                    if source_metrics["held_ids"] != data.train_ids[held].tolist():
                        raise ValueError("saved held IDs differ from reconstructed OOF fold")
                    if source_metrics["held_labels"] != data.train_y[held].tolist():
                        raise ValueError("saved held labels differ from reconstructed OOF fold")
                    standardized, scaling = standardize_fit(data.train_x, fit)
                    if not _same_standardization(source_metrics["standardization"], scaling):
                        raise ValueError("saved fold standardization did not reproduce")
                    model = make_model(data, source_config, OPTIONS, source_config["seed"] + fold).to(device)
                    checkpoint_path = source_cell / "final.pt"
                    checkpoint = torch.load(checkpoint_path, map_location=device, weights_only=True)
                    model.load_state_dict(checkpoint["model"], strict=True)
                    if sum(parameter.numel() for parameter in model.parameters()) != source_metrics["parameters"]:
                        raise ValueError("checkpoint parameter count changed")
                    conditions, layout = _evaluate_cell(
                        model,
                        standardized[held],
                        data.train_y[held],
                        data.rate,
                        ratios,
                        int(config["batch_size"]),
                        device,
                    )
                    layouts.setdefault(dataset_id, layout.to_dict())
                    if layouts[dataset_id] != layout.to_dict():
                        raise RuntimeError("dataset common-support layout changed")
                    cell = {
                        "dataset_id": dataset_id,
                        "arm": arm,
                        "fold": fold,
                        "group": group,
                        "held_ids": data.train_ids[held].tolist(),
                        "held_labels": data.train_y[held].tolist(),
                        "conditions": conditions,
                        "layout": layout.to_dict(),
                        "source_checkpoint": str(checkpoint_path.relative_to(root)).replace("\\", "/"),
                        "source_checkpoint_sha256": _sha256(checkpoint_path),
                        "source_metrics_sha256": _sha256(source_cell / "metrics.json"),
                        "model_eval": True,
                        "retrained": False,
                        "validation_read": False,
                        "test_read": False,
                    }
                    arm_cells.append(cell)
                    all_cells.append(cell)
                    del model, checkpoint
                    if device.type == "cuda":
                        torch.cuda.empty_cache()
                summary, records = _summarize(arm_cells, ratios, len(data.classes))
                key = f"{dataset_id}/{arm}"
                summaries[key] = summary
                for record in records:
                    record["dataset_id"] = dataset_id
                    record["arm"] = arm
                    record["protocol_hash"] = protocol_hash
                all_records.extend(records)

        _write_records(output / "fixed_reference_predictions.csv", all_records)
        with (output / "fixed_reference_predictions.jsonl").open("w", encoding="utf-8") as handle:
            for record in all_records:
                handle.write(json.dumps(record, ensure_ascii=False, allow_nan=False) + "\n")
        focus = summaries["pamap2_uci/multirate_mean"]
        report = {
            **plan,
            "status": "completed",
            "protocol_hash": protocol_hash,
            "source_run": str(source_run.relative_to(root)).replace("\\", "/"),
            "source_manifest_sha256": _sha256(source_manifest_path),
            "runtime": {
                "device": str(device),
                "torch": torch.__version__,
                "numpy": np.__version__,
                "seconds": time.monotonic() - started,
                "peak_cuda_allocated_mib": (
                    torch.cuda.max_memory_allocated(device) / 2**20 if device.type == "cuda" else 0.0
                ),
            },
            "layouts": layouts,
            "summaries": summaries,
            "cells": all_cells,
            "table4_pamap2_multirate": focus,
            "output_directory": str(output),
        }
        _json(output / "report.json", report)
        lines = [
            "# Fixed-reference TRAIN-only OOF re-audit", "",
            f"Protocol hash: `{protocol_hash}`", "",
            "No model was retrained. The 14 saved fold checkpoints were evaluated on TRAIN-only held-out windows with one fixed high-rate reference and endpoint-aligned low-rate grids.", "",
            "## Corrected PAMAP2 multirate result", "",
            f"- Independent windows: {focus['independent_windows']}; dependent window-rate observations: {focus['dependent_window_rate_observations']}.",
            f"- Fixed high-rate accuracy: {focus['fixed_high_reference_accuracy']:.6f} ({focus['fixed_high_reference_correct_windows']}/{focus['independent_windows']}).",
            f"- Partition: baseline wrong {focus['partition']['baseline_wrong']}, rate-added {focus['partition']['rate_added']}, nuisance-added {focus['partition']['nuisance_added']}, stable {focus['partition']['stable']}.",
            f"- Rate-added conditional fraction: {100 * focus['rate_conditional_fraction']:.3f}%.",
            f"- Reconstruction repairs: {focus['lift_repair_support']['observations']}/{focus['rate_support']['observations']}; remaining rate-added errors: {focus['remaining_rate_added_after_lift']}.",
            f"- All-row repair/introduced/net counts: {focus['low_wrong_lift_right']}/{focus['low_right_lift_wrong']}/{focus['net_error_reduction']}.",
            f"- Mean macro-F1, canonical to lifted: {focus['mean_macro_f1']['canonical_low']:.6f} to {focus['mean_macro_f1']['lifted_low']:.6f}.",
            f"- Limited-oracle gain over lifted: {focus['mean_macro_f1']['limited_oracle_gain_over_lifted']:.6f}.",
            "", "## Corrected Table 4", "",
            "| Category | Count | Fraction |", "|---|---:|---:|",
        ]
        labels = [
            ("High-rate reference already wrong", "baseline_wrong"),
            ("High-rate correct, canonical low rate wrong", "rate_added"),
            ("High and canonical low correct, perturbation adds error", "nuisance_added"),
            ("Stable correct under the prespecified conditions", "stable"),
        ]
        for label, key in labels:
            count = focus["partition"][key]
            lines.append(f"| {label} | {count} | {100 * count / focus['dependent_window_rate_observations']:.2f}% |")
        lines.extend(["", "## Per-rate transitions", "",
            "| Ratio | High correct / low correct | High correct / low wrong | High wrong / low correct | High wrong / low wrong | Low F1 | Lifted F1 |",
            "|---:|---:|---:|---:|---:|---:|---:|",
        ])
        for ratio in ratios:
            row = focus["per_rate"][str(ratio)]
            transition = row["transition_high_vs_canonical_low"]
            lines.append(
                f"| {ratio} | {transition['high_right_low_right']} | {transition['high_right_low_wrong']} | "
                f"{transition['high_wrong_low_right']} | {transition['high_wrong_low_wrong']} | "
                f"{row['views']['canonical_low']['macro_f1']:.6f} | {row['views']['lifted_low']['macro_f1']:.6f} |"
            )
        lines.extend(["", "## Group-level reconstruction trade-off", "",
            "| Group | Observations | Repairs | Introduced | Net | Low F1 | Lifted F1 |",
            "|---|---:|---:|---:|---:|---:|---:|",
        ])
        for group, row in focus["by_group"].items():
            lines.append(
                f"| {group} | {row['observations']} | {row['repair_count']} | "
                f"{row['introduced_error_count']} | {row['net_error_reduction']} | "
                f"{row['canonical_low_macro_f1']:.6f} | {row['lifted_low_macro_f1']:.6f} |"
            )
        lines.extend(["", f"Runtime: {report['runtime']['seconds']:.2f} s; peak CUDA allocation: {report['runtime']['peak_cuda_allocated_mib']:.2f} MiB.", ""])
        (output / "REPORT.md").write_text("\n".join(lines), encoding="utf-8")
        _json(output / "manifest.json", {
            **plan,
            "status": "completed",
            "protocol_hash": protocol_hash,
            "source_manifest_sha256": _sha256(source_manifest_path),
            "output_files": ["report.json", "REPORT.md", "fixed_reference_predictions.csv", "fixed_reference_predictions.jsonl"],
        })
        return report
    except BaseException as error:
        _json(output / "manifest.json", {
            **plan,
            "status": "failed",
            "protocol_hash": protocol_hash,
            "error": f"{type(error).__name__}: {error}",
        })
        raise


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", default="configs/experiments/v6_train_oof_reference_reaudit.yaml")
    parser.add_argument("--execute", action="store_true")
    parser.add_argument("--device", choices=("auto", "cpu", "cuda"), default="auto")
    args = parser.parse_args()
    root = Path(__file__).resolve().parents[4]
    result = run(root, root / args.config, execute=args.execute, device_name=args.device)
    print(json.dumps({
        key: value for key, value in result.items() if key not in {"cells", "summaries"}
    }, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()

