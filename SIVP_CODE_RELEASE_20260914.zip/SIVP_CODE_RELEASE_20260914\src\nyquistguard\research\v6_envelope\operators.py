"""Finite FIR + explicit shifted sampling grid, with valid-support cropping.

No reflection, padding, circular wrapping or modification of old resampling.
All four operators at a rate share output length and physical time step.
"""
from __future__ import annotations

from dataclasses import dataclass, asdict
import math
import torch
from torch import Tensor
import torch.nn.functional as F

MARGIN = 19  # 15 FIR half-width + ceil(.75/.25) + 1 interpolation point.


def nominal_view(x: Tensor) -> Tensor:
    if x.ndim != 3 or not x.is_floating_point() or x.shape[-1] - 2 * MARGIN < 8:
        raise ValueError("need floating [B,C,T] and at least eight common interior samples")
    if not torch.isfinite(x).all():
        raise ValueError("nonfinite source")
    return x[..., MARGIN:-MARGIN]


@dataclass(frozen=True)
class AcquisitionSpec:
    ratio: float
    phase: float
    rolloff: float
    window: str = "hamming"
    taps: int = 31

    def __post_init__(self):
        if not math.isfinite(self.ratio) or not .25 <= self.ratio <= 1:
            raise ValueError("ratio must be in [.25,1]")
        if not math.isfinite(self.phase) or not 0 <= self.phase <= .75:
            raise ValueError("phase must be in [0,.75] target-sample intervals")
        if not math.isfinite(self.rolloff) or not 0 < self.rolloff <= 1:
            raise ValueError("invalid rolloff")
        if self.taps != 31 or self.window not in {"hamming", "hann"}:
            raise ValueError("this frozen family uses 31-tap Hamming/Hann only")

    def kernel(self, *, device, dtype) -> Tensor:
        offsets = torch.arange(self.taps, device=device, dtype=torch.float64) - 15
        cutoff = .5 * self.ratio * self.rolloff
        window = (torch.hamming_window if self.window == "hamming" else torch.hann_window)(
            self.taps, periodic=False, device=device, dtype=torch.float64)
        h = 2 * cutoff * torch.sinc(2 * cutoff * offsets) * window
        return (h / h.sum()).to(dtype)

    def grid(self, source_length: int, *, device) -> Tensor:
        interior = source_length - 2 * MARGIN
        length = math.floor(interior * self.ratio)
        if length < 2:
            raise ValueError("fewer than two observable samples")
        return MARGIN + (torch.arange(length, device=device, dtype=torch.float64) + self.phase) / self.ratio

    def apply(self, x: Tensor, source_rate_hz: float) -> tuple[Tensor, float, dict]:
        nominal_view(x)
        if not math.isfinite(source_rate_hz) or source_rate_hz <= 0:
            raise ValueError("invalid source rate")
        # Explicit FP32 unless caller requests FP64; antialias interpolation is
        # excluded from autocast, student forward can still use mixed precision.
        work_dtype = torch.float64 if x.dtype == torch.float64 else torch.float32
        with torch.autocast(x.device.type, enabled=False):
            work = x.to(work_dtype)
            kernel = self.kernel(device=x.device, dtype=work_dtype)
            filtered = F.conv1d(work, kernel[None, None].expand(x.shape[1], 1, -1), groups=x.shape[1])
            grid = self.grid(x.shape[-1], device=x.device)
            position = grid - 15  # valid convolution center coordinate
            left = position.floor().long()
            if left.min() < 0 or left.max() + 1 >= filtered.shape[-1]:
                raise ValueError("sampling support escapes the common valid interior")
            weight = (position - left).to(work_dtype)
            viewed = filtered[..., left] * (1 - weight) + filtered[..., left + 1] * weight
        rate = source_rate_hz * self.ratio  # grid step is exactly 1/ratio, no resize convention
        metadata = {**asdict(self), "method": "valid_fir_then_explicit_linear_grid",
                    "source_length": x.shape[-1], "target_length": viewed.shape[-1],
                    "margin": MARGIN, "actual_rate_hz": rate,
                    "first_time_seconds": float(grid[0]) / source_rate_hz,
                    "last_time_seconds": float(grid[-1]) / source_rate_hz}
        return viewed, rate, metadata


def operator_family(ratio: float, name: str = "train") -> tuple[AcquisitionSpec, ...]:
    if name == "train":
        phases, rolloffs, window = (0., .5), (.8, .95), "hamming"
    elif name in {"heldout_hamming", "heldout_hann"}:
        phases, rolloffs = (.25, .75), (.875, .98)
        window = "hann" if name == "heldout_hann" else "hamming"
    else:
        raise ValueError("unknown registered family")
    return tuple(AcquisitionSpec(ratio, p, k, window) for p in phases for k in rolloffs)
