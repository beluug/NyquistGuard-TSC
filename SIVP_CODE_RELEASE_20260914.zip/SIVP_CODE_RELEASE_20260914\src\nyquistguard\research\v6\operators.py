"""Finite observation operators, with the SAME FIR/resize as the data view."""
from __future__ import annotations

from dataclasses import dataclass
import math

import torch
from torch import Tensor
import torch.nn.functional as F

from nyquistguard.data.resampling import resample_antialiased


def real_fourier_basis(length: int, frequency_pairs: int = 12) -> tuple[Tensor, Tensor]:
    """Orthonormal real DFT columns, spanning the source bandwidth, not a fit."""
    if length < 4 or frequency_pairs < 1:
        raise ValueError("need length >= 4 and frequency_pairs >= 1")
    maximum = max(1, min((length - 1) // 2, int(0.45 * length)))
    bins = torch.linspace(1, maximum, min(frequency_pairs, maximum), dtype=torch.float64).round().unique()
    time = torch.arange(length, dtype=torch.float64)
    phase = 2 * math.pi * time[:, None] * bins[None, :] / length
    basis = torch.cat((torch.ones(length, 1, dtype=torch.float64) / math.sqrt(length),
                       math.sqrt(2 / length) * phase.cos(), math.sqrt(2 / length) * phase.sin()), dim=1)
    return basis, bins


def channel_projection(channels: int, maximum: int = 4, seed: int = 60908) -> Tensor:
    if channels < 1 or maximum < 1:
        raise ValueError("channel dimensions must be positive")
    if channels <= maximum:
        return torch.eye(channels, dtype=torch.float64)
    generator = torch.Generator().manual_seed(seed)
    return torch.linalg.qr(torch.randn(channels, maximum, generator=generator, dtype=torch.float64)).Q


@dataclass(frozen=True)
class ObservationSpec:
    source_rate_hz: float
    ratio: float
    taps: int = 31
    rolloff: float = 0.9
    mode: str = "antialias"

    def __post_init__(self) -> None:
        if not math.isfinite(self.source_rate_hz) or self.source_rate_hz <= 0:
            raise ValueError("source rate must be finite and positive")
        if not math.isfinite(self.ratio) or not 0 < self.ratio <= 1:
            raise ValueError("ratio must be in (0,1]")
        if self.mode not in {"antialias", "naive"}:
            raise ValueError("mode must be antialias or explicit wrong-operator naive control")
        if self.taps < 3 or self.taps % 2 != 1 or not 0 < self.rolloff <= 1:
            raise ValueError("invalid antialias specification")

    def apply(self, x: Tensor) -> tuple[Tensor, float]:
        if x.ndim != 3 or x.shape[-1] < 2:
            raise ValueError("observation expects [B,C,T>=2]")
        if self.mode == "antialias":
            viewed, rate, _ = resample_antialiased(x, self.source_rate_hz, self.ratio,
                                                  taps=self.taps, rolloff=self.rolloff)
        else:
            length = max(2, round(x.shape[-1] * self.ratio))
            viewed = F.interpolate(x, size=length, mode="linear", align_corners=False)
            rate = self.source_rate_hz * length / x.shape[-1]
        return viewed, rate


def reduce_observation(basis: Tensor, spec: ObservationSpec,
                       relative_tolerance: float = 1e-6) -> dict[str, Tensor | float | int]:
    """Compute U, U^T A Phi, and U^T A A^T U without a dense T x T A.

    Metadata/basis are fixed. The adjoint uses vectorized reverse-mode on the
    actual finite operator. No parameter gradient is needed for this teacher.
    """
    if basis.ndim != 2 or not torch.isfinite(basis).all() or not 0 < relative_tolerance < 1:
        raise ValueError("invalid basis or tolerance")
    with torch.inference_mode(False), torch.enable_grad(), torch.autocast(basis.device.type, enabled=False):
        # Existing resampler deliberately works in float32; respect that operator.
        source_basis = basis.detach().float().T.unsqueeze(0)
        response, rate = spec.apply(source_basis)
        response = response[0].T.double()
        u, singular, _ = torch.linalg.svd(response, full_matrices=False)
        keep = singular > singular.max() * relative_tolerance
        u = u[:, keep].contiguous()
        reduced = u.T @ response
        source = torch.zeros(1, 1, basis.shape[0], device=basis.device, requires_grad=True)
        target, _ = spec.apply(source)
        cotangents = u.T.float()[:, None, None, :]
        adjoint = torch.autograd.grad(target, source, grad_outputs=cotangents,
                                      is_grads_batched=True)[0][:, 0, 0, :].double()
        noise_gram = adjoint @ adjoint.T
    return {"u": u.detach(), "response": reduced.detach(), "noise_gram": noise_gram.detach(),
            "effective_rate_hz": float(rate), "rank": int(keep.sum()),
            "singular_values": singular.detach(), "discarded_response_norm": float(singular[~keep].norm())}
