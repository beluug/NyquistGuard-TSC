"""Audited validation-only analysis for the SIVP decisive controls."""

from __future__ import annotations

import argparse
from collections import defaultdict
import json
from pathlib import Path
from typing import Iterable

import numpy as np
from scipy.stats import wilcoxon


CELL_KEYS = (
    "ordinary_nominal",
    "ordinary_multirate",
    "physical_nominal",
    "physical_multirate",
)

CONTRASTS = (
    ("ordinary multirate effect", "ordinary_multirate", "ordinary_nominal"),
    ("physical multirate effect", "physical_multirate", "physical_nominal"),
    ("physical effect under nominal training", "physical_nominal", "ordinary_nominal"),
    ("physical effect under multirate training", "physical_multirate", "ordinary_multirate"),
)


def holm_adjust(p_values: Iterable[float]) -> list[float]:
    values = [float(value) for value in p_values]
    order = sorted(range(len(values)), key=values.__getitem__)
    adjusted = [0.0] * len(values)
    running = 0.0
    for rank, index in enumerate(order):
        running = max(running, min(1.0, (len(values) - rank) * values[index]))
        adjusted[index] = running
    return adjusted


def _bootstrap_mean_interval(values: np.ndarray, seed: int) -> list[float]:
    rng = np.random.default_rng(seed)
    indices = rng.integers(0, len(values), size=(10_000, len(values)))
    means = values[indices].mean(axis=1)
    return [float(np.quantile(means, 0.025)), float(np.quantile(means, 0.975))]


def analyze(report: dict, *, bootstrap_seed: int = 17) -> dict:
    if report.get("test_accessed") is not False:
        raise ValueError("analysis rejected because TEST-access state is not false")
    rows = report.get("rows", [])
    if len(rows) != 120:
        raise ValueError(f"expected 120 completed validation cells, found {len(rows)}")
    grouped: dict[str, dict[str, list[dict]]] = defaultdict(lambda: defaultdict(list))
    for row in rows:
        if row.get("status") != "completed" or row.get("test_accessed") is not False:
            raise ValueError("validation row is incomplete or has invalid TEST state")
        key = f"{row['family']}_{row['regime']}"
        grouped[row["dataset_id"]][key].append(row)
    if len(grouped) != 10:
        raise ValueError(f"expected ten datasets, found {len(grouped)}")

    cell_means = {}
    for dataset_id, cells in grouped.items():
        if set(cells) != set(CELL_KEYS) or any(len(cells[key]) != 3 for key in CELL_KEYS):
            raise ValueError(f"unbalanced cells for {dataset_id}")
        cell_means[dataset_id] = {
            key: float(np.mean([
                row["validation"]["mean_unseen_macro_f1"] for row in cells[key]
            ]))
            for key in CELL_KEYS
        }

    comparison_rows = []
    arrays = []
    dataset_order = list(cell_means)
    for index, (name, left, right) in enumerate(CONTRASTS):
        values = np.asarray([
            cell_means[dataset_id][left] - cell_means[dataset_id][right]
            for dataset_id in dataset_order
        ], dtype=np.float64)
        arrays.append(values)
        test = wilcoxon(values, zero_method="wilcox", alternative="two-sided", method="auto")
        comparison_rows.append({
            "contrast": name,
            "left": left,
            "right": right,
            "dataset_effects": dict(zip(dataset_order, values.tolist())),
            "mean": float(values.mean()),
            "median": float(np.median(values)),
            "positive_dataset_count": int(np.sum(values > 0)),
            "zero_dataset_count": int(np.sum(values == 0)),
            "wilcoxon_statistic": float(test.statistic),
            "p_raw": float(test.pvalue),
            "bootstrap_95_interval": _bootstrap_mean_interval(values, bootstrap_seed + index),
        })
    adjusted = holm_adjust(row["p_raw"] for row in comparison_rows)
    for row, value in zip(comparison_rows, adjusted):
        row["p_holm"] = value

    interaction = arrays[1] - arrays[0]
    undertrained = [row for row in rows if row["undertraining"]["flagged"]]
    affected_datasets = sorted({row["dataset_id"] for row in undertrained})
    retry_counts = defaultdict(int)
    for row in rows:
        retry_counts[row["dataset_id"]] += int(row.get("numerical_retry_count", 0))
    return {
        "status": "provisional_undertraining_extension_required" if undertrained else "validation_complete",
        "source_protocol_hash": report["protocol_hash"],
        "completed_cells": len(rows),
        "dataset_count": len(grouped),
        "bootstrap_resamples": 10_000,
        "bootstrap_seed": bootstrap_seed,
        "cell_means": cell_means,
        "primary_comparisons": comparison_rows,
        "interaction": {
            "dataset_effects": dict(zip(dataset_order, interaction.tolist())),
            "mean": float(interaction.mean()),
            "median": float(np.median(interaction)),
            "positive_dataset_count": int(np.sum(interaction > 0)),
            "bootstrap_95_interval": _bootstrap_mean_interval(interaction, bootstrap_seed + 4),
            "inferential_status": "descriptive_by_protocol",
        },
        "undertraining": {
            "flagged_cells": len(undertrained),
            "affected_datasets": affected_datasets,
            "required_extension_cells": len(affected_datasets) * 12,
            "retrospective_test_permitted": False if undertrained else True,
        },
        "numerical_retry_count": int(sum(retry_counts.values())),
        "numerical_retries_by_dataset": dict(retry_counts),
        "test_accessed": False,
    }


def render_markdown(result: dict, run_directory: Path) -> str:
    lines = [
        "# SIVP decisive controls: 45-epoch validation audit",
        "",
        f"Source: `{run_directory}`  ",
        f"Protocol hash: `{result['source_protocol_hash']}`  ",
        "Scope: TRAIN/validation only; TEST was not accessed.",
        "",
        "## Completion and decision",
        "",
        f"All {result['completed_cells']} cells completed across {result['dataset_count']} datasets. "
        f"The executable undertraining rule flagged {result['undertraining']['flagged_cells']} cells "
        f"and affected {len(result['undertraining']['affected_datasets'])} datasets. The frozen remedy "
        f"therefore requires {result['undertraining']['required_extension_cells']} cells to continue "
        "from epoch 45 through epoch 60 before any retrospective TEST evaluation. The statistics below "
        "are provisional and cannot freeze the manuscript claim.",
        "",
        "## Three-seed mean unseen-rate macro-F1",
        "",
        "| Dataset | O-N | O-M | P-N | P-M |",
        "|---|---:|---:|---:|---:|",
    ]
    for dataset_id, cells in result["cell_means"].items():
        lines.append(
            f"| {dataset_id} | {cells['ordinary_nominal']:.4f} | "
            f"{cells['ordinary_multirate']:.4f} | {cells['physical_nominal']:.4f} | "
            f"{cells['physical_multirate']:.4f} |"
        )
    lines.extend([
        "",
        "## Prespecified primary comparison family",
        "",
        "| Contrast | Mean | Median | Positive datasets | Bootstrap 95% interval | Raw p | Holm p |",
        "|---|---:|---:|---:|---:|---:|---:|",
    ])
    for row in result["primary_comparisons"]:
        lower, upper = row["bootstrap_95_interval"]
        lines.append(
            f"| {row['contrast']} | {row['mean']:+.4f} | {row['median']:+.4f} | "
            f"{row['positive_dataset_count']}/10 | [{lower:+.4f}, {upper:+.4f}] | "
            f"{row['p_raw']:.4f} | {row['p_holm']:.4f} |"
        )
    interaction = result["interaction"]
    lower, upper = interaction["bootstrap_95_interval"]
    lines.extend([
        "",
        f"The prespecified descriptive interaction is {interaction['mean']:+.4f} "
        f"(dataset-bootstrap 95% interval [{lower:+.4f}, {upper:+.4f}]; "
        f"{interaction['positive_dataset_count']}/10 datasets positive).",
        "",
        "At 45 epochs, multirate training significantly improves the physical model after Holm "
        "correction. The incremental physical-versus-ordinary effect under multirate training does "
        "not pass the primary comparison family. Because the undertraining gate failed, neither result "
        "is final and no TEST analysis is permitted.",
        "",
        "## Numerical execution",
        "",
        f"The audited same-batch AMP policy recorded {result['numerical_retry_count']} scale-reduction "
        "retries. Every cell completed with finite saved metrics and exactly one successful optimizer "
        "update per scheduled batch. Retry counts diagnose mixed-precision execution and are not "
        "performance outcomes.",
        "",
    ])
    return "\n".join(lines)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--run", type=Path, required=True)
    parser.add_argument(
        "--output-dir", type=Path,
        default=Path("reports/sivp_decisive_controls/validation_45epoch"),
    )
    args = parser.parse_args()
    run_directory = args.run.resolve()
    source = json.loads((run_directory / "report.json").read_text(encoding="utf-8"))
    result = analyze(source)
    output = args.output_dir.resolve()
    output.mkdir(parents=True, exist_ok=True)
    (output / "analysis.json").write_text(
        json.dumps(result, indent=2, ensure_ascii=False, allow_nan=False), encoding="utf-8"
    )
    (output / "REPORT.md").write_text(
        render_markdown(result, run_directory), encoding="utf-8"
    )
    print(json.dumps({
        "status": result["status"],
        "completed_cells": result["completed_cells"],
        "undertrained_cells": result["undertraining"]["flagged_cells"],
        "required_extension_cells": result["undertraining"]["required_extension_cells"],
        "output_directory": str(output),
        "test_accessed": False,
    }, indent=2))


if __name__ == "__main__":
    main()
