"""Controlled acquisition populations, including no-benefit and failure cases.

The learning probe isolates L_env using a two-coefficient linear classifier and
fixed L2, not the full TCN. Inputs are generated via the production finite FIR.
It establishes what per-example worst acquisition can do, not TSC performance.
"""
from __future__ import annotations
import math
import time
import torch
import torch.nn.functional as F
from nyquistguard.losses.v6_acquisition_risk import AcquisitionRisk
from .operators import MARGIN, operator_family


def signal_population(condition: str = "nuisance"):
    length, rate, ratio = 256, 128., .5
    labels = torch.tensor([0, 0, 1, 1])
    sign = (2 * labels - 1).double()
    types = torch.tensor([0, 1, 0, 1]).double()
    t = torch.arange(length, dtype=torch.float64) / rate
    frequency = .49 * rate * ratio
    delta_angle = 2 * math.pi * frequency * .5 / (rate * ratio)
    phase = math.pi / 2 - delta_angle / 2 - 2 * math.pi * frequency * MARGIN / rate + types * math.pi
    stable = .25 * sign[:, None].expand(-1, length)
    shortcut = sign[:, None] * (1.2 + 8 * torch.cos(2 * math.pi * frequency * t[None] + phase[:, None]))
    if condition == "no_nuisance":
        shortcut = torch.zeros_like(shortcut)
    elif condition == "no_information":
        shortcut, stable = torch.zeros_like(shortcut), torch.zeros_like(stable)
    elif condition not in {"nuisance", "semantic_failure"}:
        raise ValueError("unknown synthetic condition")
    x = torch.stack((stable, shortcut), 1)
    train = torch.stack([spec.apply(x, rate)[0][:, :, 0] for spec in operator_family(ratio)]).float()
    heldout = torch.stack([spec.apply(x, rate)[0][:, :, 0] for name in ("heldout_hamming", "heldout_hann")
                          for spec in operator_family(ratio, name)]).float()
    return train, heldout, labels, {"source_rate": rate, "target_rate": rate * ratio,
        "frequency_hz": frequency, "source_length": length, "extractor": "first valid sample of two channels",
        "condition": condition, "stable_channel_amplitude": .25}


def losses(features, labels, weights):
    logits = features @ weights
    return F.binary_cross_entropy_with_logits(logits, labels.float()[None].expand_as(logits), reduction="none")


def fit_probe(features, labels, mode, seed, steps=800):
    generator = torch.Generator().manual_seed(seed)
    weights = torch.nn.Parameter(torch.randn(2, generator=generator) * .01)
    optimizer = torch.optim.Adam([weights], lr=.03)
    risk = AcquisitionRisk(features.shape[0], mode)
    for step in range(steps):
        if step == steps // 2:
            optimizer.param_groups[0]["lr"] = .003
        optimizer.zero_grad()
        objective = risk(losses(features, labels, weights), update=True) + .2 * weights.square().sum()
        objective.backward()
        optimizer.step()
    return weights.detach()


def probe(seed=60919, condition="nuisance", steps=800):
    train, heldout, y, metadata = signal_population(condition)
    rows = {}
    for mode in ("mean", "envelope", "group_dro", "batch_max"):
        w = fit_probe(train, y, mode, seed, steps)
        train_loss, heldout_loss = losses(train, y, w), losses(heldout, y, w)
        accuracy = ((train @ w >= 0) == y.bool()[None]).all(0).float().mean()
        rows[mode] = {"weights": w.tolist(), "worst_per_example_nll": float(train_loss.max(0).values.mean()),
                      "worst_per_example_accuracy": float(accuracy),
                      "heldout_worst_nll": float(heldout_loss.max(0).values.mean()),
                      "mean_nll": float(train_loss.mean())}
    if condition == "semantic_failure":
        # Counterexample to the label-preservation assumption: acquisition phase
        # is itself part of the target, so phase .5 changes the true label.
        w = torch.tensor(rows["envelope"]["weights"])
        true_by_operator = y[None].expand(4, -1).clone()
        true_by_operator[2:] = 1 - true_by_operator[2:]
        rows["envelope"]["phase_semantic_worst_accuracy"] = float(
            (((train @ w >= 0) == true_by_operator.bool()).float().mean(1)).min())
    return {"seed": seed, "metadata": metadata, "results": rows}


def assert_contract(row):
    """Frozen before running any probe; failures remain failures."""
    r, condition = row["results"], row["metadata"]["condition"]
    env, mean = r["envelope"], r["mean"]
    if condition in {"nuisance", "semantic_failure"}:
        assert env["worst_per_example_nll"] + .01 < mean["worst_per_example_nll"]
        assert env["heldout_worst_nll"] + .005 < mean["heldout_worst_nll"]
        assert env["worst_per_example_accuracy"] >= .95
        assert env["worst_per_example_nll"] + .005 < r["batch_max"]["worst_per_example_nll"]
        if condition == "semantic_failure":
            assert env["phase_semantic_worst_accuracy"] <= .25
    elif condition == "no_nuisance":
        assert abs(env["worst_per_example_nll"] - mean["worst_per_example_nll"]) < 1e-4
    else:
        for result in r.values():
            assert abs(result["mean_nll"] - math.log(2)) < 1e-6
            assert result["worst_per_example_accuracy"] == .5


def scientific_suite():
    torch.set_num_threads(4)
    started = time.monotonic()
    rows = [probe(seed, condition) for seed in (60919, 60920, 60921)
            for condition in ("nuisance", "no_nuisance", "no_information", "semantic_failure")]
    # Return results before assertion so the entry point can preserve failed runs.
    return {"scope": "synthetic_only", "real_data_accessed": False, "rows": rows,
            "seconds": time.monotonic() - started}
