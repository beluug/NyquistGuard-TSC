"""Observation-pushforward posterior DIFFERENCE teaching, isolated from CBE."""
from __future__ import annotations

import math
import torch
from torch import Tensor, nn
import torch.nn.functional as F


class PosteriorTransportLoss(nn.Module):
    """Paired CE plus sum-of-class squared probability-change error.

    Controls all use the identical student: ce, zero_difference, direct_teacher,
    high_teacher, label_smoothing, and opdt (including wrong-operator targets).
    """
    MODES = {"ce", "opdt", "zero_difference", "direct_teacher", "high_teacher", "label_smoothing", "all_pairs_difference"}

    def __init__(self, weight: float = 1., mode: str = "opdt", smoothing: float = 0.1) -> None:
        super().__init__()
        if mode not in self.MODES or not math.isfinite(weight) or weight < 0 or not 0 <= smoothing < 1:
            raise ValueError("invalid transport loss configuration")
        self.weight, self.mode, self.smoothing = float(weight), mode, smoothing

    def forward(self, high_logits: Tensor, low_logits: Tensor, targets: Tensor,
                high_teacher: Tensor | None = None, low_teacher: Tensor | None = None) -> dict[str, Tensor]:
        if high_logits.ndim != 2 or high_logits.shape != low_logits.shape or targets.shape != high_logits.shape[:1]:
            raise ValueError("paired logits [B,K] and targets [B] required")
        high, low = high_logits.float().softmax(-1), low_logits.float().softmax(-1)
        smoothing = self.smoothing if self.mode == "label_smoothing" else 0.
        ce = 0.5 * (F.cross_entropy(high_logits.float(), targets, label_smoothing=smoothing)
                    + F.cross_entropy(low_logits.float(), targets, label_smoothing=smoothing))
        auxiliary = ce * 0
        target_difference = torch.zeros_like(high)
        if self.mode in {"opdt", "direct_teacher", "high_teacher", "all_pairs_difference"}:
            for teacher in (high_teacher, low_teacher):
                if teacher is None or teacher.shape != high.shape or not torch.isfinite(teacher).all():
                    raise ValueError("both finite matching teachers required")
                if torch.any(teacher < 0) or not torch.allclose(teacher.sum(-1), torch.ones_like(teacher[:, 0]), atol=1e-5):
                    raise ValueError("teacher must be a probability distribution")
            qh, ql = high_teacher.detach().float(), low_teacher.detach().float()
            target_difference = ql - qh
            if self.mode == "opdt":
                auxiliary = ((low - high) - target_difference).square().sum(-1).mean()
            elif self.mode == "direct_teacher":
                auxiliary = 0.5 * ((high - qh).square().sum(-1).mean() + (low - ql).square().sum(-1).mean())
            elif self.mode == "all_pairs_difference":
                # Exact mean over every ordered pair of the 2B observations:
                # E_ij ||(p_i-p_j)-(q_i-q_j)||² = 2 E_i ||e_i-mean(e)||².
                # A generic relational control, NOT a claimed PDRD reproduction.
                error = torch.cat((high - qh, low - ql), 0)
                auxiliary = 2 * (error - error.mean(0)).square().sum(-1).mean()
            else:
                auxiliary = (low - qh).square().sum(-1).mean()
        elif self.mode == "zero_difference":
            auxiliary = (low - high).square().sum(-1).mean()
        return {"total": ce + self.weight * auxiliary, "classification": ce,
                "transport": auxiliary, "target_difference_norm": target_difference.norm(dim=-1).mean()}
