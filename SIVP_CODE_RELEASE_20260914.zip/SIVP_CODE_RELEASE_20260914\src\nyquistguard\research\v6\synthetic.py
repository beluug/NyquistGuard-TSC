"""Controlled scientific checks; generated arrays only, no dataset access.

The periodic ideal operator is a reference experiment, NEVER a real-data view.
Both it and the production FIR operator are tested explicitly.
"""
from __future__ import annotations

from dataclasses import dataclass
import itertools
import math
import time

import torch
from torch import Tensor, nn
import torch.nn.functional as F

from nyquistguard.losses.v6_posterior_transport import PosteriorTransportLoss
from .operators import ObservationSpec
from .posterior import SpectralPushforwardTeacher


@dataclass(frozen=True)
class IdealPeriodicSpec(ObservationSpec):
    """Exact periodic low-pass followed by integer decimation (synthetic only)."""
    def apply(self, x: Tensor) -> tuple[Tensor, float]:
        factor = round(1 / self.ratio)
        if not math.isclose(factor * self.ratio, 1.) or x.shape[-1] % factor:
            raise ValueError("ideal reference needs integer decimation")
        if factor == 1:
            return x.clone(), self.source_rate_hz
        frequency = torch.fft.rfftfreq(x.shape[-1], device=x.device)
        # Strict inequality excludes the target Nyquist endpoint ambiguity.
        spectrum = torch.fft.rfft(x.float()) * (frequency < .5 / factor)
        y = torch.fft.irfft(spectrum, n=x.shape[-1])[..., ::factor]
        return y.to(x.dtype), self.source_rate_hz / factor


def known_teacher(*, only_high: bool = False, low_only: bool = False,
                  reversed_low: bool = False, device: str = "cpu") -> SpectralPushforwardTeacher:
    length = 128
    t = torch.arange(length, dtype=torch.float64)
    # DC ensures a nonempty observable space even when both class signals vanish.
    basis = torch.stack((torch.ones_like(t) / math.sqrt(length),
                         math.sqrt(2 / length) * torch.cos(2 * math.pi * 4 * t / length),
                         math.sqrt(2 / length) * torch.cos(2 * math.pi * 32 * t / length)), -1)
    means = torch.tensor([[[0., -1., 0.]], [[0., 1., 6.]]], dtype=torch.float64)
    if only_high:
        means[:, :, 1] = 0.
    if low_only:
        means[:, :, 2] = 0.
    if reversed_low:
        means[:, :, 1] *= -1
    return SpectralPushforwardTeacher(basis, torch.ones(1, 1), means,
                                      torch.full_like(means, .16), torch.tensor([.5, .5]),
                                      0., 1e-4).to(device)


def signal_experiment(seed: int = 60908, count: int = 2048, device: str = "cpu") -> dict:
    """Partial information: marginalize high frequency; don't impute it as zero."""
    generator = torch.Generator(device=device).manual_seed(seed)
    teacher = known_teacher(device=device)
    labels = torch.arange(count, device=device) % 2
    coefficients = teacher.means[labels] + .4 * torch.randn(count, 1, 3, generator=generator, device=device, dtype=torch.float64)
    source = (coefficients @ teacher.basis.T).float()
    spec = IdealPeriodicSpec(128., .25)
    low, rate = spec.apply(source)
    low = low + .01 * torch.randn(low.shape, generator=generator, device=device)
    q = teacher(low, spec, sampling_rate_hz=rate)["probabilities"]
    # Deliberately wrong scientific control: reconstruct low Fourier coefficients
    # then treat the unobserved high coefficient as an observed zero.
    f = spec.apply(teacher.basis.T.float()[None])[0][0].T.double()
    filled = low.double() @ torch.linalg.pinv(f).T
    filled[..., 2] = 0.
    wrong_score = -.5 * ((filled[:, None] - teacher.means[None]).square() / teacher.variances[None]).sum((-1, -2))
    wrong = wrong_score.softmax(-1).float()
    onehot = F.one_hot(labels, 2)
    metrics = lambda p: {"accuracy": float((p.argmax(-1) == labels).float().mean()),
        "brier": float((p - onehot).square().sum(-1).mean()),
        "nll": float(F.nll_loss(p.clamp_min(1e-8).log(), labels))}
    erased_teacher = known_teacher(only_high=True, device=device)
    erased_coefficients = erased_teacher.means[labels] + .4 * torch.randn(count, 1, 3, generator=generator, device=device, dtype=torch.float64)
    erased, erased_rate = spec.apply((erased_coefficients @ teacher.basis.T).float())
    erased_q = erased_teacher(erased, spec, sampling_rate_hz=erased_rate)["probabilities"]
    low_teacher = known_teacher(low_only=True, device=device)
    low_coefficients = low_teacher.means[labels] + .4 * torch.randn(count, 1, 3, generator=generator, device=device, dtype=torch.float64)
    low_source = (low_coefficients @ teacher.basis.T).float()
    low_view, _ = spec.apply(low_source)
    qh = low_teacher(low_source, IdealPeriodicSpec(128., 1.), sampling_rate_hz=128.)["probabilities"]
    ql = low_teacher(low_view, spec, sampling_rate_hz=rate)["probabilities"]
    # Failure is intentional: a class-density mistake reverses the surviving cue.
    bad = known_teacher(reversed_low=True, device=device)(low, spec, sampling_rate_hz=rate)["probabilities"]
    return {"seed": seed, "n": count, "source_hz": 128, "target_hz": 32,
            "frequencies_hz": [4, 32], "operator": "ideal_periodic_reference",
            "correct_marginal": metrics(q), "wrong_zero_imputation": metrics(wrong),
            "fully_erased_max_distance_from_prior": float((erased_q - .5).abs().max()),
            "low_only_mean_posterior_change": float((ql - qh).abs().mean()),
            "misspecified_teacher": metrics(bad)}


def population_transport_experiment(seed: int = 60908, condition: str = "information_loss", steps: int = 400) -> dict:
    """Exact finite population, SAME lookup student for every loss.

    Binary low/high Fourier signs have class-conditional error .30/.10 and
    class prior .35. Counts are exact rational probabilities (N=2000).
    Ideal decimation erases the high sign. No train/evaluation sampling error.
    This isolates the LOSS; it is not evidence of real-data TCN performance.
    """
    if condition not in {"information_loss", "no_loss", "misspecified", "common_bias", "source_shared_bias"}:
        raise ValueError("unknown synthetic condition")
    hindices, lindices, labels = [], [], []
    joint = torch.zeros(2, 2, 2, dtype=torch.float64)
    for y, low, high in itertools.product(range(2), repeat=3):
        probability = (.35 if y else .65) * (.7 if low == y else .3) * (.9 if high == y else .1)
        joint[y, low, high] = probability
        count = round(2000 * probability)
        hindices.extend([2 * low + high] * count)
        lindices.extend([(2 * low + high) if condition == "no_loss" else low] * count)
        labels.extend([y] * count)
    hi, lo, y = torch.tensor(hindices), torch.tensor(lindices), torch.tensor(labels)
    high_truth = (joint / joint.sum(0, keepdim=True)).permute(1, 2, 0).reshape(4, 2).float()
    low_truth = (joint.sum(2) / joint.sum((0, 2))[None]).T.float()
    qh = high_truth[hi]
    ql = high_truth[lo] if condition == "no_loss" else low_truth[lo]
    targets_h, targets_l = (1 - qh, 1 - ql) if condition == "misspecified" else (qh, ql)
    if condition == "common_bias":
        # Exact same class-probability bias at both rates, inside the simplex.
        # It cancels from OPDT but is inherited by direct posterior teaching.
        bias = torch.tensor([-.07, .07])
        targets_h, targets_l = qh + bias, ql + bias
    if condition == "source_shared_bias":
        # Bias differs between low-cue groups but is common to both rates of
        # each source. Across-source relation matching no longer cancels it.
        scalar = torch.where(lo == 0, .07, -.07)
        bias = torch.stack((-scalar, scalar), -1)
        targets_h, targets_l = qh + bias, ql + bias
    results = {}
    torch.manual_seed(seed)
    initial = .05 * torch.randn(8, 2)
    for mode in ("ce", "opdt", "zero_difference", "direct_teacher", "all_pairs_difference"):
        logits = nn.Parameter(initial.clone())
        optimizer = torch.optim.Adam([logits], lr=.05)
        objective = PosteriorTransportLoss(1., mode)
        for _ in range(steps):
            optimizer.zero_grad()
            loss = objective(logits[hi], logits[4 + lo], y, targets_h, targets_l)
            loss["total"].backward()
            optimizer.step()
        with torch.no_grad():
            ph, pl = logits[hi].softmax(-1), logits[4 + lo].softmax(-1)
            nll = .5 * (F.cross_entropy(logits[hi], y) + F.cross_entropy(logits[4 + lo], y))
            results[mode] = {"paired_population_nll": float(nll),
                "posterior_mse": float(.5 * ((ph - qh).square().sum(-1).mean() + (pl - ql).square().sum(-1).mean())),
                "true_change_mse": float(((pl - ph) - (ql - qh)).square().sum(-1).mean())}
    return {"seed": seed, "condition": condition, "steps": steps,
            "population_mass": float(joint.sum()), "integer_population": len(y), "results": results}


def assert_scientific_contract(signals: list[dict], populations: list[dict]) -> None:
    """Thresholds written BEFORE execution; failed runs must remain recorded."""
    for row in signals:
        assert row["correct_marginal"]["accuracy"] > .95
        assert row["correct_marginal"]["brier"] + .25 < row["wrong_zero_imputation"]["brier"]
        assert row["fully_erased_max_distance_from_prior"] < 1e-4
        assert row["low_only_mean_posterior_change"] < .002
        assert row["misspecified_teacher"]["accuracy"] < .1
    for row in populations:
        r = row["results"]
        if row["condition"] == "information_loss":
            assert r["opdt"]["posterior_mse"] < 1e-5
            assert r["opdt"]["paired_population_nll"] + .005 < r["zero_difference"]["paired_population_nll"]
            # Correct ordinary CE/direct teaching can reach the same Bayes optimum.
            assert abs(r["opdt"]["paired_population_nll"] - r["ce"]["paired_population_nll"]) < 1e-4
            assert abs(r["opdt"]["paired_population_nll"] - r["direct_teacher"]["paired_population_nll"]) < 1e-4
        elif row["condition"] == "no_loss":
            assert abs(r["opdt"]["paired_population_nll"] - r["zero_difference"]["paired_population_nll"]) < 1e-4
        elif row["condition"] == "common_bias":
            assert r["opdt"]["posterior_mse"] < 1e-5
            assert r["direct_teacher"]["posterior_mse"] > .0001
            assert r["opdt"]["paired_population_nll"] + .0005 < r["direct_teacher"]["paired_population_nll"]
            assert abs(r["opdt"]["paired_population_nll"] - r["all_pairs_difference"]["paired_population_nll"]) < 1e-4
        elif row["condition"] == "source_shared_bias":
            assert r["opdt"]["posterior_mse"] < 1e-5
            assert r["opdt"]["paired_population_nll"] + .0005 < r["all_pairs_difference"]["paired_population_nll"]
        else:
            assert r["opdt"]["paired_population_nll"] > r["ce"]["paired_population_nll"] + .01


def run_scientific_suite() -> dict:
    started = time.monotonic()
    torch.set_num_threads(4)
    seeds = [60908, 60909, 60910]
    signals = [signal_experiment(seed) for seed in seeds]
    populations = [population_transport_experiment(seed, condition) for seed in seeds
                   for condition in ("information_loss", "no_loss", "misspecified", "common_bias", "source_shared_bias")]
    assert_scientific_contract(signals, populations)
    return {"status": "passed", "scope": "synthetic_only", "real_data_accessed": False,
            "signals": signals, "population_loss_experiments": populations,
            "seconds": time.monotonic() - started}
