"""Source-group splits, controlled observations, and predeclared error taxonomy."""
from dataclasses import dataclass
import hashlib
import math
from pathlib import Path
import zipfile

import numpy as np
from sklearn.model_selection import StratifiedKFold
import torch
import torch.nn.functional as F

from nyquistguard.research.v6.runner import _cap
from nyquistguard.research.v6_envelope.operators import AcquisitionSpec, MARGIN, nominal_view


@dataclass
class TrainData:
    dataset_id: str
    rate: float
    classes: tuple
    train_x: np.ndarray
    train_y: np.ndarray
    train_ids: np.ndarray


def load_train(path: Path, cap=256, seed=60908):
    # Inspect and materialize explicit TRAIN members only, never the whole NPZ.
    size = 0
    with zipfile.ZipFile(path) as archive:
        for name in ("train_x", "train_y", "train_ids"):
            with archive.open(name + ".npy") as member:
                version = np.lib.format.read_magic(member)
                if version == (1, 0):
                    shape, _, dtype = np.lib.format.read_array_header_1_0(member)
                elif version == (2, 0):
                    shape, _, dtype = np.lib.format.read_array_header_2_0(member)
                else:
                    raise ValueError("unsupported TRAIN header")
                if dtype.hasobject:
                    raise ValueError("object TRAIN arrays forbidden")
                size += math.prod(shape) * dtype.itemsize
    if size > 2 * 2**30:
        raise MemoryError("TRAIN input exceeds 2 GiB")
    with np.load(path, allow_pickle=False) as p:
        name, rate = str(p["dataset_id"].item()), float(p["sampling_rate_hz"].item())
        classes = tuple(p["class_names"].astype(str).tolist())
        y, ids = p["train_y"], p["train_ids"].astype(str)
        if y.ndim != 1 or not np.issubdtype(y.dtype, np.integer) or ids.shape != y.shape or len(set(ids)) != len(ids):
            raise ValueError("invalid TRAIN labels/IDs")
        if set(np.unique(y)) != set(range(len(classes))) or len(classes) < 2:
            raise ValueError("TRAIN must cover the vocabulary")
        take = _cap(y, cap, seed)
        full_x = p["train_x"]
        if full_x.ndim != 3 or len(full_x) != len(y) or full_x.dtype != np.float32:
            raise ValueError("invalid TRAIN tensor")
        x = full_x[take].copy()
    if name not in ("basicmotions_uea", "pamap2_uci") or rate <= 0 or not math.isfinite(rate):
        raise ValueError("unregistered dataset/rate")
    if not np.isfinite(x).all() or x.shape[-1] - 2 * MARGIN < 31:
        raise ValueError("nonfinite or too short TRAIN")
    return TrainData(name, rate, classes, x, y[take], ids[take])


def fingerprint(data):
    h = hashlib.sha256(f"{data.dataset_id}:{data.rate}:{data.classes}".encode())
    for key in ("train_x", "train_y", "train_ids"):
        value = np.ascontiguousarray(getattr(data, key))
        h.update(f"{key}:{value.dtype}:{value.shape}".encode()); h.update(value.tobytes())
    return h.hexdigest()


def folds(data, seed=60923):
    groups = np.asarray([str(s).split(":")[0] for s in data.train_ids])
    if data.dataset_id == "pamap2_uci":
        if set(groups) != {f"Protocol/subject{s}" for s in range(101, 106)}:
            raise ValueError("PAM TRAIN requires registered five subject groups")
        split = [(np.flatnonzero(groups != g), np.flatnonzero(groups == g), g) for g in sorted(set(groups))]
    else:
        if len(set(groups)) != len(groups):
            raise ValueError("Basic record IDs must be unique; no subject labels available")
        split = [(a, b, f"record_fold_{i}") for i, (a, b) in enumerate(
            StratifiedKFold(2, shuffle=True, random_state=seed).split(data.train_y, data.train_y))]
    count = np.zeros(len(groups), dtype=int)
    for fit, held, _ in split:
        if set(groups[fit]) & set(groups[held]):
            raise ValueError("source groups cross OOF boundary")
        if np.bincount(data.train_y[fit], minlength=len(data.classes)).min() < 2:
            raise ValueError("fold fit lacks two observations per class; no retry")
        count[held] += 1
    if not np.all(count == 1):
        raise ValueError("OOF must cover each record exactly once")
    return split


def standardize_fit(x, fit):
    values = x[fit].astype(np.float64)
    mean = values.mean(axis=(0, 2), keepdims=True)
    std = values.std(axis=(0, 2), keepdims=True)
    constant = std < 1e-12
    result = ((x.astype(np.float64) - mean) / np.where(constant, 1., std))
    result[:, constant.ravel(), :] = 0.
    return result.astype(np.float32), {"mean": mean.ravel().tolist(), "std": std.ravel().tolist(),
        "zeroed_channels": np.flatnonzero(constant.ravel()).tolist()}


def lift_low(low, ratio):
    length = math.floor((low.shape[-1] - 1) / ratio) + 1
    pos = torch.arange(length, device=low.device, dtype=torch.float64) * ratio
    left = pos.floor().long()
    right = (left + 1).clamp_max(low.shape[-1] - 1)
    weight = (pos - left).to(low.dtype)
    return low[..., left] * (1 - weight) + low[..., right] * weight


def views(x, rate, ratio):
    spec = AcquisitionSpec(ratio, 0., .8)
    low, low_rate, _ = spec.apply(x, rate)
    lifted = lift_low(low, ratio)
    length = lifted.shape[-1]
    kernel = spec.kernel(device=x.device, dtype=x.dtype)
    filtered = F.conv1d(x, kernel[None, None].expand(x.shape[1], 1, -1), groups=x.shape[1])
    result = {"high_reference": (x[..., MARGIN:MARGIN + length], rate),
        "filtered_dense": (filtered[..., MARGIN - 15:MARGIN - 15 + length], rate),
        "canonical_low": (low, low_rate), "lifted_low": (lifted, rate)}
    for name, phase, rolloff, window in (("phase_only", .5, .8, "hamming"),
            ("filter_only", 0., .95, "hamming"), ("joint", .5, .95, "hamming"),
            ("window_only", 0., .8, "hann")):
        v, f, _ = AcquisitionSpec(ratio, phase, rolloff, window).apply(x, rate)
        result[name] = v, f
    return result


def energy_descriptors(x, ratio):
    cropped = nominal_view(x).double()
    n = cropped.shape[-1]
    detrended = cropped - cropped.mean(-1, keepdim=True)
    fft = torch.fft.rfft(detrended * torch.hann_window(n, periodic=False, dtype=torch.float64, device=x.device))
    power = fft.abs().square().sum(1)
    multiplicity = torch.full_like(power, 2.)
    multiplicity[:, 0] = 1.
    if n % 2 == 0:
        multiplicity[:, -1] = 1.
    power = power * multiplicity
    energy = power.sum(-1)
    freq = torch.fft.rfftfreq(n, device=x.device)
    h = AcquisitionSpec(ratio, 0., .8).kernel(device=x.device, dtype=torch.float64)
    response = torch.fft.rfft(h, n=n).abs().square()
    high = power[:, freq > ratio / 2].sum(-1) / energy.clamp_min(1e-20)
    transmitted = (power * response).sum(-1) / energy.clamp_min(1e-20)
    return {"above_low_nyquist": high.cpu().tolist(), "transmitted_energy": transmitted.cpu().tolist(),
        "dynamic_energy_present": (energy > 1e-20).cpu().tolist()}


def error_masks(correct):
    h, c = correct["high_reference"], correct["canonical_low"]
    robust = np.logical_and.reduce([correct[k] for k in ("phase_only", "filter_only", "joint", "window_only")])
    return {"baseline_wrong": ~h, "rate_added": h & ~c, "nuisance_added": h & c & ~robust,
        "stable": h & c & robust, "baseline_rescued": ~h & c,
        "rate_lift_repaired": h & ~c & correct["lifted_low"],
        "rate_filter_wrong": h & ~c & ~correct["filtered_dense"],
        "rate_filter_correct_lift_repaired": h & ~c & correct["filtered_dense"] & correct["lifted_low"]}
