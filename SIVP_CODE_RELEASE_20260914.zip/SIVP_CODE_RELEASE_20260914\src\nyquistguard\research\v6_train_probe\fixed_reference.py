"""Fixed-common-support views for the TRAIN-only OOF reference re-audit.

This module is isolated from the completed OOF run.  It reuses the registered
finite acquisition operators but makes the high-rate reference and physical
endpoints identical across every evaluated rate.
"""

from __future__ import annotations

from dataclasses import asdict, dataclass
from fractions import Fraction
import math
from functools import reduce

import torch
from torch import Tensor
import torch.nn.functional as F

from nyquistguard.research.v6_envelope.operators import AcquisitionSpec, MARGIN, nominal_view


@dataclass(frozen=True)
class CommonSupport:
    source_length: int
    margin: int
    denominator_lcm: int
    dense_span_source_intervals: int
    dense_length: int
    low_lengths: dict[str, int]
    original_supported_dense_lengths: dict[str, int]

    def to_dict(self) -> dict:
        return asdict(self)


def _fraction(ratio: float) -> Fraction:
    if not math.isfinite(ratio) or not 0.0 < ratio <= 1.0:
        raise ValueError("ratios must be finite and in (0,1]")
    return Fraction(str(float(ratio))).limit_denominator(10_000)


def common_support(source_length: int, ratios: tuple[float, ...]) -> CommonSupport:
    """Choose the longest endpoint-aligned dense support shared by all grids."""

    if source_length - 2 * MARGIN < 8 or not ratios or len(set(ratios)) != len(ratios):
        raise ValueError("invalid source length or registered ratios")
    fractions = [_fraction(ratio) for ratio in ratios]
    denominator_lcm = reduce(math.lcm, (value.denominator for value in fractions), 1)
    interior = source_length - 2 * MARGIN
    original_lengths: dict[str, int] = {}
    spans: list[int] = []
    for ratio, value in zip(ratios, fractions, strict=True):
        low_length = (interior * value.numerator) // value.denominator
        if low_length < 2:
            raise ValueError("ratio leaves fewer than two observed samples")
        span = ((low_length - 1) * value.denominator) // value.numerator
        original_lengths[str(ratio)] = span + 1
        spans.append(span)
    common_span = (min(spans) // denominator_lcm) * denominator_lcm
    if common_span < denominator_lcm:
        raise ValueError("common endpoint-aligned support is too short")
    low_lengths: dict[str, int] = {}
    for ratio, value in zip(ratios, fractions, strict=True):
        scaled = common_span * value
        if scaled.denominator != 1:
            raise RuntimeError("common span did not align to a registered grid")
        low_lengths[str(ratio)] = int(scaled) + 1
    return CommonSupport(
        source_length=int(source_length),
        margin=MARGIN,
        denominator_lcm=denominator_lcm,
        dense_span_source_intervals=common_span,
        dense_length=common_span + 1,
        low_lengths=low_lengths,
        original_supported_dense_lengths=original_lengths,
    )


def lift_to_common_support(low: Tensor, ratio: float, dense_length: int) -> Tensor:
    """Piecewise-linearly evaluate low samples on a fixed nominal-rate grid."""

    if low.ndim != 3 or not low.is_floating_point() or dense_length < 2:
        raise ValueError("need floating low Tensor[B,C,T] and dense_length >= 2")
    position = torch.arange(dense_length, device=low.device, dtype=torch.float64) * ratio
    if float(position[-1]) > low.shape[-1] - 1 + 1e-10:
        raise ValueError("reconstruction would extrapolate beyond observed low samples")
    left = position.floor().long().clamp_max(low.shape[-1] - 1)
    right = (left + 1).clamp_max(low.shape[-1] - 1)
    weight = (position - left).to(low.dtype)
    return low[..., left] * (1 - weight) + low[..., right] * weight


def _cropped_acquisition(x: Tensor, source_rate_hz: float, spec: AcquisitionSpec, length: int) -> tuple[Tensor, float]:
    viewed, rate, _ = spec.apply(x, source_rate_hz)
    if viewed.shape[-1] < length:
        raise ValueError("registered acquisition does not cover fixed common support")
    return viewed[..., :length], rate


def fixed_common_support_views(
    x: Tensor,
    source_rate_hz: float,
    ratios: tuple[float, ...],
) -> tuple[tuple[Tensor, float], dict[float, dict[str, tuple[Tensor, float]]], CommonSupport]:
    """Return one fixed high reference plus ratio-specific aligned conditions.

    The returned high-rate tensor is evaluated once.  Each canonical low-rate
    grid begins and ends at the same physical coordinates as that tensor.
    Phase perturbations intentionally shift the grid within the available valid
    support while retaining the registered number of samples.
    """

    nominal_view(x)
    if not math.isfinite(source_rate_hz) or source_rate_hz <= 0:
        raise ValueError("source_rate_hz must be finite and positive")
    layout = common_support(int(x.shape[-1]), ratios)
    high = x[..., MARGIN : MARGIN + layout.dense_length]
    if high.shape[-1] != layout.dense_length:
        raise RuntimeError("fixed high-rate crop is incomplete")
    by_ratio: dict[float, dict[str, tuple[Tensor, float]]] = {}
    for ratio in ratios:
        low_length = layout.low_lengths[str(ratio)]
        canonical_spec = AcquisitionSpec(ratio, 0.0, 0.8)
        canonical, low_rate = _cropped_acquisition(x, source_rate_hz, canonical_spec, low_length)
        lifted = lift_to_common_support(canonical, ratio, layout.dense_length)
        kernel = canonical_spec.kernel(device=x.device, dtype=x.dtype)
        filtered = F.conv1d(
            x,
            kernel[None, None].expand(x.shape[1], 1, -1),
            groups=x.shape[1],
        )
        filtered_dense = filtered[
            ..., MARGIN - 15 : MARGIN - 15 + layout.dense_length
        ]
        conditions: dict[str, tuple[Tensor, float]] = {
            "filtered_dense": (filtered_dense, source_rate_hz),
            "canonical_low": (canonical, low_rate),
            "lifted_low": (lifted, source_rate_hz),
        }
        for name, phase, rolloff, window in (
            ("phase_only", 0.5, 0.8, "hamming"),
            ("filter_only", 0.0, 0.95, "hamming"),
            ("joint", 0.5, 0.95, "hamming"),
            ("window_only", 0.0, 0.8, "hann"),
        ):
            conditions[name] = _cropped_acquisition(
                x,
                source_rate_hz,
                AcquisitionSpec(ratio, phase, rolloff, window),
                low_length,
            )
        for name in ("filtered_dense", "lifted_low"):
            if conditions[name][0].shape[-1] != high.shape[-1]:
                raise RuntimeError(f"{name} does not share the fixed dense support")
        by_ratio[ratio] = conditions
    return (high, float(source_rate_hz)), by_ratio, layout

