"""TRAIN-only loading and subject-disjoint folds for the SIVP attribution extension."""

from __future__ import annotations

from dataclasses import dataclass
import math
from pathlib import Path
import re
import zipfile

import numpy as np
from sklearn.model_selection import StratifiedGroupKFold

from nyquistguard.research.v6.runner import _cap
from nyquistguard.research.v6_envelope.operators import MARGIN


REGISTERED = {
    "mhealth_uci": {
        "grouping": "mhealth_subject_prefix",
        "folds": "leave_one_subject_out",
    },
    "eegmmi_physionet": {
        "grouping": "eegmmi_subject_prefix",
        "folds": "stratified_group_5fold",
    },
}


@dataclass(frozen=True)
class TrainOnlyData:
    dataset_id: str
    rate: float
    classes: tuple[str, ...]
    train_x: np.ndarray
    train_y: np.ndarray
    train_ids: np.ndarray
    groups: np.ndarray


def _member_shape_dtype(archive: zipfile.ZipFile, name: str) -> tuple[tuple[int, ...], np.dtype]:
    with archive.open(name + ".npy") as member:
        version = np.lib.format.read_magic(member)
        if version == (1, 0):
            shape, _, dtype = np.lib.format.read_array_header_1_0(member)
        elif version == (2, 0):
            shape, _, dtype = np.lib.format.read_array_header_2_0(member)
        else:
            raise ValueError("unsupported TRAIN array header")
    return tuple(shape), np.dtype(dtype)


def subject_groups(dataset_id: str, ids: np.ndarray) -> np.ndarray:
    values = np.asarray(ids).astype(str)
    if dataset_id == "mhealth_uci":
        groups = []
        for value in values:
            match = re.fullmatch(r"(mHealth_subject\d+):\d+:\d+", value)
            if match is None:
                raise ValueError(f"unregistered MHEALTH TRAIN identifier: {value}")
            groups.append(match.group(1))
        result = np.asarray(groups)
        expected = {f"mHealth_subject{number}" for number in range(1, 7)}
        if set(result) != expected:
            raise ValueError("MHEALTH TRAIN cap must retain all six registered subjects")
        return result
    if dataset_id == "eegmmi_physionet":
        groups = []
        for value in values:
            match = re.fullmatch(r"(S\d{3})R\d{2}:trial\d+:T[12]", value)
            if match is None:
                raise ValueError(f"unregistered EEGMMI TRAIN identifier: {value}")
            groups.append(match.group(1))
        result = np.asarray(groups)
        if len(set(result)) < 25:
            raise ValueError("EEGMMI TRAIN cap retains too few independent subjects")
        return result
    raise ValueError("dataset is outside the frozen cross-task extension")


def load_train_only(path: Path, dataset_id: str, cap: int, seed: int) -> TrainOnlyData:
    """Materialize registered metadata and TRAIN members, never validation or TEST."""

    if dataset_id not in REGISTERED:
        raise ValueError("dataset is outside the frozen cross-task extension")
    required = ("train_x", "train_y", "train_ids")
    input_bytes = 0
    with zipfile.ZipFile(path) as archive:
        for name in required:
            shape, dtype = _member_shape_dtype(archive, name)
            if dtype.hasobject:
                raise ValueError("object TRAIN arrays are forbidden")
            input_bytes += math.prod(shape) * dtype.itemsize
    if input_bytes > 2 * 2**30:
        raise MemoryError("TRAIN members exceed the 2 GiB loader limit")

    with np.load(path, allow_pickle=False) as payload:
        observed_id = str(payload["dataset_id"].item())
        rate = float(payload["sampling_rate_hz"].item())
        classes = tuple(payload["class_names"].astype(str).tolist())
        labels = np.asarray(payload["train_y"])
        ids = payload["train_ids"].astype(str)
        selected = _cap(labels, int(cap), int(seed))
        source = payload["train_x"]
        if source.ndim != 3 or source.dtype != np.float32 or len(source) != len(labels):
            raise ValueError("invalid TRAIN tensor")
        values = source[selected].copy()

    if observed_id != dataset_id or not math.isfinite(rate) or rate <= 0:
        raise ValueError("TRAIN cache identity or sampling rate is invalid")
    if labels.ndim != 1 or ids.shape != labels.shape or len(set(ids.tolist())) != len(ids):
        raise ValueError("invalid TRAIN labels or identifiers")
    if len(classes) < 2 or set(np.unique(labels)) != set(range(len(classes))):
        raise ValueError("TRAIN does not cover the registered vocabulary")
    selected_labels = labels[selected].astype(np.int64, copy=True)
    selected_ids = ids[selected].copy()
    if set(np.unique(selected_labels)) != set(range(len(classes))):
        raise ValueError("TRAIN cap lost a registered class")
    if not np.isfinite(values).all() or values.shape[-1] - 2 * MARGIN < 8:
        raise ValueError("TRAIN values are nonfinite or too short")
    groups = subject_groups(dataset_id, selected_ids)
    return TrainOnlyData(
        dataset_id=dataset_id,
        rate=rate,
        classes=classes,
        train_x=values,
        train_y=selected_labels,
        train_ids=selected_ids,
        groups=groups,
    )


def grouped_folds(data: TrainOnlyData, strategy: str, seed: int) -> list[tuple[np.ndarray, np.ndarray, str]]:
    """Return deterministic subject-disjoint OOF folds covering every selected record once."""

    registered = REGISTERED[data.dataset_id]["folds"]
    if strategy != registered:
        raise ValueError("fold strategy differs from the frozen dataset registration")
    groups = data.groups
    if strategy == "leave_one_subject_out":
        split = [
            (np.flatnonzero(groups != group), np.flatnonzero(groups == group), group)
            for group in sorted(set(groups.tolist()))
        ]
    else:
        splitter = StratifiedGroupKFold(n_splits=5, shuffle=True, random_state=int(seed))
        split = [
            (fit.astype(np.int64), held.astype(np.int64), f"subject_fold_{index}")
            for index, (fit, held) in enumerate(splitter.split(data.train_y, data.train_y, groups))
        ]

    coverage = np.zeros(len(data.train_y), dtype=np.int64)
    for fit, held, _ in split:
        if not len(fit) or not len(held):
            raise ValueError("empty OOF fit or held-out partition")
        if set(groups[fit].tolist()) & set(groups[held].tolist()):
            raise ValueError("subject crossed an OOF boundary")
        if np.bincount(data.train_y[fit], minlength=len(data.classes)).min() < 2:
            raise ValueError("OOF fit partition lacks two examples of a class")
        coverage[held] += 1
    if not np.all(coverage == 1):
        raise ValueError("OOF folds do not cover each selected record exactly once")
    return split

