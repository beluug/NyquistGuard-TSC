"""CLI entry point for the frozen SIVP cross-task TRAIN-only OOF extension."""

from nyquistguard.research.sivp_attribution_extension.runner import main


if __name__ == "__main__":
    main()
