"""Validation-only analysis of the exhausted SIVP epoch-60 extension."""

from __future__ import annotations

import argparse
from collections import defaultdict
import json
from pathlib import Path

import numpy as np
from scipy.stats import wilcoxon

from .analysis import CELL_KEYS, CONTRASTS, _bootstrap_mean_interval, holm_adjust


def _key(row: dict) -> tuple[str, str, str, int]:
    return row["dataset_id"], row["family"], row["regime"], int(row["seed"])


def _safe_wilcoxon(values: np.ndarray) -> tuple[float, float]:
    if np.all(values == 0):
        return 0.0, 1.0
    test = wilcoxon(values, zero_method="wilcox", alternative="two-sided", method="auto")
    return float(test.statistic), float(test.pvalue)


def _validate(extension_report: dict, source_report: dict) -> tuple[list[dict], list[dict]]:
    if extension_report.get("test_accessed") is not False:
        raise ValueError("extension analysis rejected because TEST-access state is not false")
    if extension_report.get("retrospective_test_permitted") is not False:
        raise ValueError("extension analysis expects the frozen TEST gate to remain closed")
    if extension_report.get("status") != "completed_extension_undertrained":
        raise ValueError("extension report is not the exhausted undertraining result")
    if source_report.get("test_accessed") is not False:
        raise ValueError("source analysis rejected because TEST-access state is not false")
    extension_rows = extension_report.get("rows", [])
    source_rows = source_report.get("rows", [])
    if len(extension_rows) != 120 or len(source_rows) != 120:
        raise ValueError("epoch-45 and epoch-60 reports must each contain 120 cells")
    if any(
        row.get("status") != "completed_extension" or row.get("test_accessed") is not False
        for row in extension_rows
    ):
        raise ValueError("extension row is incomplete or has an invalid TEST state")
    if any(
        row.get("status") != "completed" or row.get("test_accessed") is not False
        for row in source_rows
    ):
        raise ValueError("source row is incomplete or has an invalid TEST state")
    if {_key(row) for row in extension_rows} != {_key(row) for row in source_rows}:
        raise ValueError("epoch-45 and epoch-60 cell identities differ")
    return extension_rows, source_rows


def _cell_means(rows: list[dict]) -> dict[str, dict[str, float]]:
    grouped: dict[str, dict[str, list[dict]]] = defaultdict(lambda: defaultdict(list))
    for row in rows:
        grouped[row["dataset_id"]][f"{row['family']}_{row['regime']}"] .append(row)
    if len(grouped) != 10:
        raise ValueError(f"expected ten datasets, found {len(grouped)}")
    means = {}
    for dataset_id, cells in grouped.items():
        if set(cells) != set(CELL_KEYS) or any(len(cells[key]) != 3 for key in CELL_KEYS):
            raise ValueError(f"unbalanced extension cells for {dataset_id}")
        means[dataset_id] = {
            key: float(np.mean([
                row["validation"]["mean_unseen_macro_f1"] for row in cells[key]
            ]))
            for key in CELL_KEYS
        }
    return means


def _comparisons(
    means: dict[str, dict[str, float]], *, bootstrap_seed: int
) -> tuple[list[dict], np.ndarray]:
    dataset_order = list(means)
    comparison_rows = []
    arrays = []
    for index, (name, left, right) in enumerate(CONTRASTS):
        values = np.asarray([
            means[dataset_id][left] - means[dataset_id][right]
            for dataset_id in dataset_order
        ], dtype=np.float64)
        statistic, p_value = _safe_wilcoxon(values)
        arrays.append(values)
        comparison_rows.append({
            "contrast": name,
            "left": left,
            "right": right,
            "dataset_effects": dict(zip(dataset_order, values.tolist())),
            "mean": float(values.mean()),
            "median": float(np.median(values)),
            "positive_dataset_count": int(np.sum(values > 0)),
            "negative_dataset_count": int(np.sum(values < 0)),
            "zero_dataset_count": int(np.sum(values == 0)),
            "wilcoxon_statistic": statistic,
            "p_raw": p_value,
            "bootstrap_95_interval": _bootstrap_mean_interval(values, bootstrap_seed + index),
        })
    for row, adjusted in zip(
        comparison_rows, holm_adjust(item["p_raw"] for item in comparison_rows)
    ):
        row["p_holm"] = adjusted
    return comparison_rows, arrays[1] - arrays[0]


def _undertraining(rows_60: list[dict], rows_45: list[dict]) -> dict:
    old = {_key(row): bool(row["undertraining"]["flagged"]) for row in rows_45}
    new = {_key(row): bool(row["undertraining"]["flagged"]) for row in rows_60}
    transitions = {
        "flagged_to_flagged": sum(old[key] and new[key] for key in old),
        "flagged_to_clear": sum(old[key] and not new[key] for key in old),
        "clear_to_flagged": sum(not old[key] and new[key] for key in old),
        "clear_to_clear": sum(not old[key] and not new[key] for key in old),
    }
    trigger_counts = {
        "best_epoch_only": 0,
        "loss_decrease_only": 0,
        "both": 0,
    }
    by_dataset: dict[str, dict[str, int]] = defaultdict(
        lambda: {"flagged": 0, "best_epoch": 0, "loss_decrease": 0}
    )
    by_condition: dict[str, dict[str, int]] = defaultdict(
        lambda: {"flagged": 0, "best_epoch": 0, "loss_decrease": 0}
    )
    flagged_relative = []
    flagged_absolute = []
    ceiling = 0
    flat_final_five = 0
    for row in rows_60:
        under = row["undertraining"]
        if not under["flagged"]:
            continue
        best = bool(under["best_epoch_in_final_window"])
        loss = bool(under["loss_still_decreasing"])
        trigger_counts["both" if best and loss else "best_epoch_only" if best else "loss_decrease_only"] += 1
        condition = f"{row['family']}_{row['regime']}"
        for target in (by_dataset[row["dataset_id"]], by_condition[condition]):
            target["flagged"] += 1
            target["best_epoch"] += int(best)
            target["loss_decrease"] += int(loss)
        flagged_relative.append(float(under["final_loss_relative_decrease"]))
        history = row["history"]
        first = float(np.mean([item["train_loss"] for item in history[-5:-3]]))
        last = float(np.mean([item["train_loss"] for item in history[-2:]]))
        flagged_absolute.append(first - last)
        validation = row["validation"]
        if (
            float(validation["full_rate_macro_f1"]) == 1.0
            and float(validation["mean_unseen_macro_f1"]) == 1.0
        ):
            ceiling += 1
        final_scores = [float(item["validation_selection_score"]) for item in history[-5:]]
        if max(final_scores) - min(final_scores) <= 1e-12:
            flat_final_five += 1
    return {
        "epoch45_flagged_cells": int(sum(old.values())),
        "epoch60_flagged_cells": int(sum(new.values())),
        "transitions": transitions,
        "epoch60_trigger_counts": trigger_counts,
        "affected_datasets": sorted({
            row["dataset_id"] for row in rows_60 if row["undertraining"]["flagged"]
        }),
        "by_dataset": dict(sorted(by_dataset.items())),
        "by_condition": dict(sorted(by_condition.items())),
        "flagged_with_exact_validation_ceiling": ceiling,
        "flagged_with_flat_final_five_validation_scores": flat_final_five,
        "flagged_relative_loss_decrease": {
            "median": float(np.median(flagged_relative)),
            "minimum": float(np.min(flagged_relative)),
            "maximum": float(np.max(flagged_relative)),
        },
        "flagged_absolute_loss_decrease": {
            "median": float(np.median(flagged_absolute)),
            "minimum": float(np.min(flagged_absolute)),
            "maximum": float(np.max(flagged_absolute)),
        },
        "one_time_extension_exhausted": True,
        "retrospective_test_permitted": False,
    }


def analyze_extension(
    extension_report: dict, source_report: dict, *, bootstrap_seed: int = 17
) -> dict:
    rows_60, rows_45 = _validate(extension_report, source_report)
    means_60 = _cell_means(rows_60)
    means_45 = _cell_means(rows_45)
    comparisons_60, interaction_60 = _comparisons(means_60, bootstrap_seed=bootstrap_seed)
    comparisons_45, interaction_45 = _comparisons(means_45, bootstrap_seed=bootstrap_seed)
    for current, prior in zip(comparisons_60, comparisons_45):
        current["epoch45_mean"] = prior["mean"]
        current["mean_change_from_epoch45"] = current["mean"] - prior["mean"]
    dataset_order = list(means_60)
    source_by_key = {_key(row): row for row in rows_45}
    selection_deltas = np.asarray([
        row["validation"]["selection_score"]
        - source_by_key[_key(row)]["validation"]["selection_score"]
        for row in rows_60
    ], dtype=np.float64)
    unseen_deltas = np.asarray([
        row["validation"]["mean_unseen_macro_f1"]
        - source_by_key[_key(row)]["validation"]["mean_unseen_macro_f1"]
        for row in rows_60
    ], dtype=np.float64)
    new_best = [row for row in rows_60 if int(row["best_epoch"]) > 45]
    source_retries = sum(int(row.get("source_numerical_retry_count", 0)) for row in rows_60)
    extension_retries = sum(int(row.get("extension_numerical_retry_count", 0)) for row in rows_60)
    return {
        "status": "validation_only_extension_exhausted",
        "inferential_status": "provisional_because_undertraining_gate_failed",
        "protocol_hash": extension_report["protocol_hash"],
        "plan_hash": extension_report["plan_hash"],
        "merge_input_hash": extension_report["merge_input_hash"],
        "merge_audit_version": extension_report.get("merge_audit_version"),
        "completed_cells": len(rows_60),
        "dataset_count": len(means_60),
        "statistical_unit": "dataset; three seeds averaged within each condition",
        "outcome": "mean unseen-rate macro-F1 over ratios 0.9, 0.6, 0.4, and 0.3",
        "bootstrap_resamples": 10_000,
        "bootstrap_seed": bootstrap_seed,
        "cell_means": means_60,
        "primary_comparisons": comparisons_60,
        "interaction": {
            "dataset_effects": dict(zip(dataset_order, interaction_60.tolist())),
            "mean": float(interaction_60.mean()),
            "median": float(np.median(interaction_60)),
            "positive_dataset_count": int(np.sum(interaction_60 > 0)),
            "bootstrap_95_interval": _bootstrap_mean_interval(interaction_60, bootstrap_seed + 4),
            "epoch45_mean": float(interaction_45.mean()),
            "mean_change_from_epoch45": float(interaction_60.mean() - interaction_45.mean()),
            "inferential_status": "descriptive_by_protocol",
        },
        "undertraining": _undertraining(rows_60, rows_45),
        "convergence_from_epoch45": {
            "new_best_checkpoint_cells": len(new_best),
            "new_best_checkpoint_by_condition": {
                key: sum(
                    f"{row['family']}_{row['regime']}" == key for row in new_best
                ) for key in CELL_KEYS
            },
            "selection_score": {
                "improved_cells": int(np.sum(selection_deltas > 1e-12)),
                "unchanged_cells": int(np.sum(np.abs(selection_deltas) <= 1e-12)),
                "decreased_cells": int(np.sum(selection_deltas < -1e-12)),
                "mean_change": float(selection_deltas.mean()),
                "median_change": float(np.median(selection_deltas)),
                "maximum_change": float(selection_deltas.max()),
            },
            "mean_unseen_macro_f1": {
                "improved_cells": int(np.sum(unseen_deltas > 1e-12)),
                "unchanged_cells": int(np.sum(np.abs(unseen_deltas) <= 1e-12)),
                "decreased_cells": int(np.sum(unseen_deltas < -1e-12)),
                "mean_change": float(unseen_deltas.mean()),
                "median_change": float(np.median(unseen_deltas)),
                "minimum_change": float(unseen_deltas.min()),
                "maximum_change": float(unseen_deltas.max()),
            },
        },
        "numerical_retries": {
            "source_epochs_1_to_45": int(source_retries),
            "extension_epochs_46_to_60": int(extension_retries),
            "total": int(source_retries + extension_retries),
            "extension_cells_with_retry": sum(
                int(row.get("extension_numerical_retry_count", 0)) > 0 for row in rows_60
            ),
            "maximum_extension_retries_in_one_cell": max(
                int(row.get("extension_numerical_retry_count", 0)) for row in rows_60
            ),
        },
        "retrospective_test_permitted": False,
        "test_accessed": False,
    }


def render_markdown(result: dict, run_directory: Path) -> str:
    under = result["undertraining"]
    transitions = under["transitions"]
    triggers = under["epoch60_trigger_counts"]
    lines = [
        "# SIVP decisive controls: exhausted epoch-60 validation audit",
        "",
        f"Source: `{run_directory}`  ",
        f"Protocol hash: `{result['protocol_hash']}`  ",
        f"Plan hash: `{result['plan_hash']}`  ",
        "Scope: TRAIN/validation only; TEST was not accessed.",
        "",
        "## Frozen decision",
        "",
        f"All {result['completed_cells']} cells completed across {result['dataset_count']} datasets. "
        f"The epoch-60 rule still flags {under['epoch60_flagged_cells']} cells across "
        f"{len(under['affected_datasets'])} datasets. The one-time extension is exhausted, "
        "retrospective TEST remains blocked, and a second epoch extension is not permitted. "
        "All comparisons below are validation-only and provisional.",
        "",
        "## Undertraining transition and trigger audit",
        "",
        "| Epoch 45 state | Epoch 60 state | Cells |",
        "|---|---|---:|",
        f"| Flagged | Flagged | {transitions['flagged_to_flagged']} |",
        f"| Flagged | Clear | {transitions['flagged_to_clear']} |",
        f"| Clear | Flagged | {transitions['clear_to_flagged']} |",
        f"| Clear | Clear | {transitions['clear_to_clear']} |",
        "",
        "| Epoch-60 trigger | Cells |",
        "|---|---:|",
        f"| Final-three best epoch only | {triggers['best_epoch_only']} |",
        f"| Final-five loss decrease only | {triggers['loss_decrease_only']} |",
        f"| Both triggers | {triggers['both']} |",
        "",
        f"Among the flagged cells, {under['flagged_with_exact_validation_ceiling']} have exact "
        "full-rate and mean unseen-rate macro-F1 of 1.0, and "
        f"{under['flagged_with_flat_final_five_validation_scores']} have an exactly flat selection "
        "score across the final five epochs. These are descriptive diagnostics and do not override "
        "the frozen stopping rule.",
        "",
        "## Three-seed mean unseen-rate macro-F1 at epoch 60",
        "",
        "| Dataset | O-N | O-M | P-N | P-M |",
        "|---|---:|---:|---:|---:|",
    ]
    for dataset_id, cells in result["cell_means"].items():
        lines.append(
            f"| {dataset_id} | {cells['ordinary_nominal']:.4f} | "
            f"{cells['ordinary_multirate']:.4f} | {cells['physical_nominal']:.4f} | "
            f"{cells['physical_multirate']:.4f} |"
        )
    lines.extend([
        "",
        "## Prespecified four-comparison family",
        "",
        "| Contrast | Mean | Epoch-45 mean | Change | Median | +/0/- datasets | Bootstrap 95% interval | Raw p | Holm p |",
        "|---|---:|---:|---:|---:|---:|---:|---:|---:|",
    ])
    for row in result["primary_comparisons"]:
        lower, upper = row["bootstrap_95_interval"]
        lines.append(
            f"| {row['contrast']} | {row['mean']:+.4f} | {row['epoch45_mean']:+.4f} | "
            f"{row['mean_change_from_epoch45']:+.4f} | {row['median']:+.4f} | "
            f"{row['positive_dataset_count']}/{row['zero_dataset_count']}/"
            f"{row['negative_dataset_count']} | [{lower:+.4f}, {upper:+.4f}] | "
            f"{row['p_raw']:.4f} | {row['p_holm']:.4f} |"
        )
    lower, upper = result["interaction"]["bootstrap_95_interval"]
    convergence = result["convergence_from_epoch45"]
    lines.extend([
        "",
        f"The prespecified descriptive interaction is {result['interaction']['mean']:+.4f} "
        f"(dataset-bootstrap 95% interval [{lower:+.4f}, {upper:+.4f}]; "
        f"{result['interaction']['positive_dataset_count']}/10 datasets positive).",
        "",
        "## What changed from epoch 45 to epoch 60",
        "",
        f"Only {convergence['new_best_checkpoint_cells']}/120 cells selected a new best checkpoint "
        "after epoch 45. The frozen selection score improved in "
        f"{convergence['selection_score']['improved_cells']} cells, was unchanged in "
        f"{convergence['selection_score']['unchanged_cells']}, and decreased in "
        f"{convergence['selection_score']['decreased_cells']}; its mean change was "
        f"{convergence['selection_score']['mean_change']:+.4f}. Mean unseen-rate macro-F1 improved "
        f"in {convergence['mean_unseen_macro_f1']['improved_cells']} cells, was unchanged in "
        f"{convergence['mean_unseen_macro_f1']['unchanged_cells']}, and decreased in "
        f"{convergence['mean_unseen_macro_f1']['decreased_cells']}; its mean change was "
        f"{convergence['mean_unseen_macro_f1']['mean_change']:+.4f}.",
        "",
        "No p-value in this report licenses a confirmatory claim because the frozen undertraining "
        "gate failed. The results may be used for transparent validation-only interpretation and "
        "for designing a future independently preregistered experiment.",
        "",
        "## Numerical execution",
        "",
        f"The full 60-epoch histories contain {result['numerical_retries']['total']} recorded "
        "numerical scale-reduction retries: "
        f"{result['numerical_retries']['source_epochs_1_to_45']} in epochs 1--45 and "
        f"{result['numerical_retries']['extension_epochs_46_to_60']} in epochs 46--60. "
        "The audited same-batch replay policy preserved one successful optimizer update per batch. "
        "TEST remained inaccessible throughout training, merge recovery, and this analysis.",
        "",
    ])
    return "\n".join(lines)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--run", type=Path, required=True)
    parser.add_argument("--source-run", type=Path, required=True)
    parser.add_argument(
        "--output-dir", type=Path,
        default=Path("reports/sivp_decisive_controls/validation_60epoch"),
    )
    args = parser.parse_args()
    run_directory = args.run.resolve()
    source_directory = args.source_run.resolve()
    extension_report = json.loads(
        (run_directory / "report.json").read_text(encoding="utf-8")
    )
    source_report = json.loads(
        (source_directory / "report.json").read_text(encoding="utf-8")
    )
    result = analyze_extension(extension_report, source_report)
    output = args.output_dir.resolve()
    output.mkdir(parents=True, exist_ok=True)
    (output / "analysis.json").write_text(
        json.dumps(result, indent=2, ensure_ascii=False, allow_nan=False), encoding="utf-8"
    )
    (output / "REPORT.md").write_text(
        render_markdown(result, run_directory), encoding="utf-8"
    )
    print(json.dumps({
        "status": result["status"],
        "completed_cells": result["completed_cells"],
        "undertrained_cells": result["undertraining"]["epoch60_flagged_cells"],
        "affected_datasets": len(result["undertraining"]["affected_datasets"]),
        "retrospective_test_permitted": result["retrospective_test_permitted"],
        "output_directory": str(output),
        "test_accessed": result["test_accessed"],
    }, indent=2))


if __name__ == "__main__":
    main()
