"""Read-only recovery of the completed SIVP three-shard merge.

The original sharding execution is immutable.  Its merger compared a checkpoint's
cell-level source protocol identity with the plan-level amended source-run identity.
This module preserves and revalidates the frozen plan and every produced artifact,
then applies the corrected two-level identity check without training or TEST access.
"""

from __future__ import annotations

import hashlib
import json
from pathlib import Path

import torch

from . import extension_runner as extension
from . import extension_sharding as sharding


MERGE_AUDIT_VERSION = "sivp_extension_merge_source_identity_v2"


def _merge_audit_hash(root: Path) -> str:
    digest = hashlib.sha256()
    for path in (
        Path(__file__),
        root / "scripts/recover_sivp_extension_merge.py",
        root / "docs/SIVP_MERGE_IDENTITY_AMENDMENT.md",
    ):
        digest.update(sharding._portable_relative_identifier(root, path))
        digest.update(path.read_bytes())
    return digest.hexdigest()


def validate_source_identity_chain(
    *, source_report: dict, plan: dict, source_row: dict, row: dict,
    checkpoint: dict, cell_name: str,
) -> None:
    """Validate the distinct run-level and cell-level source identities."""
    if source_report.get("protocol_hash") != plan.get("source_protocol_hash"):
        raise ValueError("plan-level source protocol identity mismatch")
    cell_source_hash = source_row.get("protocol_hash")
    if not isinstance(cell_source_hash, str) or not cell_source_hash:
        raise ValueError(f"missing cell-level source protocol identity: {cell_name}")
    if row.get("source_protocol_hash") != cell_source_hash:
        raise ValueError(f"row cell-level source protocol identity mismatch: {cell_name}")
    if checkpoint.get("source_protocol_hash") != cell_source_hash:
        raise ValueError(f"checkpoint cell-level source protocol identity mismatch: {cell_name}")


def recover_merge(root: Path, distributed_directory: Path) -> dict:
    """Re-run the complete merge audit with the corrected identity relation."""
    root = root.resolve()
    directory, _, config, plan = sharding._load_distributed(root, distributed_directory)
    checked = extension.preflight(root, config)
    source_report = json.loads(
        (root / config["source_run"] / "report.json").read_text(encoding="utf-8")
    )
    source_rows = extension._source_rows(source_report)
    reports = []
    report_hashes = []
    for index in range(plan["num_shards"]):
        shard_directory = directory / f"shard_{index:02d}_of_{plan['num_shards']:02d}"
        report_path = shard_directory / "shard_report.json"
        if not report_path.is_file():
            raise ValueError(f"missing shard report: {index}")
        reports.append(json.loads(report_path.read_text(encoding="utf-8")))
        report_hashes.append(extension._sha256(report_path))

    rows = sharding.validate_collected_rows(
        plan, reports, protocol_hash=plan["protocol_hash"]
    )
    cell_locations: dict[str, str] = {}
    output_hashes: dict[str, dict[str, str]] = {}
    required = (
        "checkpoint_best.pt", "checkpoint_last.pt", "history.json",
        "schedule.json", "metrics.json",
    )
    for row in rows:
        key = sharding._cell_key(row)
        source_row = source_rows[key]
        group_key = sharding._group_key(row["dataset_id"], row["seed"])
        shard_index = next(
            shard["shard_index"] for shard in plan["shards"]
            if group_key in {group["group_key"] for group in shard["groups"]}
        )
        cell_name = (
            f"{row['dataset_id']}__{row['family']}_{row['regime']}__seed{row['seed']}"
        )
        cell_directory = (
            directory / f"shard_{shard_index:02d}_of_{plan['num_shards']:02d}" / cell_name
        )
        metrics = json.loads((cell_directory / "metrics.json").read_text(encoding="utf-8"))
        if metrics != row:
            raise ValueError(f"cell metrics differ from shard report: {cell_name}")
        if row.get("source_artifact_hashes") != checked["source_artifacts"][cell_name]:
            raise ValueError(f"cell source artifact hashes mismatch: {cell_name}")
        if (
            row.get("initial_state_hash") != source_row.get("initial_state_hash")
            or row.get("downstream_initial_state_hash")
            != source_row.get("downstream_initial_state_hash")
        ):
            raise ValueError(f"cell source initialization identity mismatch: {cell_name}")
        if not all((cell_directory / name).is_file() for name in required):
            raise ValueError(f"merged cell artifacts incomplete: {cell_name}")

        checkpoint = torch.load(
            cell_directory / "checkpoint_last.pt", map_location="cpu", weights_only=True
        )
        if (
            checkpoint.get("epoch") != plan["target_epoch"]
            or checkpoint.get("protocol_hash") != plan["protocol_hash"]
        ):
            raise ValueError(f"merged checkpoint extension identity mismatch: {cell_name}")
        validate_source_identity_chain(
            source_report=source_report, plan=plan, source_row=source_row,
            row=row, checkpoint=checkpoint, cell_name=cell_name,
        )
        if (
            checkpoint.get("best_epoch") != row.get("best_epoch")
            or abs(float(checkpoint.get("best_score")) - float(row["validation"]["selection_score"]))
            > 1e-12
        ):
            raise ValueError(f"merged checkpoint selection identity mismatch: {cell_name}")

        history = json.loads(
            (cell_directory / "history.json").read_text(encoding="utf-8")
        )["history"]
        expected_epochs = list(range(1, int(plan["target_epoch"]) + 1))
        if [item.get("epoch") for item in history] != expected_epochs:
            raise ValueError(f"merged history epoch sequence mismatch: {cell_name}")
        schedule_document = json.loads(
            (cell_directory / "schedule.json").read_text(encoding="utf-8")
        )
        if schedule_document.get("schedule_hash") != row.get("schedule_hash"):
            raise ValueError(f"merged schedule hash mismatch: {cell_name}")
        cell_locations[cell_name] = str(cell_directory.relative_to(directory))
        output_hashes[cell_name] = {
            name: extension._sha256(cell_directory / name) for name in required
        }

    for dataset_id, seed in sorted(
        {(row["dataset_id"], int(row["seed"])) for row in rows}
    ):
        paired = [
            row for row in rows
            if row["dataset_id"] == dataset_id and int(row["seed"]) == seed
        ]
        if len(paired) != 4 or len(
            {row["downstream_initial_state_hash"] for row in paired}
        ) != 1:
            raise ValueError(f"merged paired initialization mismatch: {dataset_id}/seed{seed}")
        schedule_values = []
        for row in paired:
            cell_name = (
                f"{row['dataset_id']}__{row['family']}_{row['regime']}__seed{row['seed']}"
            )
            schedule = json.loads(
                (directory / cell_locations[cell_name] / "schedule.json").read_text(
                    encoding="utf-8"
                )
            )["schedule"]
            schedule_values.append([item["scheduled_ratio"] for item in schedule])
        if any(values != schedule_values[0] for values in schedule_values[1:]):
            raise ValueError(f"merged paired schedule mismatch: {dataset_id}/seed{seed}")

    merge_input_hash = sharding._canonical_hash({
        "plan_hash": plan["plan_hash"],
        "shard_report_hashes": report_hashes,
        "output_artifact_hashes": output_hashes,
    })
    remaining = [
        f"{row['dataset_id']}/{row['family']}_{row['regime']}/seed{row['seed']}"
        for row in rows if row["undertraining"]["flagged"]
    ]
    status = "completed_extension_undertrained" if remaining else "completed_extension"
    audit_hash = _merge_audit_hash(root)
    report = {
        "protocol_version": config["protocol_version"],
        "protocol_hash": plan["protocol_hash"],
        "scope": config["scope"],
        "source_run": config["source_run"],
        "source_epoch": config["source_epoch"],
        "target_epoch": config["target_epoch"],
        "expected_extension_cells": sharding.EXPECTED_TOTAL_CELLS,
        "status": status,
        "sharding_version": sharding.SHARDING_VERSION,
        "sharding_execution_hash": plan["sharding_execution_hash"],
        "plan_hash": plan["plan_hash"],
        "merge_input_hash": merge_input_hash,
        "merge_audit_version": MERGE_AUDIT_VERSION,
        "merge_audit_hash": audit_hash,
        "merge_identity_amendment": {
            "original_failure": "plan-level hash compared with cell-level source hash",
            "correct_relation": "checkpoint.source_protocol_hash == source_row.protocol_hash",
            "training_or_checkpoint_modified": False,
            "test_accessed": False,
        },
        "num_shards": plan["num_shards"],
        "rows": rows,
        "cell_locations": cell_locations,
        "output_artifact_hashes": output_hashes,
        "remaining_undertrained_cells": remaining,
        "extension_exhausted": bool(remaining),
        "retrospective_test_permitted": not remaining,
        "retrospective_test_started": False,
        "automatic_test_stage": False,
        "runtime_by_shard": [item["runtime"] for item in reports],
        "wall_seconds_by_shard": [item["execution_session_seconds"] for item in reports],
        "summed_cell_seconds": float(sum(float(row["seconds"]) for row in rows)),
        "run_directory": str(directory),
        "test_accessed": False,
    }
    report = sharding._write_immutable_aggregate(directory / "report.json", report)
    extension._json(directory / "manifest.json", {
        "status": status,
        "protocol_hash": plan["protocol_hash"],
        "sharding_execution_hash": plan["sharding_execution_hash"],
        "plan_hash": plan["plan_hash"],
        "merge_input_hash": merge_input_hash,
        "merge_audit_version": MERGE_AUDIT_VERSION,
        "merge_audit_hash": audit_hash,
        "num_shards": plan["num_shards"],
        "completed_shards": plan["num_shards"],
        "completed_cells": len(rows),
        "remaining_undertrained_cells": remaining,
        "extension_exhausted": bool(remaining),
        "retrospective_test_permitted": not remaining,
        "retrospective_test_started": False,
        "test_accessed": False,
    })
    return report

