"""Audited multi-GPU sharding for the SIVP epoch-45-to-60 extension.

This module parallelizes independent dataset/seed groups.  It deliberately does
not use DDP: each group contains the four paired scientific cells, and no model
state is shared across groups.  Shards write to disjoint directories and become
a valid 120-cell extension run only after :func:`merge_shards` succeeds.
"""

from __future__ import annotations

import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import time
from typing import Iterable

import numpy as np
import torch
import yaml

from nyquistguard.data import full_cache_path
from . import controlled_runner as base
from . import extension_runner as extension


SHARDING_VERSION = "sivp_extension_dataset_seed_lpt_v1"
EXPECTED_TOTAL_CELLS = 120
MIN_TORCH_VERSION = (2, 8)


def _canonical_hash(value: object) -> str:
    payload = json.dumps(
        value, sort_keys=True, separators=(",", ":"), ensure_ascii=False, allow_nan=False
    ).encode("utf-8")
    return hashlib.sha256(payload).hexdigest()


def _portable_relative_identifier(root: Path, path: Path) -> bytes:
    """Reproduce the frozen Windows path bytes on every execution platform."""
    relative = path.resolve().relative_to(root.resolve()).as_posix().replace("/", "\\")
    return relative.encode("utf-8")


def _portable_extension_hash(root: Path, config_path: Path) -> str:
    """Compute the frozen extension hash without host path-separator drift."""
    digest = hashlib.sha256()
    paths = (
        config_path,
        root / "docs/SIVP_DECISIVE_CONTROLS_EXTENSION_PROTOCOL.md",
        root / "scripts/run_sivp_decisive_controls_extension.py",
        Path(extension.__file__),
        Path(base.__file__),
        Path(base.__file__).with_name("models.py"),
    )
    for path in paths:
        digest.update(_portable_relative_identifier(root, path))
        digest.update(path.read_bytes())
    return digest.hexdigest()


def _execution_hash(root: Path) -> str:
    digest = hashlib.sha256()
    paths = (
        Path(__file__),
        root / "scripts/run_sivp_decisive_controls_extension_sharded.py",
        root / "docs/SIVP_THREE_GPU_SHARDING_RUNBOOK.md",
    )
    for path in paths:
        digest.update(_portable_relative_identifier(root, path))
        digest.update(path.read_bytes())
    return digest.hexdigest()


def _version_tuple(version: str) -> tuple[int, int]:
    core = version.split("+", 1)[0]
    numbers = []
    for part in core.split(".")[:2]:
        digits = "".join(character for character in part if character.isdigit())
        numbers.append(int(digits or 0))
    return tuple((numbers + [0, 0])[:2])  # type: ignore[return-value]


def validate_runtime(*, require_cuda: bool, required_devices: int = 1) -> dict:
    """Fail early on an environment that cannot reproduce the extension."""
    if sys.version_info < (3, 10):
        raise RuntimeError("Python 3.10 or newer is required")
    if _version_tuple(torch.__version__) < MIN_TORCH_VERSION:
        raise RuntimeError(
            f"PyTorch >= {MIN_TORCH_VERSION[0]}.{MIN_TORCH_VERSION[1]} is required; "
            f"found {torch.__version__}"
        )
    visible = torch.cuda.device_count() if torch.cuda.is_available() else 0
    if require_cuda and visible < required_devices:
        raise RuntimeError(
            f"{required_devices} visible CUDA device(s) required; found {visible}. "
            "Check the platform GPU count and CUDA_VISIBLE_DEVICES."
        )
    devices = []
    for index in range(visible):
        properties = torch.cuda.get_device_properties(index)
        devices.append({
            "index": index,
            "name": properties.name,
            "total_memory_mib": int(properties.total_memory / (1024 ** 2)),
            "compute_capability": f"{properties.major}.{properties.minor}",
        })
    return {
        "python": sys.version.split()[0],
        "torch": torch.__version__,
        "torch_cuda": torch.version.cuda,
        "numpy": np.__version__,
        "cuda_available": torch.cuda.is_available(),
        "visible_cuda_devices": visible,
        "devices": devices,
    }


def _cell_key(row: dict) -> tuple[str, str, str, int]:
    return row["dataset_id"], row["family"], row["regime"], int(row["seed"])


def _group_key(dataset_id: str, seed: int) -> str:
    return f"{dataset_id}::seed{int(seed)}"


def _plan_payload(plan: dict) -> dict:
    return {key: value for key, value in plan.items() if key != "plan_hash"}


def build_shard_plan_from_report(
    config: dict,
    source_report: dict,
    *,
    num_shards: int,
    protocol_hash: str,
    config_sha256: str,
    execution_hash: str,
) -> dict:
    """Create a deterministic longest-processing-time plan from measured cell times."""
    if not 1 <= num_shards <= 30:
        raise ValueError("num_shards must be between 1 and 30")
    indexed = extension._source_rows(source_report)
    source_epoch = int(config["source_epoch"])
    target_epoch = int(config["target_epoch"])
    scale = (target_epoch - source_epoch) / source_epoch
    grouped: dict[tuple[str, int], list[dict]] = {}
    for row in indexed.values():
        key = (row["dataset_id"], int(row["seed"]))
        grouped.setdefault(key, []).append(row)
    if len(grouped) != 30:
        raise ValueError(f"expected 30 dataset/seed groups, found {len(grouped)}")
    groups = []
    expected_cells = {f"{family}_{regime}" for family, regime in base.CELLS}
    for (dataset_id, seed), rows in grouped.items():
        names = {f"{row['family']}_{row['regime']}" for row in rows}
        if names != expected_cells or len(rows) != len(base.CELLS):
            raise ValueError(f"incomplete four-cell source group: {dataset_id}/seed{seed}")
        source_seconds = float(sum(float(row.get("seconds", 0.0)) for row in rows))
        if not np.isfinite(source_seconds) or source_seconds <= 0:
            raise ValueError(f"invalid measured source time: {dataset_id}/seed{seed}")
        groups.append({
            "group_key": _group_key(dataset_id, seed),
            "dataset_id": dataset_id,
            "seed": seed,
            "cell_count": len(base.CELLS),
            "measured_source_seconds": source_seconds,
            "predicted_extension_seconds": source_seconds * scale,
        })
    # LPT scheduling is deterministic because both the weight and tie breakers are explicit.
    groups.sort(key=lambda row: (
        -row["predicted_extension_seconds"], row["dataset_id"], row["seed"]
    ))
    bins = [{"shard_index": index, "groups": [], "predicted_extension_seconds": 0.0}
            for index in range(num_shards)]
    for group in groups:
        target = min(bins, key=lambda row: (row["predicted_extension_seconds"], row["shard_index"]))
        target["groups"].append(group)
        target["predicted_extension_seconds"] += group["predicted_extension_seconds"]
    for shard in bins:
        shard["expected_groups"] = len(shard["groups"])
        shard["expected_cells"] = sum(group["cell_count"] for group in shard["groups"])
        shard["predicted_extension_hours"] = shard["predicted_extension_seconds"] / 3600.0
    plan = {
        "sharding_version": SHARDING_VERSION,
        "protocol_version": config["protocol_version"],
        "protocol_hash": protocol_hash,
        "sharding_execution_hash": execution_hash,
        "extension_config_sha256": config_sha256,
        "source_run": config["source_run"],
        "source_protocol_hash": config["source_protocol_hash"],
        "source_report_sha256": config["source_report_sha256"],
        "source_config_sha256": config["source_config_sha256"],
        "source_epoch": source_epoch,
        "target_epoch": target_epoch,
        "num_shards": num_shards,
        "grouping_unit": "dataset_id_x_seed_with_all_four_paired_cells",
        "assignment_algorithm": "deterministic_longest_processing_time_first",
        "time_estimator": "sum_epoch45_cell_seconds_x_15_over_45",
        "expected_total_groups": len(groups),
        "expected_total_cells": len(indexed),
        "dataset_order": list(dict.fromkeys(row["dataset_id"] for row in source_report["rows"])),
        "seed_order": list(dict.fromkeys(int(row["seed"]) for row in source_report["rows"])),
        "shards": bins,
        "automatic_test_stage": False,
        "test_accessed": False,
    }
    plan["plan_hash"] = _canonical_hash(_plan_payload(plan))
    return plan


def build_shard_plan(root: Path, config_path: Path, *, num_shards: int) -> tuple[dict, dict]:
    root = root.resolve()
    config_path = config_path.resolve()
    config = yaml.safe_load(config_path.read_text(encoding="utf-8"))
    extension._validate_extension_config(config)
    checked = extension.preflight(root, config)
    source_report = json.loads(
        (root / config["source_run"] / "report.json").read_text(encoding="utf-8")
    )
    plan = build_shard_plan_from_report(
        config,
        source_report,
        num_shards=num_shards,
        protocol_hash=_portable_extension_hash(root, config_path),
        config_sha256=extension._sha256(config_path),
        execution_hash=_execution_hash(root),
    )
    return plan, checked


def _validate_plan(root: Path, config_path: Path, plan: dict) -> None:
    if plan.get("sharding_version") != SHARDING_VERSION:
        raise ValueError("sharding version mismatch")
    if plan.get("plan_hash") != _canonical_hash(_plan_payload(plan)):
        raise ValueError("shard plan hash mismatch")
    if plan.get("test_accessed") is not False or plan.get("automatic_test_stage") is not False:
        raise ValueError("shard plan TEST boundary mismatch")
    if plan.get("expected_total_cells") != EXPECTED_TOTAL_CELLS:
        raise ValueError("shard plan does not cover 120 cells")
    if plan.get("extension_config_sha256") != extension._sha256(config_path):
        raise ValueError("shard plan extension config mismatch")
    if plan.get("protocol_hash") != _portable_extension_hash(root, config_path):
        raise ValueError("shard plan scientific protocol mismatch")
    if plan.get("sharding_execution_hash") != _execution_hash(root):
        raise ValueError("shard plan execution-code mismatch")
    shards = plan.get("shards", [])
    if len(shards) != plan.get("num_shards"):
        raise ValueError("shard count mismatch")
    groups = []
    for expected_index, shard in enumerate(shards):
        if shard.get("shard_index") != expected_index:
            raise ValueError("non-contiguous shard indices")
        if shard.get("expected_groups") != len(shard.get("groups", [])):
            raise ValueError("shard group count mismatch")
        if shard.get("expected_cells") != 4 * len(shard.get("groups", [])):
            raise ValueError("shard cell count mismatch")
        groups.extend(group["group_key"] for group in shard.get("groups", []))
    if len(groups) != 30 or len(set(groups)) != 30:
        raise ValueError("shard groups are missing or duplicated")


def _validate_plan_against_source(
    root: Path, config_path: Path, config: dict, plan: dict
) -> None:
    source_report_path = root / config["source_run"] / "report.json"
    if extension._sha256(source_report_path) != config["source_report_sha256"]:
        raise ValueError("source report changed after shard planning")
    source_report = json.loads(source_report_path.read_text(encoding="utf-8"))
    rebuilt = build_shard_plan_from_report(
        config,
        source_report,
        num_shards=plan["num_shards"],
        protocol_hash=_portable_extension_hash(root, config_path),
        config_sha256=extension._sha256(config_path),
        execution_hash=_execution_hash(root),
    )
    if rebuilt != plan:
        raise ValueError("shard plan differs from deterministic source-derived assignment")


def prepare_distributed_run(
    root: Path, config_path: Path, *, num_shards: int, directory: Path | None = None
) -> dict:
    root = root.resolve()
    config_path = config_path.resolve()
    plan, checked = build_shard_plan(root, config_path, num_shards=num_shards)
    config = yaml.safe_load(config_path.read_text(encoding="utf-8"))
    output_root = (root / config["output_root"]).resolve()
    if root not in output_root.parents:
        raise ValueError("distributed output root escapes project")
    if directory is None:
        stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S%fZ")
        directory = output_root / f"distributed_{num_shards}gpu__{stamp}"
        directory.mkdir(parents=True, exist_ok=False)
    else:
        directory = directory.resolve()
        if output_root not in directory.parents:
            raise ValueError("distributed directory escapes extension output root")
        directory.mkdir(parents=True, exist_ok=False)
    shutil.copy2(config_path, directory / "config_frozen.yaml")
    extension._json(directory / "shard_plan.json", plan)
    extension._json(directory / "preflight_snapshot.json", checked)
    extension._json(directory / "manifest.json", {
        "status": "prepared",
        "sharding_version": SHARDING_VERSION,
        "protocol_hash": plan["protocol_hash"],
        "sharding_execution_hash": plan["sharding_execution_hash"],
        "plan_hash": plan["plan_hash"],
        "num_shards": num_shards,
        "completed_shards": 0,
        "test_accessed": False,
    })
    return {"directory": str(directory), "plan": plan, "preflight": checked}


def _load_distributed(root: Path, directory: Path) -> tuple[Path, Path, dict, dict]:
    root = root.resolve()
    directory = directory.resolve()
    if root not in directory.parents or not directory.is_dir():
        raise ValueError("distributed run is missing or outside project")
    config_path = root / "configs/experiments/sivp_decisive_controls_extension.yaml"
    frozen = directory / "config_frozen.yaml"
    if not frozen.is_file() or frozen.read_bytes() != config_path.read_bytes():
        raise ValueError("distributed frozen config mismatch")
    config = yaml.safe_load(config_path.read_text(encoding="utf-8"))
    output_root = (root / config["output_root"]).resolve()
    if output_root not in directory.parents:
        raise ValueError("distributed run is outside the frozen extension output root")
    plan = json.loads((directory / "shard_plan.json").read_text(encoding="utf-8"))
    _validate_plan(root, config_path, plan)
    _validate_plan_against_source(root, config_path, config, plan)
    return directory, config_path, config, plan


def _validate_completed_cell(
    row: dict, *, dataset_id: str, family: str, regime: str, seed: int,
    protocol_hash: str, target_epoch: int, cell_directory: Path,
) -> None:
    expected = {
        "status": "completed_extension",
        "protocol_hash": protocol_hash,
        "dataset_id": dataset_id,
        "family": family,
        "regime": regime,
        "seed": seed,
        "epochs_completed": target_epoch,
        "test_accessed": False,
    }
    for key, value in expected.items():
        if row.get(key) != value:
            raise ValueError(f"completed shard cell mismatch for {key}: {cell_directory.name}")
    required = tuple(cell_directory / name for name in (
        "checkpoint_best.pt", "checkpoint_last.pt", "history.json", "schedule.json", "metrics.json"
    ))
    if not all(path.is_file() for path in required):
        raise ValueError(f"completed shard cell artifacts incomplete: {cell_directory.name}")


def run_shard(
    root: Path,
    distributed_directory: Path,
    *,
    shard_index: int,
    device_name: str = "cuda",
) -> dict:
    root = root.resolve()
    directory, config_path, config, plan = _load_distributed(root, distributed_directory)
    if not 0 <= shard_index < plan["num_shards"]:
        raise ValueError("shard_index outside plan")
    runtime = validate_runtime(require_cuda=device_name == "cuda", required_devices=1)
    checked = extension.preflight(root, config)
    if checked["source_protocol_hash"] != plan["source_protocol_hash"]:
        raise ValueError("source protocol changed after sharding")
    source_run = Path(checked["source_run"])
    source_report = json.loads((source_run / "report.json").read_text(encoding="utf-8"))
    indexed = extension._source_rows(source_report)
    train_config = yaml.safe_load((source_run / "config_frozen.yaml").read_text(encoding="utf-8"))
    base_config = yaml.safe_load((root / train_config["base_config"]).read_text(encoding="utf-8"))
    shard_plan = plan["shards"][shard_index]
    selected = {(group["dataset_id"], int(group["seed"])) for group in shard_plan["groups"]}
    shard_directory = directory / f"shard_{shard_index:02d}_of_{plan['num_shards']:02d}"
    shard_directory.mkdir(parents=True, exist_ok=True)
    manifest_path = shard_directory / "manifest.json"
    if manifest_path.is_file():
        prior = json.loads(manifest_path.read_text(encoding="utf-8"))
        if (
            prior.get("plan_hash") != plan["plan_hash"]
            or prior.get("protocol_hash") != plan["protocol_hash"]
            or prior.get("shard_index") != shard_index
            or prior.get("test_accessed") is not False
        ):
            raise ValueError("shard resume identity or TEST boundary mismatch")
    extension._json(manifest_path, {
        "status": "running",
        "sharding_version": SHARDING_VERSION,
        "sharding_execution_hash": plan["sharding_execution_hash"],
        "protocol_hash": plan["protocol_hash"],
        "plan_hash": plan["plan_hash"],
        "shard_index": shard_index,
        "num_shards": plan["num_shards"],
        "expected_groups": shard_plan["expected_groups"],
        "expected_cells": shard_plan["expected_cells"],
        "test_accessed": False,
    })
    torch.set_num_threads(int(train_config["threads"]))
    device = torch.device(device_name)
    rows = []
    reused = 0
    started = time.monotonic()
    try:
        for dataset_id in train_config["datasets"]:
            seeds = [int(seed) for seed in train_config["seeds"] if (dataset_id, int(seed)) in selected]
            if not seeds:
                continue
            data = base.load_development_cache(full_cache_path(root, dataset_id))
            fingerprint = checked["cache_check"]["datasets"][dataset_id]["development_fingerprint"]
            if base._fingerprint(data) != fingerprint:
                raise ValueError("development cache changed after shard preflight")
            for seed in seeds:
                paired = {}
                for family, regime in base.CELLS:
                    source_row = indexed[(dataset_id, family, regime, seed)]
                    cell_name = f"{dataset_id}__{family}_{regime}__seed{seed}"
                    cell_directory = shard_directory / cell_name
                    metrics_path = cell_directory / "metrics.json"
                    if metrics_path.is_file():
                        row = json.loads(metrics_path.read_text(encoding="utf-8"))
                        _validate_completed_cell(
                            row, dataset_id=dataset_id, family=family, regime=regime, seed=seed,
                            protocol_hash=plan["protocol_hash"], target_epoch=config["target_epoch"],
                            cell_directory=cell_directory,
                        )
                        reused += 1
                    else:
                        if cell_directory.exists():
                            archive = shard_directory / "incomplete_attempts"
                            archive.mkdir(exist_ok=True)
                            suffix = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S%fZ")
                            cell_directory.rename(archive / f"{cell_name}__{suffix}")
                        row = extension._extend_cell(
                            data, base_config, train_config, config, source_row,
                            source_run / cell_name, cell_directory, device, plan["protocol_hash"],
                        )
                    rows.append(row)
                    paired[f"{family}_{regime}"] = row
                    extension._json(shard_directory / "partial.json", {
                        "shard_index": shard_index,
                        "completed_cells": len(rows),
                        "expected_cells": shard_plan["expected_cells"],
                        "rows": rows,
                        "test_accessed": False,
                    })
                if len({row["downstream_initial_state_hash"] for row in paired.values()}) != 1:
                    raise RuntimeError("paired shard cells do not share downstream initialization")
                schedules = []
                for family, regime in base.CELLS:
                    schedule_path = shard_directory / (
                        f"{dataset_id}__{family}_{regime}__seed{seed}/schedule.json"
                    )
                    schedules.append([
                        item["scheduled_ratio"]
                        for item in json.loads(schedule_path.read_text(encoding="utf-8"))["schedule"]
                    ])
                if any(schedule != schedules[0] for schedule in schedules[1:]):
                    raise RuntimeError("paired shard cells do not share the full ratio schedule")
            del data
            if device.type == "cuda":
                torch.cuda.empty_cache()
        if len(rows) != shard_plan["expected_cells"]:
            raise RuntimeError("shard completed an unexpected number of cells")
        remaining = [
            f"{row['dataset_id']}/{row['family']}_{row['regime']}/seed{row['seed']}"
            for row in rows if row["undertraining"]["flagged"]
        ]
        report = {
            "status": "completed_shard",
            "sharding_version": SHARDING_VERSION,
            "sharding_execution_hash": plan["sharding_execution_hash"],
            "protocol_hash": plan["protocol_hash"],
            "source_protocol_hash": plan["source_protocol_hash"],
            "plan_hash": plan["plan_hash"],
            "shard_index": shard_index,
            "num_shards": plan["num_shards"],
            "groups": shard_plan["groups"],
            "expected_cells": shard_plan["expected_cells"],
            "completed_cells": len(rows),
            "rows": rows,
            "remaining_undertrained_cells": remaining,
            "execution_session_seconds": time.monotonic() - started,
            "reused_completed_cells": reused,
            "runtime": runtime,
            "retrospective_test_permitted": False,
            "retrospective_test_started": False,
            "test_accessed": False,
        }
        extension._json(shard_directory / "shard_report.json", report)
        extension._json(manifest_path, {
            "status": "completed_shard",
            "protocol_hash": plan["protocol_hash"],
            "sharding_execution_hash": plan["sharding_execution_hash"],
            "plan_hash": plan["plan_hash"],
            "shard_index": shard_index,
            "num_shards": plan["num_shards"],
            "completed_cells": len(rows),
            "remaining_undertrained_cells": remaining,
            "reused_completed_cells": reused,
            "test_accessed": False,
        })
        return report
    except BaseException as error:
        extension._json(manifest_path, {
            "status": "failed",
            "protocol_hash": plan["protocol_hash"],
            "sharding_execution_hash": plan["sharding_execution_hash"],
            "plan_hash": plan["plan_hash"],
            "shard_index": shard_index,
            "completed_cells": len(rows),
            "error": f"{type(error).__name__}: {error}",
            "test_accessed": False,
        })
        raise


def _planned_cell_keys(plan: dict) -> set[tuple[str, str, str, int]]:
    keys = set()
    for shard in plan["shards"]:
        for group in shard["groups"]:
            for family, regime in base.CELLS:
                key = (group["dataset_id"], family, regime, int(group["seed"]))
                if key in keys:
                    raise ValueError(f"duplicate planned cell: {key}")
                keys.add(key)
    return keys


def validate_collected_rows(
    plan: dict, shard_reports: Iterable[dict], *, protocol_hash: str
) -> list[dict]:
    """Validate report-level completeness before touching any aggregate output."""
    reports = list(shard_reports)
    if len(reports) != plan["num_shards"]:
        raise ValueError("missing shard report")
    rows_by_key = {}
    seen_shards = set()
    for report in reports:
        index = report.get("shard_index")
        if not isinstance(index, int) or not 0 <= index < plan["num_shards"]:
            raise ValueError(f"invalid shard report index: {index}")
        if index in seen_shards:
            raise ValueError("duplicate shard report")
        seen_shards.add(index)
        if (
            report.get("status") != "completed_shard"
            or report.get("protocol_hash") != protocol_hash
            or report.get("plan_hash") != plan["plan_hash"]
            or report.get("sharding_execution_hash") != plan["sharding_execution_hash"]
            or report.get("test_accessed") is not False
        ):
            raise ValueError(f"shard report identity or TEST boundary mismatch: {index}")
        assigned = set()
        for group in plan["shards"][index]["groups"]:
            assigned.update(
                (group["dataset_id"], family, regime, int(group["seed"]))
                for family, regime in base.CELLS
            )
        report_rows = report.get("rows", [])
        if len(report_rows) != plan["shards"][index]["expected_cells"]:
            raise ValueError(f"shard row count mismatch: {index}")
        for row in report_rows:
            key = _cell_key(row)
            if key not in assigned:
                raise ValueError(f"cell appears in wrong shard: {key}")
            if key in rows_by_key:
                raise ValueError(f"duplicate collected cell: {key}")
            if (
                row.get("status") != "completed_extension"
                or row.get("protocol_hash") != protocol_hash
                or row.get("epochs_completed") != plan["target_epoch"]
                or row.get("test_accessed") is not False
            ):
                raise ValueError(f"invalid collected cell: {key}")
            rows_by_key[key] = row
    planned = _planned_cell_keys(plan)
    if set(rows_by_key) != planned or len(rows_by_key) != EXPECTED_TOTAL_CELLS:
        missing = sorted(planned - set(rows_by_key))
        extra = sorted(set(rows_by_key) - planned)
        raise ValueError(f"merged cells incomplete; missing={missing[:3]}, extra={extra[:3]}")
    order = {}
    position = 0
    for dataset_id in plan["dataset_order"]:
        for seed in plan["seed_order"]:
            for family, regime in base.CELLS:
                order[(dataset_id, family, regime, seed)] = position
                position += 1
    return sorted(rows_by_key.values(), key=lambda row: order[_cell_key(row)])


def _write_immutable_aggregate(path: Path, report: dict) -> dict:
    """Create an aggregate once, or return the byte-equivalent-input aggregate."""
    if path.is_file():
        existing = json.loads(path.read_text(encoding="utf-8"))
        if existing != report:
            raise FileExistsError("immutable merged report exists for different shard inputs")
        return existing
    extension._json(path, report)
    return report


def merge_shards(root: Path, distributed_directory: Path) -> dict:
    root = root.resolve()
    directory, config_path, config, plan = _load_distributed(root, distributed_directory)
    checked = extension.preflight(root, config)
    source_report = json.loads(
        (root / config["source_run"] / "report.json").read_text(encoding="utf-8")
    )
    source_rows = extension._source_rows(source_report)
    reports = []
    report_hashes = []
    for index in range(plan["num_shards"]):
        shard_directory = directory / f"shard_{index:02d}_of_{plan['num_shards']:02d}"
        report_path = shard_directory / "shard_report.json"
        if not report_path.is_file():
            raise ValueError(f"missing shard report: {index}")
        reports.append(json.loads(report_path.read_text(encoding="utf-8")))
        report_hashes.append(extension._sha256(report_path))
    rows = validate_collected_rows(plan, reports, protocol_hash=plan["protocol_hash"])
    cell_locations = {}
    output_hashes = {}
    for row in rows:
        key = _cell_key(row)
        source_row = source_rows[key]
        group_key = _group_key(row["dataset_id"], row["seed"])
        shard_index = next(
            shard["shard_index"] for shard in plan["shards"]
            if group_key in {group["group_key"] for group in shard["groups"]}
        )
        cell_name = f"{row['dataset_id']}__{row['family']}_{row['regime']}__seed{row['seed']}"
        cell_directory = directory / f"shard_{shard_index:02d}_of_{plan['num_shards']:02d}" / cell_name
        metrics = json.loads((cell_directory / "metrics.json").read_text(encoding="utf-8"))
        if metrics != row:
            raise ValueError(f"cell metrics differ from shard report: {cell_name}")
        if row.get("source_artifact_hashes") != checked["source_artifacts"][cell_name]:
            raise ValueError(f"cell source artifact hashes mismatch: {cell_name}")
        if (
            row.get("initial_state_hash") != source_row.get("initial_state_hash")
            or row.get("downstream_initial_state_hash")
            != source_row.get("downstream_initial_state_hash")
        ):
            raise ValueError(f"cell source identity mismatch: {cell_name}")
        required = ("checkpoint_best.pt", "checkpoint_last.pt", "history.json", "schedule.json", "metrics.json")
        if not all((cell_directory / name).is_file() for name in required):
            raise ValueError(f"merged cell artifacts incomplete: {cell_name}")
        last = torch.load(cell_directory / "checkpoint_last.pt", map_location="cpu", weights_only=True)
        if (
            last.get("epoch") != plan["target_epoch"]
            or last.get("protocol_hash") != plan["protocol_hash"]
            or last.get("source_protocol_hash") != plan["source_protocol_hash"]
        ):
            raise ValueError(f"merged checkpoint identity mismatch: {cell_name}")
        history = json.loads((cell_directory / "history.json").read_text(encoding="utf-8"))["history"]
        if len(history) != plan["target_epoch"]:
            raise ValueError(f"merged history length mismatch: {cell_name}")
        cell_locations[cell_name] = str(cell_directory.relative_to(directory))
        output_hashes[cell_name] = {name: extension._sha256(cell_directory / name) for name in required}
    for dataset_id, seed in sorted({(row["dataset_id"], int(row["seed"])) for row in rows}):
        paired = [row for row in rows if row["dataset_id"] == dataset_id and int(row["seed"]) == seed]
        if len(paired) != 4 or len({row["downstream_initial_state_hash"] for row in paired}) != 1:
            raise ValueError(f"merged paired initialization mismatch: {dataset_id}/seed{seed}")
        schedule_values = []
        for row in paired:
            cell_name = f"{row['dataset_id']}__{row['family']}_{row['regime']}__seed{row['seed']}"
            schedule = json.loads(
                (directory / cell_locations[cell_name] / "schedule.json").read_text(encoding="utf-8")
            )["schedule"]
            schedule_values.append([item["scheduled_ratio"] for item in schedule])
        if any(values != schedule_values[0] for values in schedule_values[1:]):
            raise ValueError(f"merged paired schedule mismatch: {dataset_id}/seed{seed}")
    merge_input_hash = _canonical_hash({
        "plan_hash": plan["plan_hash"],
        "shard_report_hashes": report_hashes,
        "output_artifact_hashes": output_hashes,
    })
    report_path = directory / "report.json"
    remaining = [
        f"{row['dataset_id']}/{row['family']}_{row['regime']}/seed{row['seed']}"
        for row in rows if row["undertraining"]["flagged"]
    ]
    status = "completed_extension_undertrained" if remaining else "completed_extension"
    report = {
        "protocol_version": config["protocol_version"],
        "protocol_hash": plan["protocol_hash"],
        "scope": config["scope"],
        "source_run": config["source_run"],
        "source_epoch": config["source_epoch"],
        "target_epoch": config["target_epoch"],
        "expected_extension_cells": EXPECTED_TOTAL_CELLS,
        "status": status,
        "sharding_version": SHARDING_VERSION,
        "sharding_execution_hash": plan["sharding_execution_hash"],
        "plan_hash": plan["plan_hash"],
        "merge_input_hash": merge_input_hash,
        "num_shards": plan["num_shards"],
        "rows": rows,
        "cell_locations": cell_locations,
        "output_artifact_hashes": output_hashes,
        "remaining_undertrained_cells": remaining,
        "extension_exhausted": bool(remaining),
        "retrospective_test_permitted": not remaining,
        "retrospective_test_started": False,
        "automatic_test_stage": False,
        "runtime_by_shard": [report["runtime"] for report in reports],
        "wall_seconds_by_shard": [report["execution_session_seconds"] for report in reports],
        "summed_cell_seconds": float(sum(float(row["seconds"]) for row in rows)),
        "run_directory": str(directory),
        "test_accessed": False,
    }
    report = _write_immutable_aggregate(report_path, report)
    extension._json(directory / "manifest.json", {
        "status": status,
        "protocol_hash": plan["protocol_hash"],
        "sharding_execution_hash": plan["sharding_execution_hash"],
        "plan_hash": plan["plan_hash"],
        "merge_input_hash": merge_input_hash,
        "num_shards": plan["num_shards"],
        "completed_shards": plan["num_shards"],
        "completed_cells": len(rows),
        "remaining_undertrained_cells": remaining,
        "extension_exhausted": bool(remaining),
        "retrospective_test_permitted": not remaining,
        "test_accessed": False,
    })
    return report


def _child_command(script: Path, directory: Path, index: int) -> list[str]:
    command = [sys.executable]
    if sys.flags.no_site:
        command.append("-S")
    command.extend([
        str(script), "--run-shard", "--distributed-run", str(directory),
        "--shard-index", str(index), "--device", "cuda",
    ])
    return command


def _physical_device_token(local_index: int) -> str:
    """Map a PyTorch-visible local index through an inherited platform mask."""
    inherited = os.environ.get("CUDA_VISIBLE_DEVICES")
    if not inherited:
        return str(local_index)
    tokens = [token.strip() for token in inherited.split(",") if token.strip()]
    if local_index >= len(tokens):
        raise ValueError("local GPU index exceeds inherited CUDA_VISIBLE_DEVICES mask")
    return tokens[local_index]


def launch_local_gpus(
    root: Path,
    config_path: Path,
    *,
    devices: list[int],
    distributed_directory: Path | None = None,
) -> dict:
    """Launch one isolated Python process per visible local GPU and merge on success."""
    root = root.resolve()
    if not devices or len(set(devices)) != len(devices) or any(index < 0 for index in devices):
        raise ValueError("GPU device indices must be a non-empty unique list")
    runtime = validate_runtime(require_cuda=True, required_devices=max(devices) + 1)
    config_path = config_path.resolve()
    if distributed_directory is None:
        prepared = prepare_distributed_run(root, config_path, num_shards=len(devices))
        directory = Path(prepared["directory"])
        plan = prepared["plan"]
    else:
        directory, _, _, plan = _load_distributed(root, distributed_directory)
        if plan["num_shards"] != len(devices):
            raise ValueError("resume GPU count differs from frozen shard plan")
    logs = directory / "logs"
    logs.mkdir(exist_ok=True)
    extension._json(directory / "launcher_runtime.json", runtime)
    extension._json(directory / "manifest.json", {
        "status": "running_shards",
        "protocol_hash": plan["protocol_hash"],
        "sharding_execution_hash": plan["sharding_execution_hash"],
        "plan_hash": plan["plan_hash"],
        "num_shards": plan["num_shards"],
        "gpu_mapping": {str(index): devices[index] for index in range(len(devices))},
        "completed_shards": 0,
        "test_accessed": False,
    })
    script = root / "scripts/run_sivp_decisive_controls_extension_sharded.py"
    processes = []
    handles = []
    try:
        for shard_index, gpu_index in enumerate(devices):
            log_path = logs / f"shard_{shard_index:02d}.log"
            handle = log_path.open("a", encoding="utf-8", buffering=1)
            handles.append(handle)
            environment = os.environ.copy()
            environment["CUDA_VISIBLE_DEVICES"] = _physical_device_token(gpu_index)
            environment["PYTHONUNBUFFERED"] = "1"
            process = subprocess.Popen(
                _child_command(script, directory, shard_index),
                cwd=root,
                env=environment,
                stdout=handle,
                stderr=subprocess.STDOUT,
            )
            processes.append((shard_index, gpu_index, process, log_path))
            print(f"launched shard {shard_index} on GPU {gpu_index}; log={log_path}", flush=True)
        last_progress = None
        while any(process.poll() is None for _, _, process, _ in processes):
            progress = []
            for shard_index, _, process, _ in processes:
                partial = directory / f"shard_{shard_index:02d}_of_{plan['num_shards']:02d}" / "partial.json"
                completed = 0
                if partial.is_file():
                    try:
                        completed = int(json.loads(partial.read_text(encoding="utf-8"))["completed_cells"])
                    except (OSError, ValueError, KeyError, json.JSONDecodeError):
                        completed = 0
                progress.append((shard_index, completed, plan["shards"][shard_index]["expected_cells"], process.poll()))
            if progress != last_progress:
                print(" | ".join(
                    f"shard {index}: {done}/{total} cells" + ("" if code is None else f" exit={code}")
                    for index, done, total, code in progress
                ), flush=True)
                last_progress = progress
            time.sleep(10)
        failures = [
            (index, process.returncode, str(log_path))
            for index, _, process, log_path in processes if process.returncode != 0
        ]
        if failures:
            extension._json(directory / "manifest.json", {
                "status": "failed_shard_launch",
                "protocol_hash": plan["protocol_hash"],
                "sharding_execution_hash": plan["sharding_execution_hash"],
                "plan_hash": plan["plan_hash"],
                "failures": failures,
                "test_accessed": False,
            })
            raise RuntimeError(f"one or more shards failed; resume after inspecting logs: {failures}")
    except KeyboardInterrupt:
        for _, _, process, _ in processes:
            if process.poll() is None:
                process.terminate()
        for _, _, process, _ in processes:
            try:
                process.wait(timeout=30)
            except subprocess.TimeoutExpired:
                process.kill()
        extension._json(directory / "manifest.json", {
            "status": "interrupted",
            "protocol_hash": plan["protocol_hash"],
            "sharding_execution_hash": plan["sharding_execution_hash"],
            "plan_hash": plan["plan_hash"],
            "test_accessed": False,
        })
        raise
    finally:
        for handle in handles:
            handle.close()
    return merge_shards(root, directory)


def _parse_devices(value: str) -> list[int]:
    try:
        devices = [int(item.strip()) for item in value.split(",") if item.strip()]
    except ValueError as error:
        raise argparse.ArgumentTypeError("devices must be comma-separated integer indices") from error
    if not devices:
        raise argparse.ArgumentTypeError("at least one GPU device is required")
    return devices


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--config", type=Path,
        default=Path("configs/experiments/sivp_decisive_controls_extension.yaml"),
    )
    actions = parser.add_mutually_exclusive_group()
    actions.add_argument("--prepare", action="store_true")
    actions.add_argument("--execute", action="store_true")
    actions.add_argument("--run-shard", action="store_true")
    actions.add_argument("--merge", action="store_true")
    parser.add_argument("--num-shards", type=int, default=3)
    parser.add_argument("--devices", type=_parse_devices, default=[0, 1, 2])
    parser.add_argument("--distributed-run", type=Path)
    parser.add_argument("--shard-index", type=int)
    parser.add_argument("--device", choices=("cpu", "cuda"), default="cuda")
    args = parser.parse_args()
    root = Path(__file__).resolve().parents[4]
    config_path = args.config if args.config.is_absolute() else root / args.config
    if args.run_shard:
        if args.distributed_run is None or args.shard_index is None:
            parser.error("--run-shard requires --distributed-run and --shard-index")
        result = run_shard(
            root, args.distributed_run, shard_index=args.shard_index, device_name=args.device
        )
    elif args.merge:
        if args.distributed_run is None:
            parser.error("--merge requires --distributed-run")
        result = merge_shards(root, args.distributed_run)
    elif args.execute:
        result = launch_local_gpus(
            root, config_path, devices=args.devices, distributed_directory=args.distributed_run
        )
    elif args.prepare:
        if args.distributed_run is not None:
            parser.error("--prepare creates a new directory; omit --distributed-run")
        result = prepare_distributed_run(root, config_path, num_shards=args.num_shards)
    else:
        plan, checked = build_shard_plan(root, config_path, num_shards=args.num_shards)
        result = {"status": "plan_only", "plan": plan, "preflight": checked, "test_accessed": False}
    print(json.dumps(
        {key: value for key, value in result.items() if key not in {"rows", "preflight"}},
        indent=2, ensure_ascii=False,
    ))


if __name__ == "__main__":
    main()
