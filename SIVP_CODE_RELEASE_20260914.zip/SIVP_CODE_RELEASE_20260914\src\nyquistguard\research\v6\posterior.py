"""TRAIN-fitted class density transported through a finite sampling operator.

Gaussian marginalization is established mathematics, not a novelty claim.
V6's hypothesis concerns how its posterior DIFFERENCES teach a fixed student.
"""
from __future__ import annotations

import math
import torch
from torch import Tensor, nn

from .operators import ObservationSpec, channel_projection, real_fourier_basis, reduce_observation


class SpectralPushforwardTeacher(nn.Module):
    """Frozen fold-specific teacher. Forward is differentiable in observations.

    The teacher is defined on fixed-length source windows. It rejects padding
    and incompatible observation rates rather than silently changing time.
    """
    def __init__(self, basis: Tensor, projection: Tensor, means: Tensor, variances: Tensor,
                 priors: Tensor, residual_variance: float, observation_variance: float = 1e-4) -> None:
        super().__init__()
        if basis.ndim != 2 or projection.ndim != 2 or means.ndim != 3:
            raise ValueError("basis [T,D], projection [C,J], means [K,J,D] required")
        if variances.shape != means.shape or means.shape[1:] != (projection.shape[1], basis.shape[1]):
            raise ValueError("incompatible latent shapes")
        if priors.shape != (means.shape[0],) or means.shape[0] < 2:
            raise ValueError("need >=2 class priors")
        if any(not torch.isfinite(t).all() for t in (basis, projection, means, variances, priors)):
            raise ValueError("teacher state must be finite")
        if torch.any(variances <= 0) or torch.any(priors <= 0) or not torch.isclose(priors.sum().double(), priors.new_tensor(1., dtype=torch.float64)):
            raise ValueError("positive variances and normalized positive priors required")
        if not math.isfinite(residual_variance) or residual_variance < 0 or not math.isfinite(observation_variance) or observation_variance <= 0:
            raise ValueError("invalid noise variances")
        for key, value in dict(basis=basis, projection=projection, means=means,
                               variances=variances, priors=priors).items():
            self.register_buffer(key, value.detach().double().clone())
        self.register_buffer("residual_variance", basis.new_tensor(residual_variance, dtype=torch.float64))
        self.register_buffer("observation_variance", basis.new_tensor(observation_variance, dtype=torch.float64))

    @classmethod
    def fit(cls, x: Tensor, y: Tensor, num_classes: int, *, frequency_pairs: int = 12,
            maximum_channels: int = 4, shrinkage: float = 0.2,
            variance_floor: float = 1e-4) -> "SpectralPushforwardTeacher":
        if x.ndim != 3 or y.shape != x.shape[:1] or not torch.isfinite(x).all():
            raise ValueError("finite TRAIN x [N,C,T] and y [N] required")
        if not 0 <= shrinkage <= 1 or variance_floor <= 0:
            raise ValueError("invalid shrinkage/floor")
        if y.dtype != torch.long or torch.any(y < 0) or torch.any(y >= num_classes):
            raise ValueError("class labels must be long in [0,K)")
        if any(int((y == k).sum()) < 2 for k in range(num_classes)):
            raise ValueError("every teacher TRAIN fold needs at least two samples per class")
        basis, _ = real_fourier_basis(x.shape[-1], frequency_pairs)
        projection = channel_projection(x.shape[1], maximum_channels)
        basis, projection = basis.to(x.device), projection.to(x.device)
        with torch.no_grad():
            z = torch.einsum("bct,cj->bjt", x.double(), projection)
            coefficients = z @ basis
            means = torch.stack([coefficients[y == k].mean(0) for k in range(num_classes)])
            variances = torch.stack([coefficients[y == k].var(0, unbiased=False) for k in range(num_classes)])
            pooled = (coefficients - means[y]).square().mean(0)
            variances = ((1 - shrinkage) * variances + shrinkage * pooled).clamp_min(variance_floor)
            residual = z - coefficients @ basis.T
            noise = max(variance_floor, float(residual.square().mean()))
            priors = torch.bincount(y, minlength=num_classes).double() / y.numel()
        return cls(basis, projection, means, variances, priors, noise, variance_floor)

    def prepare(self, spec: ObservationSpec) -> dict:
        return reduce_observation(self.basis, spec)

    def forward(self, x: Tensor, spec: ObservationSpec, *, sampling_rate_hz: float,
                observation: dict | None = None) -> dict[str, Tensor | int | float]:
        if x.ndim != 3 or x.shape[1] != self.projection.shape[0] or not x.is_floating_point():
            raise ValueError("x must be floating [B,C,Tr]")
        expected_length = max(2, round(self.basis.shape[0] * spec.ratio))
        expected_rate = spec.source_rate_hz * expected_length / self.basis.shape[0]
        if x.shape[-1] != expected_length or not math.isclose(sampling_rate_hz, expected_rate, rel_tol=1e-6):
            raise ValueError("observation length/rate inconsistent with source operator")
        if not torch.isfinite(x).all():
            raise ValueError("observations must be finite")
        reduced = self.prepare(spec) if observation is None else observation
        with torch.autocast(x.device.type, enabled=False):
            u, r = reduced["u"], reduced["response"]
            z = torch.einsum("bct,cj->bjt", x.double(), self.projection)
            observed = z @ u
            mean = self.means @ r.T
            covariance = torch.einsum("ad,kjd,ed->kjae", r, self.variances, r)
            covariance = covariance + self.residual_variance * reduced["noise_gram"]
            covariance = covariance + self.observation_variance * torch.eye(r.shape[0], device=r.device, dtype=r.dtype)
            chol = torch.linalg.cholesky(covariance)
            error = observed[:, None, :, :] - mean[None, :, :, :]
            solved = torch.linalg.solve_triangular(chol[None], error.unsqueeze(-1), upper=False).squeeze(-1)
            logdet = 2 * torch.log(chol.diagonal(dim1=-2, dim2=-1)).sum(-1)
            log_likelihood = -0.5 * (solved.square().sum(-1) + logdet[None] + r.shape[0] * math.log(2 * math.pi)).sum(-1)
            scores = log_likelihood + self.priors.log()
            probabilities = scores.softmax(-1)
        return {"probabilities": probabilities.float(), "logits": scores,
                "rank": reduced["rank"], "discarded_response_norm": reduced["discarded_response_norm"]}
