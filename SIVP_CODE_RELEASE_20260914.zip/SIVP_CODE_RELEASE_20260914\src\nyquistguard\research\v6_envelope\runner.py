"""Candidate C micro only. Default plan has no data access or training.

Completed OPDT files are read-only dependencies; this runner writes only to
runs/v6_envelope/<UTC>. No TEST argument, no automatic followup.
"""
from __future__ import annotations
import argparse
import hashlib
import json
import math
import os
from pathlib import Path
import random
import time
from datetime import datetime, timezone
import numpy as np
from sklearn.metrics import f1_score
import torch
import yaml

from nyquistguard.losses.v6_acquisition_risk import AcquisitionRisk, MODES
from nyquistguard.research.v6.runner import (DATASETS, DevelopmentData, load_development,
    development_hash, make_model, protocol_hash as old_protocol_hash, _json)
from .operators import nominal_view, operator_family, MARGIN
from .training import backward_acquisition, rng_state, restore_rng

OPTIONS = {"summary": "rich", "fusion": "fixed", "gate": "none", "frontend": "ordinary"}


def bounded(root: Path, path: Path, *, output=False) -> Path:
    path = path.resolve()
    boundary = (root / "runs/v6_envelope").resolve() if output else root.resolve()
    if path != boundary and boundary not in path.parents:
        raise ValueError("path escapes envelope boundary")
    return path


def validate_config(c):
    expected = {"protocol_version": "v6_acquisition_envelope_v1", "scope": "validation_only",
        "automatic_followup": False, "datasets": list(DATASETS), "seeds": [60919],
        "arms": list(MODES), "cache_root": "data/processed/pilot_v1",
        "checkpoint_rule": "fixed_final_epoch", "train_rates": [.35,.5,.7],
        "validation_rates": [.9,.6,.4,.3], "heldout_families": ["heldout_hamming","heldout_hann"],
        "epochs": 8, "max_batches_per_epoch": 8, "batch_size": 16,
        "train_cap": 256, "validation_cap": 128, "wall_seconds": 600,
        "maximum_rss_gib": 6, "maximum_cuda_allocated_gib": 2}
    for key, value in expected.items():
        if c.get(key) != value:
            raise ValueError(f"registered envelope setting changed: {key}")
    for key in ("learning_rate", "weight_decay", "gradient_clip", "group_dro_step_size"):
        if not math.isfinite(c[key]) or c[key] <= 0:
            raise ValueError(f"invalid optimizer setting: {key}")


def protocol_hash(root, config_path):
    paths = [config_path, root / "docs/V6_ACQUISITION_ENVELOPE_PROTOCOL.md",
        root / "scripts/run_v6_envelope.py", root / "src/nyquistguard/losses/v6_acquisition_risk.py",
        *sorted((root / "src/nyquistguard/research/v6_envelope").glob("*.py"))]
    digest = hashlib.sha256(old_protocol_hash(root, root / "configs/experiments/v6_validation_micro.yaml").encode())
    for path in paths:
        digest.update(str(path.relative_to(root)).encode()); digest.update(path.read_bytes())
    return digest.hexdigest()


def parent_check(root, config):
    path = bounded(root, root / config["parent_report"])
    parent = json.loads(path.read_text(encoding="utf-8"))
    if parent.get("phase") != "backbone_checks" or parent.get("status") != "completed" or parent.get("test_accessed") is not False:
        raise ValueError("parent must be completed uncontaminated S2")
    if parent.get("selected_options") != OPTIONS or not parent.get("screen_health", {}).get("passed"):
        raise ValueError("frozen ordinary backbone parent required")
    if parent["protocol_hash"] != old_protocol_hash(root, root / "configs/experiments/v6_validation_micro.yaml"):
        raise ValueError("OPDT dependency changed; do not overwrite its frozen implementation")
    frozen = yaml.safe_load((path.parent / "config_frozen.yaml").read_text(encoding="utf-8"))
    if config["model"] != frozen["model"]:
        raise ValueError("backbone hyperparameters changed from S2")
    return {"report": str(path), "sha256": hashlib.sha256(path.read_bytes()).hexdigest()}


def preflight(root, c):
    result = {}
    for dataset in c["datasets"]:
        data = load_development(root / c["cache_root"] / f"{dataset}.npz", c)
        if data.dataset_id != dataset:
            raise ValueError("cache dataset ID mismatch")
        minimum_length = math.floor((data.train_x.shape[-1] - 2 * MARGIN) * min(c["validation_rates"]))
        if minimum_length < 8 or data.train_x.shape[1:] != data.validation_x.shape[1:]:
            raise ValueError("common crop leaves insufficient samples or shapes differ")
        counts = np.bincount(data.validation_y, minlength=len(data.classes))
        result[dataset] = {"development_hash": development_hash(data),
            "train_shape": list(data.train_x.shape), "validation_shape": list(data.validation_x.shape),
            "minimum_view_length": minimum_length,
            "validation_missing_classes": [data.classes[i] for i in np.flatnonzero(counts == 0)],
            "macro_f1_class_count": len(data.classes), "training_started": False}
        del data
    return result


def rss_bytes():
    if os.name == "nt":
        import ctypes
        from ctypes import wintypes
        class Counters(ctypes.Structure):
            _fields_ = [("cb",wintypes.DWORD),("PageFaultCount",wintypes.DWORD),
                *[(name,ctypes.c_size_t) for name in ("PeakWorkingSetSize","WorkingSetSize",
                "QuotaPeakPagedPoolUsage","QuotaPagedPoolUsage","QuotaPeakNonPagedPoolUsage",
                "QuotaNonPagedPoolUsage","PagefileUsage","PeakPagefileUsage")]]
        counter = Counters(); counter.cb = ctypes.sizeof(counter)
        kernel = ctypes.WinDLL("kernel32",use_last_error=True)
        kernel.GetCurrentProcess.restype = wintypes.HANDLE
        psapi = ctypes.WinDLL("psapi",use_last_error=True)
        psapi.GetProcessMemoryInfo.argtypes = [wintypes.HANDLE,ctypes.POINTER(Counters),wintypes.DWORD]
        if not psapi.GetProcessMemoryInfo(kernel.GetCurrentProcess(),ctypes.byref(counter),counter.cb):
            raise OSError("could not inspect process RAM budget")
        return int(counter.WorkingSetSize)
    stat = Path("/proc/self/statm")
    if stat.exists():
        return int(stat.read_text().split()[1]) * os.sysconf("SC_PAGE_SIZE")
    return None


def guard(deadline, c, device):
    if time.monotonic() >= deadline:
        raise TimeoutError("envelope micro wall limit; keep checkpoint and resume same protocol")
    rss = rss_bytes()
    if rss is not None and rss > c["maximum_rss_gib"] * 2**30:
        raise MemoryError("process RAM budget exceeded")
    if device.type == "cuda" and torch.cuda.max_memory_allocated(device) > c["maximum_cuda_allocated_gib"] * 2**30:
        raise MemoryError("CUDA allocated budget exceeded")
    return rss


@torch.no_grad()
def evaluate(model, data, c, device, deadline):
    model.eval()
    def prediction(spec=None):
        ps=[]; metadata=None
        for start in range(0,len(data.validation_y),c["batch_size"]):
            guard(deadline,c,device)
            x=torch.from_numpy(data.validation_x[start:start+c["batch_size"]]).to(device)
            if spec is None:
                viewed, rate = nominal_view(x), data.rate
            else:
                viewed,rate,metadata=spec.apply(x,data.rate)
            ps.append(model(viewed,rate)["logits"].float().softmax(-1).cpu())
        probs=torch.cat(ps).numpy(); y=data.validation_y; pred=probs.argmax(-1)
        metrics={"macro_f1":float(f1_score(y,pred,labels=np.arange(len(data.classes)),average="macro",zero_division=0)),
            "nll":float(-np.log(np.maximum(probs[np.arange(len(y)),y],1e-8)).mean()),
            "prediction_class_count":len(np.unique(pred)), "observation":metadata}
        return metrics,pred
    nominal,_=prediction()
    families={}
    for name in ("train",*c["heldout_families"]):
        rates={}
        for ratio in c["validation_rates"]:
            outcomes=[prediction(spec) for spec in operator_family(ratio,name)]
            rates[str(ratio)]={"operators":[z[0] for z in outcomes],
                "worst_macro_f1":min(z[0]["macro_f1"] for z in outcomes),
                "mean_macro_f1":sum(z[0]["macro_f1"] for z in outcomes)/4,
                "all_operators_correct_accuracy":float(np.stack([pred==data.validation_y for _,pred in outcomes]).all(0).mean())}
        families[name]={"per_rate":rates,
            "mean_worst_macro_f1":sum(z["worst_macro_f1"] for z in rates.values())/len(rates),
            "mean_macro_f1":sum(z["mean_macro_f1"] for z in rates.values())/len(rates)}
    return {"nominal":nominal,"families":families,"checkpoint_rule":"fixed_final_epoch",
            "heldout_used_for_checkpoint_selection":False}


def train_cell(data,c,arm,seed,directory,device,deadline,digest,resume=False):
    directory.mkdir(parents=True,exist_ok=True)
    fingerprint=development_hash(data); metrics=directory/"metrics.json"
    identity={"protocol_hash":digest,"development_hash":fingerprint,"arm":arm,"seed":seed,"options":OPTIONS}
    if metrics.exists():
        previous=json.loads(metrics.read_text(encoding="utf-8"))
        if not resume or any(previous.get(k)!=v for k,v in identity.items()):
            raise ValueError("completed envelope cell cannot be overwritten or cross-protocol resumed")
        return previous
    started=time.monotonic(); model=make_model(data,c,OPTIONS,seed).to(device)
    initial_hash=hashlib.sha256(b"".join(v.detach().cpu().numpy().tobytes() for v in model.state_dict().values())).hexdigest()
    risk=AcquisitionRisk(4,arm,c["group_dro_step_size"]).to(device)
    optimizer=torch.optim.AdamW(model.parameters(),lr=c["learning_rate"],weight_decay=c["weight_decay"])
    history=[]; first_epoch=0; peak_rss=0; checkpoint=directory/"last.pt"
    if device.type=="cuda":torch.cuda.reset_peak_memory_stats(device)
    if resume and checkpoint.exists():
        state=torch.load(checkpoint,map_location=device,weights_only=False)
        if any(state.get(k)!=v for k,v in identity.items()):raise ValueError("checkpoint protocol mismatch")
        model.load_state_dict(state["model"]); risk.load_state_dict(state["risk"])
        optimizer.load_state_dict(state["optimizer"]); history=state["history"]; first_epoch=state["epoch"]
        restore_rng((state["rng"][0].cpu(),[v.cpu() for v in state["rng"][1]]))
    try:
        for epoch in range(first_epoch,c["epochs"]):
            generator=np.random.default_rng(seed+epoch)
            indices=generator.permutation(len(data.train_y)); steps=[]
            for batch,start in enumerate(range(0,len(indices),c["batch_size"])):
                if batch>=c["max_batches_per_epoch"]:break
                rss=guard(deadline,c,device); peak_rss=max(peak_rss,rss or 0)
                idx=indices[start:start+c["batch_size"]]
                x=torch.from_numpy(data.train_x[idx]).to(device); y=torch.from_numpy(data.train_y[idx]).long().to(device)
                ratio=float(generator.choice(c["train_rates"]))
                optimizer.zero_grad(set_to_none=True)
                step=backward_acquisition(model,x,y,data.rate,ratio,risk,step=batch)
                if not math.isfinite(step["total"]) or any(p.grad is not None and not torch.isfinite(p.grad).all() for p in model.parameters()):
                    raise FloatingPointError("nonfinite envelope loss/gradient")
                torch.nn.utils.clip_grad_norm_(model.parameters(),c["gradient_clip"]); optimizer.step()
                steps.append({**step,"ratio":ratio,"sample_ids":data.train_ids[idx].tolist()})
            history.append({"epoch":epoch+1,"steps":steps})
            torch.save({**identity,"model":model.state_dict(),"risk":risk.state_dict(),"optimizer":optimizer.state_dict(),
                "epoch":epoch+1,"history":history,"rng":rng_state()},checkpoint)
            _json(directory/"history.json",{"history":history,"test_accessed":False})
            print(f"{data.dataset_id} {arm} epoch {epoch+1}/{c['epochs']}: train_loss={sum(s['total'] for s in steps)/len(steps):.4f}",flush=True)
        validation=evaluate(model,data,c,device,deadline)
        schedule=[{"ratio":s["ratio"],"sample_ids":s["sample_ids"]} for h in history for s in h["steps"]]
        result={**identity,"status":"completed","dataset_id":data.dataset_id,"initial_state_hash":initial_hash,
            "parameters":sum(p.numel() for p in model.parameters() if p.requires_grad),"parameter_match":model.parameter_match,
            "epochs":len(history),"updates":len(schedule),"schedule_hash":hashlib.sha256(json.dumps(schedule).encode()).hexdigest(),
            "forward_passes":sum(s["forward_passes"] for h in history for s in h["steps"]),
            "backward_passes":sum(s["backward_passes"] for h in history for s in h["steps"]),
            "validation":validation,"train_ids":data.train_ids.tolist(),"validation_ids":data.validation_ids.tolist(),
            "group_weights":risk.log_group_weights.softmax(0).cpu().tolist(),"test_accessed":False,
            "seconds_this_session":time.monotonic()-started,"peak_rss_observed_mib":peak_rss/2**20,
            "peak_cuda_allocated_mib":torch.cuda.max_memory_allocated(device)/2**20 if device.type=="cuda" else 0.}
        _json(metrics,result);return result
    except BaseException as error:
        _json(directory/"failure.json",{**identity,"error":repr(error),"test_accessed":False})
        raise


def decision(rows,c):
    expected={(d,a) for d in DATASETS for a in MODES}
    keys=[(r["dataset_id"],r["arm"]) for r in rows]
    if len(keys)!=len(expected) or set(keys)!=expected:raise ValueError("incomplete or duplicated envelope matrix")
    by=dict(zip(keys,rows)); checks={}; deltas={}
    for d in DATASETS:
        mean,env=by[d,"mean"],by[d,"envelope"]
        for a in MODES:
            for field in ("initial_state_hash","parameters","options","updates","schedule_hash","development_hash"):
                if by[d,a][field]!=mean[field]:raise ValueError(f"unmatched {d}/{a}/{field}")
            if a!="ce" and any(by[d,a][k]!=mean[k] for k in ("forward_passes","backward_passes")):
                raise ValueError("main acquisition controls not compute matched")
        v,m=env["validation"],mean["validation"]
        checks[d+"_nominal_floor"]=v["nominal"]["macro_f1"]-m["nominal"]["macro_f1"]>=c["gates"]["nominal_floor_each_dataset"]
        checks[d+"_noncollapsed"]=v["nominal"]["prediction_class_count"]>1 and all(
            op["prediction_class_count"]>1 for f in v["families"].values() for rate in f["per_rate"].values() for op in rate["operators"])
        for family in c["heldout_families"]:
            score=v["families"][family]["mean_worst_macro_f1"]
            for a in ("mean","group_dro","batch_max"):
                delta=score-by[d,a]["validation"]["families"][family]["mean_worst_macro_f1"]
                deltas[f"{d}/{family}/vs_{a}"]=delta
                if d=="pamap2_uci":
                    threshold=c["gates"]["pamap_gain_vs_mean_each_heldout"] if a=="mean" else c["gates"]["pamap_gain_vs_group_dro_each_heldout"] if a=="group_dro" else 0.
                    checks[f"{d}_{family}_vs_{a}"]=delta>threshold if a=="batch_max" else delta>=threshold
                elif a=="mean":
                    checks[f"{d}_{family}_protection"]=delta>=c["gates"]["basicmotions_heldout_floor"]
    checks["pamap_training_family_floor"]=by["pamap2_uci","envelope"]["validation"]["families"]["train"]["mean_worst_macro_f1"]>=by["pamap2_uci","mean"]["validation"]["families"]["train"]["mean_worst_macro_f1"]
    return {"passed":all(checks.values()),"checks":{k:bool(v) for k,v in checks.items()},"deltas":deltas,
            "scope":"provisional_single_primary_dataset_development","automatic_next_stage":False}


def run(root,config_path,*,execute=False,preflight_only=False,resume=None,device_name="auto"):
    root=root.resolve();config_path=bounded(root,config_path)
    c=yaml.safe_load(config_path.read_text(encoding="utf-8"));validate_config(c)
    if preflight_only and (execute or resume is not None):raise ValueError("preflight cannot execute/resume")
    parent=parent_check(root,c);digest=protocol_hash(root,config_path)
    plan={"protocol_hash":digest,"parent":parent,"scope":"validation_only","datasets":c["datasets"],
        "arms":c["arms"],"seed":60919,"execution_requested":execute,"test_accessed":False,"automatic_followup":False}
    if not execute:
        if preflight_only:plan["preflight"]=preflight(root,c)
        return plan
    dashboard=root/"runs/dashboard_status.json"
    if dashboard.exists() and json.loads(dashboard.read_text(encoding="utf-8")).get("status")=="running":
        raise RuntimeError("another experiment running; dashboard untouched")
    stamp=datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S%fZ")
    directory=bounded(root,resume if resume else root/"runs/v6_envelope"/f"micro__{stamp}",output=True)
    if resume:
        old=json.loads((directory/"manifest.json").read_text(encoding="utf-8"))
        if old["protocol_hash"]!=digest or old["parent"]!=parent:raise ValueError("resume protocol mismatch")
    deadline=time.monotonic()+c["wall_seconds"]
    plan["preflight"]=preflight(root,c)
    torch.set_num_threads(c["threads"])
    device=torch.device("cuda" if device_name=="auto" and torch.cuda.is_available() else "cpu" if device_name=="auto" else device_name)
    guard(deadline,c,device)
    directory.mkdir(parents=True,exist_ok=resume is not None)
    (directory/"config_frozen.yaml").write_bytes(config_path.read_bytes())
    order=list(c["arms"]);random.Random(60919).shuffle(order)
    plan.update(run_directory=str(directory),arm_order=order,runtime={"device":str(device),"torch":torch.__version__,"threads":c["threads"]})
    _json(directory/"manifest.json",{**plan,"status":"running"});rows=[]
    try:
        for dataset in DATASETS:
            data=load_development(root/c["cache_root"]/f"{dataset}.npz",c)
            if development_hash(data)!=plan["preflight"][dataset]["development_hash"]:raise ValueError("cache changed after preflight")
            for arm in order:
                guard(deadline,c,device)
                rows.append(train_cell(data,c,arm,60919,directory/f"{dataset}__{arm}__60919",device,deadline,digest,resume is not None))
                _json(directory/"partial.json",{"rows":rows,"test_accessed":False})
        result={**plan,"status":"completed","rows":rows,"decision":decision(rows,c)}
        _json(directory/"report.json",result);_json(directory/"manifest.json",{**plan,"status":"completed"})
        return result
    except BaseException as error:
        _json(directory/"manifest.json",{**plan,"status":"bounded_stop" if isinstance(error,TimeoutError) else "failed", "error":repr(error),"completed_cells":len(rows)})
        raise


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config",default="configs/experiments/v6_acquisition_envelope_micro.yaml")
    parser.add_argument("--execute",action="store_true");parser.add_argument("--preflight",action="store_true")
    parser.add_argument("--resume",type=Path);parser.add_argument("--device",choices=("auto","cpu","cuda"),default="auto")
    args=parser.parse_args();root=Path(__file__).resolve().parents[4]
    result=run(root,root/args.config,execute=args.execute,preflight_only=args.preflight,resume=args.resume,device_name=args.device)
    print(json.dumps({k:v for k,v in result.items() if k!="rows"},indent=2,ensure_ascii=False,allow_nan=False))
