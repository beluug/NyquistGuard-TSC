"""Downstream-identical ordinary-front control for NyquistGuard-TSC V5.1."""

from __future__ import annotations

import math
from typing import Optional

import torch
from torch import Tensor, nn

from nyquistguard.models.physical_filterbank import normalize_sampling_rates, validate_padding_mask
from nyquistguard.research.v5_dual_path import DualPathNyquistGuardTSC, _masked_channel_standardize


class PointwiseOrdinaryFront(nn.Module):
    """Rate-independent learned channel mixing with matched active parameters.

    Conv1d contributes C*K parameters and affine GroupNorm contributes 2*K,
    exactly matching the C*K channel logits plus 2*K physical parameters in
    the V5.1 Gabor bank.  All parameters participate in the forward pass.
    """

    def __init__(self, input_channels: int, num_bands: int) -> None:
        super().__init__()
        self.input_channels = int(input_channels)
        self.num_bands = int(num_bands)
        self.projection = nn.Conv1d(input_channels, num_bands, 1, bias=False)
        self.normalization = nn.GroupNorm(num_bands, num_bands, affine=True)
        self.activation = nn.SiLU()

    def forward(
        self,
        x: Tensor,
        sampling_rate_hz: float | Tensor,
        padding_mask: Optional[Tensor] = None,
    ) -> Tensor:
        del sampling_rate_hz
        mask = validate_padding_mask(x, padding_mask)
        features = self.activation(self.normalization(self.projection(x)))
        return features.masked_fill(mask.unsqueeze(1), 0.0)


class MatchedOrdinaryDualPath(DualPathNyquistGuardTSC):
    """V5.1 downstream with only the physical front/gate mechanism replaced.

    The signed path, both temporal encoders, rich summaries, adaptive fusion,
    cross-path residual, normalization, and classifier remain unchanged.  The
    simple rate scalar remains in the shared fusion controller; this makes the
    control stricter by asking whether the complex Gabor/gate path adds value
    beyond generic rate metadata and multirate training.
    """

    def __init__(self, *args, **kwargs) -> None:
        super().__init__(*args, **kwargs)
        self.filterbank = PointwiseOrdinaryFront(self.input_channels, self.num_bands)
        self.filterbank_type = "matched_pointwise_ordinary"
        self.nyquist_gate_mode = "absent_ordinary_front"

    def forward(
        self,
        x: Tensor,
        sampling_rate_hz: float | Tensor,
        padding_mask: Optional[Tensor] = None,
        timestamps: Optional[Tensor] = None,
    ) -> dict[str, Tensor | dict]:
        if x.ndim != 3 or x.shape[1] != self.input_channels:
            raise ValueError(f"x must have shape [B,{self.input_channels},T]")
        rates = normalize_sampling_rates(sampling_rate_hz, x.shape[0], device=x.device)
        resolved_mask = validate_padding_mask(x, padding_mask)
        timestamps = self._validate_timestamps(timestamps, resolved_mask, rates)

        unpooled = self.filterbank(x, rates, resolved_mask)
        band_features = self.time_pool(unpooled, resolved_mask, timestamps)
        analytic = band_features.new_ones((x.shape[0], self.num_bands))
        # Keep the K matched floor parameters active as an ordinary per-band
        # calibration.  The factor two makes the registered 0.5 initialization
        # an identity multiplier.
        floor = self.gate_floor.to(band_features.dtype)
        multiplier = 2.0 * floor.unsqueeze(0)
        classifier_features = band_features * multiplier.unsqueeze(-1)
        first_sequence, _ = self.encoder(classifier_features)
        first_embedding = self.physical_summary(first_sequence)

        standardized = _masked_channel_standardize(
            x, resolved_mask, self.input_standardization_epsilon
        )
        spatial_unpooled = self.spatial_projection(standardized)
        spatial_features = self.time_pool(spatial_unpooled, resolved_mask, timestamps)
        spatial_sequence, _ = self.spatial_encoder(spatial_features)
        spatial_embedding = self.spatial_summary(spatial_sequence)

        rate_feature = torch.log2(
            rates.float().clamp_min(1e-6) / self.reference_sampling_rate_hz
        ).clamp(-4.0, 4.0)
        controller_features = torch.stack(
            (rate_feature, analytic.mean(dim=1), analytic.amin(dim=1)), dim=1
        ).to(dtype=first_embedding.dtype)
        first_weight = torch.sigmoid(self.fusion_controller(controller_features))
        convex_embedding = first_weight * first_embedding + (1.0 - first_weight) * spatial_embedding
        cross_residual = self.cross_path_residual(
            torch.cat((first_embedding, spatial_embedding), dim=1)
        )
        embedding = self.fusion_norm(convex_embedding + cross_residual)

        logits = self.classifier(embedding)
        probabilities = torch.softmax(logits.float(), dim=-1)
        entropy = -(probabilities * probabilities.clamp_min(1e-8).log()).sum(dim=-1)
        normalized_entropy = entropy / math.log(self.num_classes)
        if self.selective_head is None:
            accept_logit = embedding.new_zeros((x.shape[0],))
        else:
            accept_logit = self.selective_head(
                embedding, analytic, rates, normalized_entropy.to(embedding.dtype)
            )
        return {
            "logits": logits,
            "accept_logit": accept_logit,
            "accept_probability": torch.sigmoid(accept_logit),
            "band_features": band_features,
            "gated_band_features": classifier_features,
            "nyquist_gate": analytic,
            "effective_gate_multiplier": multiplier,
            "gate_floor": floor,
            "spatial_features": spatial_features,
            "physical_embedding": first_embedding,
            "spatial_embedding": spatial_embedding,
            "fusion_physical_weight": first_weight.squeeze(1),
            "embedding": embedding,
            "aux": {
                "sampling_rate_hz": rates,
                "valid_lengths": (~resolved_mask).sum(dim=1),
                "encoded_sequence": first_sequence,
                "spatial_encoded_sequence": spatial_sequence,
                "normalized_prediction_entropy": normalized_entropy,
                "filterbank_type": self.filterbank_type,
                "nyquist_gate_enabled": False,
                "nyquist_gate_mode": self.nyquist_gate_mode,
                "selective_head_enabled": self.use_selective_head,
                "classifier_uses_observability_attenuation": False,
                "signed_spatial_bypass_enabled": True,
                "temporal_statistics_summary": ("mean", "standard_deviation", "maximum"),
                "ordinary_front_rate_conditioned": False,
                "fusion_controller_receives_rate_scalar": True,
            },
        }


def exact_parameter_match(
    physical: DualPathNyquistGuardTSC,
    ordinary: MatchedOrdinaryDualPath,
) -> dict[str, int | float | bool]:
    physical_parameters = sum(p.numel() for p in physical.parameters() if p.requires_grad)
    ordinary_parameters = sum(p.numel() for p in ordinary.parameters() if p.requires_grad)
    difference = ordinary_parameters - physical_parameters
    return {
        "physical_parameters": physical_parameters,
        "ordinary_parameters": ordinary_parameters,
        "difference": difference,
        "relative_difference": difference / physical_parameters,
        "exact": difference == 0,
        "dummy_parameters": 0,
    }

