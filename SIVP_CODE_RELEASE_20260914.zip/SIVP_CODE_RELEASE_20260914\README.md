﻿SIVP CODE RELEASE CANDIDATE

Target repository: https://github.com/beluug/NyquistGuard-TSC
Release date: 2026-09-14

This bundle contains the complete nyquistguard source tree plus the frozen cross-task TRAIN-only OOF runner, configuration, protocol, and tests. It contains no raw datasets, caches, checkpoints, or TEST predictions.

Run entry point:
scripts/run_sivp_cross_task_attribution.py

Frozen configuration:
configs/experiments/sivp_cross_task_attribution_train_oof.yaml

The run must not read validation or TEST members. See docs/SIVP_CROSS_TASK_ATTRIBUTION_PROTOCOL.md.
