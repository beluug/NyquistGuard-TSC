"""Bounded TRAIN-only OOF experiment. All old methods and results are read-only."""
import argparse
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import time

import numpy as np
from sklearn.metrics import f1_score
import torch
import torch.nn.functional as F
import yaml

from nyquistguard.research.v6.runner import _json, make_model
from nyquistguard.research.v6_envelope.runner import OPTIONS, guard, protocol_hash as envelope_hash
from nyquistguard.research.v6_envelope.training import backward_acquisition
from nyquistguard.losses.v6_acquisition_risk import AcquisitionRisk
from nyquistguard.research.v6_envelope.operators import nominal_view
from .core import load_train, fingerprint, folds, standardize_fit, views, energy_descriptors, error_masks

FAMILY = ("high_reference", "filtered_dense", "canonical_low", "lifted_low", "phase_only", "filter_only", "joint", "window_only")


def protocol_hash(root, path):
    h = hashlib.sha256(envelope_hash(root, root / "configs/experiments/v6_acquisition_envelope_micro.yaml").encode())
    for file in [path, root / "docs/V6_TRAIN_OOF_PROBE_PROTOCOL.md", root / "scripts/run_v6_train_probe.py",
                 *sorted((root / "src/nyquistguard/research/v6_train_probe").glob("*.py"))]:
        h.update(str(file.relative_to(root)).encode()); h.update(file.read_bytes())
    return h.hexdigest()


def validate_config(c):
    expected = {"protocol_version": "v6_train_oof_probe_v1", "scope": "train_only_oof", "automatic_followup": False,
        "datasets": ["basicmotions_uea", "pamap2_uci"], "seed": 60923, "cap_seed": 60908, "train_cap": 256,
        "arms": ["nominal_ce", "multirate_mean"], "cache_root": "data/processed/pilot_v1",
        "updates": 64, "batch_size": 16, "train_rates": [.35, .5, .7], "evaluation_rates": [.9, .6, .4, .3],
        "wall_seconds": 600, "maximum_rss_gib": 6, "maximum_cuda_allocated_gib": 2}
    for k, v in expected.items():
        if c.get(k) != v:
            raise ValueError(f"registered TRAIN probe changed: {k}")


def prepare(root, c):
    data, info = {}, {}
    for name in c["datasets"]:
        d = load_train(root / c["cache_root"] / f"{name}.npz", c["train_cap"], c["cap_seed"])
        if d.dataset_id != name:
            raise ValueError("TRAIN cache identity mismatch")
        partition = folds(d, c["seed"])
        info[name] = {"fingerprint": fingerprint(d), "shape": list(d.train_x.shape), "classes": d.classes,
            "folds": [{"index": i, "group": g, "fit_count": len(a), "held_count": len(b),
                "fit_ids": d.train_ids[a].tolist(), "held_ids": d.train_ids[b].tolist()} for i, (a, b, g) in enumerate(partition)],
            "validation_read": False, "test_read": False}
        data[name] = d
    return data, info


def metrics(probs, y, classes):
    pred = probs.argmax(-1)
    return {"probabilities": probs.tolist(), "predictions": pred.tolist(),
        "accuracy": float(np.mean(pred == y)),
        "macro_f1": float(f1_score(y, pred, labels=np.arange(classes), average="macro", zero_division=0)),
        "nll": float(-np.log(np.maximum(probs[np.arange(len(y)), y], 1e-8)).mean())}


@torch.no_grad()
def evaluate(model, x, y, rate, c, device, deadline, *, nominal_only=False):
    model.eval(); collected = {}; energies = {str(r): {} for r in c["evaluation_rates"]}
    for start in range(0, len(y), c["batch_size"]):
        guard(deadline, c, device)
        batch = torch.from_numpy(x[start:start + c["batch_size"]]).to(device)
        observations = {"nominal": (nominal_view(batch), rate)}
        if not nominal_only:
            for r in c["evaluation_rates"]:
                observations.update({f"{r}/{k}": v for k, v in views(batch, rate, r).items()})
                for k, values in energy_descriptors(batch, r).items():
                    energies[str(r)].setdefault(k, []).extend(values)
        for key, (v, f) in observations.items():
            guard(deadline, c, device)
            collected.setdefault(key, []).append(model(v, f)["logits"].softmax(-1).cpu().numpy())
    return {"conditions": {k: metrics(np.concatenate(v), y, model.num_classes) for k, v in collected.items()},
        "energy": {} if nominal_only else energies}


def train_cell(d, fold_index, partition, arm, c, directory, device, deadline, digest):
    fit, held, group = partition
    x, scaling = standardize_fit(d.train_x, fit)
    directory.mkdir(parents=True, exist_ok=False)
    model = make_model(d, c, OPTIONS, c["seed"] + fold_index).to(device)
    initial_hash = hashlib.sha256(b"".join(v.cpu().numpy().tobytes() for v in model.state_dict().values())).hexdigest()
    optimizer = torch.optim.AdamW(model.parameters(), lr=c["learning_rate"], weight_decay=c["weight_decay"])
    risk = AcquisitionRisk(4, "mean").to(device)
    generator = np.random.default_rng(c["seed"] + fold_index)
    history = []; schedule = []; queue = []; started = time.monotonic(); peak_rss = 0
    if device.type == "cuda":
        torch.cuda.reset_peak_memory_stats(device)
    try:
        for step in range(c["updates"]):
            peak_rss = max(peak_rss, guard(deadline, c, device) or 0)
            if not queue:
                queue = generator.permutation(fit).tolist()
            idx, queue = queue[:c["batch_size"]], queue[c["batch_size"]:]
            r = float(generator.choice(c["train_rates"]))
            bx = torch.from_numpy(x[idx]).to(device); by = torch.from_numpy(d.train_y[idx]).long().to(device)
            optimizer.zero_grad(set_to_none=True)
            if arm == "multirate_mean":
                entry = backward_acquisition(model, bx, by, d.rate, r, risk)
            else:
                model.train(); loss = F.cross_entropy(model(nominal_view(bx), d.rate)["logits"], by)
                loss.backward(); entry = {"total": float(loss.detach()), "forward_passes": 1, "backward_passes": 1}
            if not np.isfinite(entry["total"]) or any(p.grad is not None and not torch.isfinite(p.grad).all() for p in model.parameters()):
                raise FloatingPointError("nonfinite TRAIN probe loss/gradient")
            torch.nn.utils.clip_grad_norm_(model.parameters(), c["gradient_clip"]); optimizer.step()
            history.append(entry); schedule.append({"ids": d.train_ids[idx].tolist(), "ratio": r})
            if (step + 1) % 16 == 0:
                print(f"{d.dataset_id} {group} {arm} update {step + 1}/{c['updates']}: loss={entry['total']:.4f}", flush=True)
        fit_eval = evaluate(model, x[fit], d.train_y[fit], d.rate, c, device, deadline, nominal_only=True)
        held_eval = evaluate(model, x[held], d.train_y[held], d.rate, c, device, deadline)
        row = {"dataset_id": d.dataset_id, "fold": fold_index, "group": group, "arm": arm,
            "protocol_hash": digest, "train_fingerprint": fingerprint(d), "initial_state_hash": initial_hash,
            "parameters": sum(p.numel() for p in model.parameters()), "parameter_match": model.parameter_match,
            "fit_ids": d.train_ids[fit].tolist(), "held_ids": d.train_ids[held].tolist(), "held_labels": d.train_y[held].tolist(),
            "updates": len(history), "schedule_hash": hashlib.sha256(json.dumps(schedule).encode()).hexdigest(),
            "fit_nominal": {k: v for k, v in fit_eval["conditions"]["nominal"].items() if k not in ("probabilities", "predictions")},
            "evaluation": held_eval, "standardization": scaling, "status": "completed", "history": history,
            "validation_read": False, "test_read": False, "seconds": time.monotonic() - started,
            "peak_rss_observed_mib": peak_rss / 2**20,
            "peak_cuda_allocated_mib": torch.cuda.max_memory_allocated(device) / 2**20 if device.type == "cuda" else 0.}
        torch.save({"model": model.state_dict(), "optimizer": optimizer.state_dict(), "updates": len(history),
            "protocol_hash": digest, "standardization": scaling}, directory / "final.pt")
        _json(directory / "schedule.json", {"schedule": schedule})
        _json(directory / "metrics.json", row)
        return row
    except BaseException as e:
        torch.save({"model": model.state_dict(), "optimizer": optimizer.state_dict(), "updates": len(history),
            "protocol_hash": digest}, directory / "interrupted.pt")
        _json(directory / "failure.json", {"error": repr(e), "completed_updates": len(history), "history": history})
        raise


def select_lead(records, fit_accuracies):
    if not records:
        raise ValueError("no OOF records")
    def selected(key): return [r for r in records if r[key]]
    def support(rs): return {"observations": len(rs), "unique_windows": len({r["id"] for r in rs}), "groups": len({r["group"] for r in rs})}
    rate = selected("rate_added"); nuisance = selected("nuisance_added"); stable = selected("stable")
    repaired = selected("rate_lift_repaired"); filtered = selected("rate_filter_wrong")
    h = sum(r["high_correct"] for r in records); hc = sum(r["high_correct"] and r["canonical_correct"] for r in records)
    rs, ns, ls = support(rate), support(nuisance), support(repaired)
    healthy = min(fit_accuracies) >= .85 and h / len(records) >= .65
    rate_opportunity = rs["unique_windows"] >= 10 and rs["groups"] >= 3 and len(rate) / max(1, h) >= .05
    nuisance_opportunity = ns["unique_windows"] >= 10 and ns["groups"] >= 3 and len(nuisance) / max(1, hc) >= .05
    energy_gap = float(np.median([r["above_low_nyquist"] for r in rate]) - np.median([r["above_low_nyquist"] for r in stable])) if rate and stable else None
    group_gaps = {}
    for g in sorted({r["group"] for r in records}):
        a = [r["above_low_nyquist"] for r in rate if r["group"] == g]
        b = [r["above_low_nyquist"] for r in stable if r["group"] == g]
        if len(a) >= 2 and len(b) >= 2:
            group_gaps[g] = float(np.median(a) - np.median(b))
    grid = rate_opportunity and len(repaired) / max(1, len(rate)) >= .5 and ls["unique_windows"] >= 10 and ls["groups"] >= 3
    spectral = rate_opportunity and len(filtered) / max(1, len(rate)) >= .5 and energy_gap is not None and energy_gap >= .1 and sum(v > 0 for v in group_gaps.values()) >= 3
    lead = ("BASELINE_OR_GROUP_SHIFT_LIMITATION" if not healthy else "GRID_REPRESENTATION_LEAD" if grid else
        "SPECTRAL_INFORMATION_LEAD" if spectral else "ACQUISITION_NUISANCE_LEAD" if nuisance_opportunity else
        "RATE_ERROR_UNRESOLVED" if rate_opportunity else "INSUFFICIENT_SAMPLING_SPECIFIC_SIGNAL")
    return {"lead": lead, "method_go": False, "healthy": healthy, "min_fit_nominal_accuracy": min(fit_accuracies),
        "oof_high_accuracy": h / len(records), "rate_support": rs, "nuisance_support": ns,
        "lift_repair_support": ls, "rate_conditional_fraction": len(rate) / max(1, h),
        "nuisance_conditional_fraction": len(nuisance) / max(1, hc),
        "lift_repair_fraction_of_rate_added": len(repaired) / max(1, len(rate)),
        "filtered_wrong_fraction_of_rate_added": len(filtered) / max(1, len(rate)),
        "high_energy_median_gap": energy_gap, "high_energy_group_gaps": group_gaps,
        "rate_opportunity": rate_opportunity, "nuisance_opportunity": nuisance_opportunity,
        "grid_lead_criteria": grid, "spectral_lead_criteria": spectral}


def summarize(rows, c):
    summaries = {}; all_records = []
    for dataset in c["datasets"]:
        for arm in c["arms"]:
            cells = [r for r in rows if r["dataset_id"] == dataset and r["arm"] == arm]
            expected_folds = 2 if dataset == "basicmotions_uea" else 5
            if len(cells) != expected_folds or len({r["fold"] for r in cells}) != expected_folds:
                raise ValueError("incomplete OOF cells")
            ids = [i for r in cells for i in r["held_ids"]]
            if len(set(ids)) != len(ids): raise ValueError("repeated OOF records")
            per_rate = {}; records = []
            for ratio in c["evaluation_rates"]:
                y = np.concatenate([r["held_labels"] for r in cells]); probs = {}
                for view in FAMILY:
                    probs[view] = np.concatenate([r["evaluation"]["conditions"][f"{ratio}/{view}"]["probabilities"] for r in cells])
                correct = {v: p.argmax(-1) == y for v, p in probs.items()}; masks = error_masks(correct)
                count = {k: int(v.sum()) for k, v in masks.items()}
                if sum(count[k] for k in ("baseline_wrong", "rate_added", "nuisance_added", "stable")) != len(y):
                    raise ValueError("error partition inconsistent")
                per_rate[str(ratio)] = {"n": len(y), "counts": count,
                    "views": {k: {n: z for n, z in metrics(p, y, p.shape[1]).items() if n not in ("predictions", "probabilities")} for k, p in probs.items()}}
                index = 0
                for cell in cells:
                    for local, id_value in enumerate(cell["held_ids"]):
                        rec = {"dataset": dataset, "arm": arm, "id": id_value, "group": cell["group"], "ratio": ratio,
                            "high_correct": bool(correct["high_reference"][index]), "canonical_correct": bool(correct["canonical_low"][index]),
                            **{k: bool(v[index]) for k, v in masks.items()},
                            **{k: v[local] for k, v in cell["evaluation"]["energy"][str(ratio)].items()}}
                        records.append(rec); index += 1
            result = {"per_rate": per_rate, "fit_nominal_accuracy": [r["fit_nominal"]["accuracy"] for r in cells],
                "groups": [{"group": r["group"], "held_n": len(r["held_ids"]), "fit_accuracy": r["fit_nominal"]["accuracy"]} for r in cells]}
            if dataset == "pamap2_uci" and arm == "multirate_mean":
                result["selection"] = select_lead(records, result["fit_nominal_accuracy"])
            summaries[f"{dataset}/{arm}"] = result; all_records.extend(records)
    return summaries, all_records


def run(root, config_path, *, execute=False, preflight=False, resume=None, device_name="auto"):
    c = yaml.safe_load(config_path.read_text(encoding="utf-8")); validate_config(c)
    digest = protocol_hash(root, config_path)
    plan = {"scope": c["scope"], "protocol_hash": digest, "execution_requested": execute,
        "validation_read": False, "test_read": False, "automatic_followup": False, "expected_cells": 14}
    if not execute and not preflight: return plan
    if preflight and execute: raise ValueError("choose preflight or execute")
    deadline = time.monotonic() + c["wall_seconds"]
    data, info = prepare(root, c)
    plan["preflight"] = info
    if not execute: return plan
    dashboard = root / "runs/dashboard_status.json"
    if dashboard.exists() and json.loads(dashboard.read_text(encoding="utf-8")).get("status") == "running":
        raise RuntimeError("another experiment running; dashboard untouched")
    directory = (resume if resume else root / "runs/v6_train_probe" / ("oof__" + datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S%fZ"))).resolve()
    boundary = (root / "runs/v6_train_probe").resolve()
    if boundary not in directory.parents: raise ValueError("output escapes TRAIN probe boundary")
    if resume:
        previous = json.loads((directory / "manifest.json").read_text(encoding="utf-8"))
        if previous["protocol_hash"] != digest or previous["preflight"] != json.loads(json.dumps(info)):
            raise ValueError("resume identity mismatch")
    torch.set_num_threads(c["threads"])
    device = torch.device("cuda" if device_name == "auto" and torch.cuda.is_available() else "cpu" if device_name == "auto" else device_name)
    guard(deadline, c, device)
    directory.mkdir(parents=True, exist_ok=resume is not None)
    if not resume: (directory / "config_frozen.yaml").write_bytes(config_path.read_bytes())
    plan.update(run_directory=str(directory), runtime={"device": str(device), "torch": torch.__version__})
    _json(directory / "manifest.json", {**plan, "status": "running"}); rows = []
    try:
        for d in data.values():
            for i, partition in enumerate(folds(d, c["seed"])):
                paired = []
                for arm in c["arms"]:
                    cell = directory / f"{d.dataset_id}__fold{i}__{arm}"
                    if cell.exists():
                        if not resume or not (cell / "metrics.json").exists():
                            raise ValueError("incomplete cell preserved; automatic retraining forbidden")
                        row = json.loads((cell / "metrics.json").read_text(encoding="utf-8"))
                        if row["protocol_hash"] != digest or row["train_fingerprint"] != fingerprint(d): raise ValueError("cell identity mismatch")
                    else:
                        row = train_cell(d, i, partition, arm, c, cell, device, deadline, digest)
                    paired.append(row); rows.append(row)
                    _json(directory / "partial.json", {"rows": rows})
                for key in ("initial_state_hash", "schedule_hash", "fit_ids", "held_ids", "parameters", "updates"):
                    if paired[0][key] != paired[1][key]: raise ValueError("unmatched probe arms: " + key)
        summary, records = summarize(rows, c)
        result = {**plan, "status": "completed", "rows": rows, "summary": summary,
            "selection": summary["pamap2_uci/multirate_mean"]["selection"], "seconds_execute_including_preflight": c["wall_seconds"] - (deadline - time.monotonic())}
        _json(directory / "oof_records.json", {"records": records, "validation_read": False, "test_read": False})
        _json(directory / "report.json", result)
        _json(directory / "manifest.json", {**plan, "status": "completed"})
        return result
    except BaseException as e:
        _json(directory / "manifest.json", {**plan, "status": "failed", "error": repr(e), "completed_cells": len(rows)})
        raise


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--execute", action="store_true"); parser.add_argument("--preflight", action="store_true")
    parser.add_argument("--resume", type=Path); parser.add_argument("--device", choices=("auto", "cpu", "cuda"), default="auto")
    args = parser.parse_args(); root = Path(__file__).resolve().parents[4]
    result = run(root, root / "configs/experiments/v6_train_oof_probe.yaml", execute=args.execute,
        preflight=args.preflight, resume=args.resume, device_name=args.device)
    print(json.dumps({k: v for k, v in result.items() if k not in ("rows", "preflight", "summary")}, indent=2))


if __name__ == "__main__": main()
