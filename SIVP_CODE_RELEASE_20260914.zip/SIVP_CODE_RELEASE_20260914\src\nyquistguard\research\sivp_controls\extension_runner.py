"""One-time validation-only continuation of decisive-control cells to epoch 60."""

from __future__ import annotations

import argparse
from datetime import datetime, timezone
import hashlib
import json
import math
from pathlib import Path
import shutil
import time

import numpy as np
import torch
from torch import nn
from torch.utils.data import DataLoader, TensorDataset
import yaml

from nyquistguard.data import full_cache_path
from . import controlled_runner as base


def _json(path: Path, value: object) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(
        json.dumps(value, indent=2, ensure_ascii=False, allow_nan=False), encoding="utf-8"
    )
    temporary.replace(path)


def _sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def _extension_hash(root: Path, config_path: Path) -> str:
    digest = hashlib.sha256()
    for path in (
        config_path,
        root / "docs/SIVP_DECISIVE_CONTROLS_EXTENSION_PROTOCOL.md",
        root / "scripts/run_sivp_decisive_controls_extension.py",
        Path(__file__),
        Path(base.__file__),
        Path(base.__file__).with_name("models.py"),
    ):
        digest.update(str(path.relative_to(root)).encode())
        digest.update(path.read_bytes())
    return digest.hexdigest()


def _validate_extension_config(config: dict) -> None:
    required = {
        "protocol_version": "sivp_decisive_controls_extension_to_60_v1",
        "scope": "train_validation_extension_only",
        "automatic_test_stage": False,
        "source_epoch": 45,
        "target_epoch": 60,
    }
    for key, expected in required.items():
        if config.get(key) != expected:
            raise ValueError(f"extension config mismatch for {key}")
    boundaries = config.get("scientific_boundaries", {})
    if boundaries != {
        "test_accessed": False,
        "continue_optimizer_state": True,
        "continue_scaler_state": True,
        "retain_best_checkpoint_from_epochs_1_to_60": True,
        "all_cells_of_every_affected_dataset": True,
        "no_second_extension": True,
        "no_automatic_test_stage": True,
    }:
        raise ValueError("extension scientific boundaries changed")


def _source_rows(report: dict) -> dict[tuple[str, str, str, int], dict]:
    if report.get("status") != "completed_validation_undertrained":
        raise ValueError("source run is not a completed undertrained validation run")
    if report.get("test_accessed") is not False or report.get("retrospective_test_permitted") is not False:
        raise ValueError("source TEST boundary is invalid")
    rows = report.get("rows", [])
    if len(rows) != 120:
        raise ValueError(f"source run has {len(rows)} rather than 120 cells")
    indexed = {}
    for row in rows:
        key = (row["dataset_id"], row["family"], row["regime"], int(row["seed"]))
        if key in indexed:
            raise ValueError(f"duplicate source cell: {key}")
        if (
            row.get("status") != "completed"
            or row.get("epochs_completed") != 45
            or row.get("test_accessed") is not False
        ):
            raise ValueError(f"invalid source cell: {key}")
        indexed[key] = row
    return indexed


def preflight(root: Path, config: dict) -> dict:
    source_run = (root / config["source_run"]).resolve()
    if root not in source_run.parents or not source_run.is_dir():
        raise ValueError("source run is missing or outside project")
    source_report_path = source_run / "report.json"
    source_config_path = source_run / "config_frozen.yaml"
    if _sha256(source_report_path) != config["source_report_sha256"]:
        raise ValueError("source report hash mismatch")
    if _sha256(source_config_path) != config["source_config_sha256"]:
        raise ValueError("source frozen config hash mismatch")
    source_report = json.loads(source_report_path.read_text(encoding="utf-8"))
    if source_report.get("protocol_hash") != config["source_protocol_hash"]:
        raise ValueError("source protocol hash mismatch")
    indexed = _source_rows(source_report)
    source_config = yaml.safe_load(source_config_path.read_text(encoding="utf-8"))
    base._validate_config(source_config)
    base_config = yaml.safe_load((root / source_config["base_config"]).read_text(encoding="utf-8"))
    cache_check = base.preflight(root, source_config, base_config)
    affected = sorted({
        row["dataset_id"] for row in indexed.values() if row["undertraining"]["flagged"]
    })
    if affected != sorted(source_config["datasets"]):
        raise ValueError("this frozen extension expects every source dataset to be affected")
    required_names = (
        "checkpoint_best.pt", "checkpoint_last.pt", "history.json", "schedule.json", "metrics.json"
    )
    source_artifacts = {}
    for key, row in indexed.items():
        dataset_id, family, regime, seed = key
        cell_name = f"{dataset_id}__{family}_{regime}__seed{seed}"
        cell_directory = source_run / cell_name
        paths = [cell_directory / name for name in required_names]
        if not all(path.is_file() for path in paths):
            raise ValueError(f"source artifacts incomplete: {cell_name}")
        history = json.loads((cell_directory / "history.json").read_text(encoding="utf-8"))["history"]
        if len(history) != config["source_epoch"]:
            raise ValueError(f"source history length mismatch: {cell_name}")
        checkpoint = torch.load(
            cell_directory / "checkpoint_last.pt", map_location="cpu", weights_only=True
        )
        if (
            checkpoint.get("epoch") != config["source_epoch"]
            or checkpoint.get("protocol_hash") != row["protocol_hash"]
        ):
            raise ValueError(f"source checkpoint identity mismatch: {cell_name}")
        source_artifacts[cell_name] = {name: _sha256(cell_directory / name) for name in required_names}
    return {
        "status": "passed",
        "source_run": str(source_run),
        "source_protocol_hash": source_report["protocol_hash"],
        "source_cells": len(indexed),
        "affected_datasets": affected,
        "extension_cells": len(indexed),
        "source_artifacts": source_artifacts,
        "cache_check": cache_check,
        "test_accessed": False,
        "training_started": False,
    }


def _extend_cell(
    data: base.DevelopmentDataset,
    base_config: dict,
    train_config: dict,
    extension_config: dict,
    source_row: dict,
    source_directory: Path,
    directory: Path,
    device: torch.device,
    protocol_hash: str,
) -> dict:
    if directory.exists():
        raise FileExistsError("extension cells are immutable")
    directory.mkdir(parents=True)
    if device.type == "cuda":
        torch.cuda.reset_peak_memory_stats(device)
    family = source_row["family"]
    regime = source_row["regime"]
    seed = int(source_row["seed"])
    model = base._model(data, base_config, family, seed, device)
    optimizer = torch.optim.AdamW(
        model.parameters(), lr=train_config["learning_rate"],
        weight_decay=train_config["weight_decay"],
    )
    scaler = torch.amp.GradScaler(
        "cuda", enabled=device.type == "cuda",
        init_scale=float(train_config["amp_initial_scale"]),
        growth_interval=int(train_config["amp_growth_interval"]),
    )
    checkpoint = torch.load(
        source_directory / "checkpoint_last.pt", map_location=device, weights_only=True
    )
    model.load_state_dict(checkpoint["model"])
    optimizer.load_state_dict(checkpoint["optimizer"])
    scaler.load_state_dict(checkpoint["scaler"])
    if checkpoint["epoch"] != extension_config["source_epoch"]:
        raise ValueError("extension did not load epoch-45 state")
    history = json.loads((source_directory / "history.json").read_text(encoding="utf-8"))["history"]
    schedule_rows = json.loads(
        (source_directory / "schedule.json").read_text(encoding="utf-8")
    )["schedule"]
    history = list(history)
    schedule_rows = list(schedule_rows)
    if len(history) != extension_config["source_epoch"]:
        raise ValueError("source history is not 45 epochs")
    best_score = float(checkpoint["best_score"])
    best_epoch = int(checkpoint["best_epoch"])
    shutil.copy2(source_directory / "checkpoint_best.pt", directory / "checkpoint_best.pt")
    filter_regularizer = base._filter_regularizer(model, base_config) if family == "physical" else None
    training = TensorDataset(torch.from_numpy(data.train.x), torch.from_numpy(data.train.y).long())
    extension_retries = []
    started = time.monotonic()
    for epoch in range(extension_config["source_epoch"] + 1, extension_config["target_epoch"] + 1):
        loader = DataLoader(
            training, batch_size=int(train_config["batch_size"]), shuffle=True,
            generator=torch.Generator().manual_seed(seed + epoch - 1), num_workers=0,
        )
        model.train()
        total_loss = total_ce = total_regularization = 0.0
        batches = 0
        for batch_index, (x_cpu, y_cpu) in enumerate(loader):
            x = x_cpu.to(device)
            targets = y_cpu.to(device)
            scheduled = base.scheduled_ratio(train_config, seed, epoch - 1, batch_index)
            applied_ratio = 1.0 if regime == "nominal" else scheduled
            high, high_rate = base._view(x, data.sampling_rate_hz, 1.0, train_config)
            second, second_rate = base._view(x, data.sampling_rate_hz, applied_ratio, train_config)
            cpu_rng_state, cuda_rng_state = base._capture_rng_state(device)
            for attempt in range(base.AMP_MAX_RETRIES + 1):
                base._restore_rng_state(device, cpu_rng_state, cuda_rng_state)
                optimizer.zero_grad(set_to_none=True)
                with torch.amp.autocast("cuda", dtype=torch.float16, enabled=device.type == "cuda"):
                    high_output = model(high, high_rate)
                    second_output = model(second, second_rate)
                    ce = 0.5 * (
                        nn.functional.cross_entropy(high_output["logits"], targets)
                        + nn.functional.cross_entropy(second_output["logits"], targets)
                    )
                    regularization = ce.new_zeros(())
                    if filter_regularizer is not None:
                        regularization = filter_regularizer(
                            model.filterbank.center_frequencies_hz,
                            model.filterbank.time_scales_seconds,
                            torch.cat((high_output["nyquist_gate"], second_output["nyquist_gate"]), dim=0),
                        )["total"]
                    loss = ce + train_config["physical_filter_regularization_weight"] * regularization
                if not torch.isfinite(loss):
                    raise FloatingPointError(
                        f"non-finite extension loss: {data.dataset_id}/{family}_{regime}/seed{seed}/"
                        f"epoch{epoch}/batch{batch_index}"
                    )
                scale_before = float(scaler.get_scale())
                scaler.scale(loss).backward()
                scaler.unscale_(optimizer)
                bad = [
                    name for name, parameter in model.named_parameters()
                    if parameter.grad is not None and not torch.isfinite(parameter.grad).all()
                ]
                if not bad:
                    nn.utils.clip_grad_norm_(
                        model.parameters(), train_config["gradient_clip_norm"], error_if_nonfinite=True
                    )
                    scaler.step(optimizer)
                    scaler.update()
                    break
                scale_after = base._next_amp_scale(scale_before, attempt, device)
                if scale_after is None:
                    raise FloatingPointError(
                        f"non-finite extension gradient after retries: {data.dataset_id}/"
                        f"{family}_{regime}/seed{seed}/epoch{epoch}/batch{batch_index}; "
                        f"scale={scale_before}; parameters={bad[:8]}"
                    )
                extension_retries.append({
                    "epoch": epoch, "batch_index": batch_index,
                    "retry_number": attempt + 1, "scale_before": scale_before,
                    "scale_after": scale_after, "nonfinite_parameters": bad[:8],
                })
                scaler.update(new_scale=scale_after)
            total_loss += float(loss.detach().cpu())
            total_ce += float(ce.detach().cpu())
            total_regularization += float(regularization.detach().cpu())
            batches += 1
            schedule_rows.append({
                "epoch": epoch, "batch_index": batch_index,
                "scheduled_ratio": scheduled, "applied_ratio": applied_ratio,
            })
        validation = base.evaluate(model, data, train_config, device)
        epoch_row = {
            "epoch": epoch,
            "train_loss": total_loss / batches,
            "cross_entropy": total_ce / batches,
            "filter_regularization": total_regularization / batches,
            "validation_selection_score": validation["selection_score"],
            "validation_full_rate_macro_f1": validation["full_rate_macro_f1"],
            "validation_mean_unseen_macro_f1": validation["mean_unseen_macro_f1"],
        }
        history.append(epoch_row)
        if validation["selection_score"] > best_score + 1e-12:
            best_score = validation["selection_score"]
            best_epoch = epoch
            torch.save(model.state_dict(), directory / "checkpoint_best.pt")
        torch.save({
            "model": model.state_dict(), "optimizer": optimizer.state_dict(),
            "scaler": scaler.state_dict(), "epoch": epoch,
            "best_score": best_score, "best_epoch": best_epoch,
            "protocol_hash": protocol_hash,
            "source_protocol_hash": source_row["protocol_hash"],
            "numerical_amendment_id": base.AMP_RETRY_AMENDMENT_ID,
            "extension_numerical_retries": extension_retries,
        }, directory / "checkpoint_last.pt")
        _json(directory / "history.json", {"history": history})
        print(
            f"{data.dataset_id} {family}_{regime} seed{seed} epoch {epoch}: "
            f"loss={epoch_row['train_loss']:.4f} val={epoch_row['validation_selection_score']:.4f}",
            flush=True,
        )
    model.load_state_dict(torch.load(
        directory / "checkpoint_best.pt", map_location=device, weights_only=True
    ))
    validation = base.evaluate(model, data, train_config, device)
    schedule_hash = hashlib.sha256(json.dumps(schedule_rows, sort_keys=True).encode()).hexdigest()
    final_config = dict(train_config)
    final_config["max_epochs"] = extension_config["target_epoch"]
    undertraining = base._undertrained(history, best_epoch, final_config)
    undertraining["allowed_remedy"] = None
    undertraining["one_time_extension_exhausted"] = bool(undertraining["flagged"])
    source_retry_count = int(source_row.get("numerical_retry_count", 0))
    result = {
        "status": "completed_extension",
        "protocol_hash": protocol_hash,
        "source_protocol_hash": source_row["protocol_hash"],
        "dataset_id": data.dataset_id,
        "family": family,
        "regime": regime,
        "seed": seed,
        "initial_state_hash": source_row["initial_state_hash"],
        "downstream_initial_state_hash": source_row["downstream_initial_state_hash"],
        "parameters": source_row["parameters"],
        "schedule_hash": schedule_hash,
        "epochs_completed": len(history),
        "extension_start_epoch": extension_config["source_epoch"] + 1,
        "extension_target_epoch": extension_config["target_epoch"],
        "best_epoch": best_epoch,
        "undertraining": undertraining,
        "validation": validation,
        "history": history,
        "source_numerical_retry_count": source_retry_count,
        "extension_numerical_retry_count": len(extension_retries),
        "total_numerical_retry_count": source_retry_count + len(extension_retries),
        "extension_numerical_retries": extension_retries,
        "seconds": time.monotonic() - started,
        "peak_cuda_allocated_mib": (
            float(torch.cuda.max_memory_allocated(device) / (1024 ** 2))
            if device.type == "cuda" else 0.0
        ),
        "source_artifact_hashes": {
            name: _sha256(source_directory / name)
            for name in ("checkpoint_best.pt", "checkpoint_last.pt", "history.json", "schedule.json", "metrics.json")
        },
        "test_accessed": False,
    }
    _json(directory / "metrics.json", result)
    _json(directory / "schedule.json", {"schedule": schedule_rows, "schedule_hash": schedule_hash})
    return result


def run(
    root: Path,
    config_path: Path,
    *,
    execute: bool = False,
    preflight_only: bool = False,
    device_name: str = "auto",
    resume_directory: Path | None = None,
) -> dict:
    root = root.resolve()
    config_path = config_path.resolve()
    config = yaml.safe_load(config_path.read_text(encoding="utf-8"))
    _validate_extension_config(config)
    protocol_hash = _extension_hash(root, config_path)
    plan = {
        "protocol_version": config["protocol_version"],
        "protocol_hash": protocol_hash,
        "scope": config["scope"],
        "source_run": config["source_run"],
        "source_epoch": config["source_epoch"],
        "target_epoch": config["target_epoch"],
        "expected_extension_cells": 120,
        "automatic_test_stage": False,
        "test_accessed": False,
        "execution_requested": execute,
        "preflight_requested": preflight_only,
        "resume_requested": resume_directory is not None,
    }
    if resume_directory is not None and (not execute or preflight_only):
        raise ValueError("extension resume requires --execute and cannot be preflight")
    if not execute and not preflight_only:
        return plan
    if execute and preflight_only:
        raise ValueError("choose extension preflight or execute")
    checked = preflight(root, config)
    plan["preflight"] = checked
    if preflight_only:
        output = (root / config["preflight_output"]).resolve()
        if root not in output.parents:
            raise ValueError("extension preflight output escapes project")
        _json(output, {**plan, "status": "passed", "test_accessed": False})
        plan["preflight_report"] = str(output)
        return plan

    source_run = Path(checked["source_run"])
    source_report = json.loads((source_run / "report.json").read_text(encoding="utf-8"))
    indexed = _source_rows(source_report)
    train_config = yaml.safe_load((source_run / "config_frozen.yaml").read_text(encoding="utf-8"))
    base_config = yaml.safe_load((root / train_config["base_config"]).read_text(encoding="utf-8"))
    output_root = (root / config["output_root"]).resolve()
    if root not in output_root.parents:
        raise ValueError("extension output root escapes project")
    if resume_directory is None:
        stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S%fZ")
        directory = output_root / f"extension__{stamp}"
        directory.mkdir(parents=True, exist_ok=False)
        shutil.copy2(config_path, directory / "config_frozen.yaml")
    else:
        directory = resume_directory.resolve()
        if output_root not in directory.parents or not directory.is_dir():
            raise ValueError("extension resume directory is missing or outside output root")
        if (directory / "config_frozen.yaml").read_bytes() != config_path.read_bytes():
            raise ValueError("extension resume config mismatch")
        prior = json.loads((directory / "manifest.json").read_text(encoding="utf-8"))
        if prior.get("protocol_hash") != protocol_hash or prior.get("test_accessed") is not False:
            raise ValueError("extension resume protocol or TEST boundary mismatch")
    _json(directory / "manifest.json", {
        **plan, "status": "running", "protocol_hash": protocol_hash,
        "resumed": resume_directory is not None, "test_accessed": False,
    })
    torch.set_num_threads(train_config["threads"])
    device = torch.device(
        "cuda" if device_name == "auto" and torch.cuda.is_available()
        else "cpu" if device_name == "auto" else device_name
    )
    rows = []
    reused = 0
    started = time.monotonic()
    try:
        for dataset_id in train_config["datasets"]:
            data = base.load_development_cache(full_cache_path(root, dataset_id))
            expected_fingerprint = checked["cache_check"]["datasets"][dataset_id]["development_fingerprint"]
            if base._fingerprint(data) != expected_fingerprint:
                raise ValueError("development cache changed after extension preflight")
            for seed in train_config["seeds"]:
                paired = {}
                for family, regime in base.CELLS:
                    key = (dataset_id, family, regime, int(seed))
                    source_row = indexed[key]
                    cell_name = f"{dataset_id}__{family}_{regime}__seed{seed}"
                    cell_directory = directory / cell_name
                    metrics_path = cell_directory / "metrics.json"
                    if metrics_path.is_file():
                        row = json.loads(metrics_path.read_text(encoding="utf-8"))
                        valid = (
                            row.get("status") == "completed_extension"
                            and row.get("protocol_hash") == protocol_hash
                            and row.get("dataset_id") == dataset_id
                            and row.get("family") == family
                            and row.get("regime") == regime
                            and row.get("seed") == seed
                            and row.get("epochs_completed") == config["target_epoch"]
                            and row.get("test_accessed") is False
                        )
                        required = tuple(cell_directory / name for name in (
                            "checkpoint_best.pt", "checkpoint_last.pt", "history.json", "schedule.json"
                        ))
                        if not valid or not all(path.is_file() for path in required):
                            raise ValueError(f"completed extension cell failed resume checks: {cell_name}")
                        reused += 1
                    else:
                        if cell_directory.exists():
                            archive_root = directory / "incomplete_attempts"
                            archive_root.mkdir(exist_ok=True)
                            archived = archive_root / (
                                cell_name + "__" + datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S%fZ")
                            )
                            cell_directory.rename(archived)
                        row = _extend_cell(
                            data, base_config, train_config, config, source_row,
                            source_run / cell_name, cell_directory, device, protocol_hash,
                        )
                    rows.append(row)
                    paired[f"{family}_{regime}"] = row
                    _json(directory / "partial.json", {"rows": rows, "test_accessed": False})
                if len({row["downstream_initial_state_hash"] for row in paired.values()}) != 1:
                    raise RuntimeError("extension cells do not share downstream initialization")
                schedules = []
                for family, regime in base.CELLS:
                    path = directory / f"{dataset_id}__{family}_{regime}__seed{seed}" / "schedule.json"
                    schedules.append([
                        row["scheduled_ratio"]
                        for row in json.loads(path.read_text(encoding="utf-8"))["schedule"]
                    ])
                if any(schedule != schedules[0] for schedule in schedules[1:]):
                    raise RuntimeError("extension cells do not share the full ratio schedule")
            del data
            if device.type == "cuda":
                torch.cuda.empty_cache()
        remaining_undertrained = [
            f"{row['dataset_id']}/{row['family']}_{row['regime']}/seed{row['seed']}"
            for row in rows if row["undertraining"]["flagged"]
        ]
        status = "completed_extension_undertrained" if remaining_undertrained else "completed_extension"
        report = {
            **plan, "status": status, "protocol_hash": protocol_hash,
            "rows": rows, "remaining_undertrained_cells": remaining_undertrained,
            "extension_exhausted": bool(remaining_undertrained),
            "retrospective_test_permitted": not remaining_undertrained,
            "retrospective_test_started": False,
            "runtime": {"device": str(device), "torch": torch.__version__, "numpy": np.__version__},
            "execution_session_seconds": time.monotonic() - started,
            "reused_completed_cells": reused,
            "run_directory": str(directory), "test_accessed": False,
        }
        _json(directory / "report.json", report)
        _json(directory / "manifest.json", {
            **plan, "status": status, "protocol_hash": protocol_hash,
            "remaining_undertrained_cells": remaining_undertrained,
            "extension_exhausted": bool(remaining_undertrained),
            "retrospective_test_permitted": not remaining_undertrained,
            "reused_completed_cells": reused, "test_accessed": False,
        })
        return report
    except BaseException as error:
        _json(directory / "manifest.json", {
            **plan, "status": "failed", "protocol_hash": protocol_hash,
            "completed_cells": len(rows), "error": f"{type(error).__name__}: {error}",
            "test_accessed": False,
        })
        raise


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--config", default="configs/experiments/sivp_decisive_controls_extension.yaml"
    )
    parser.add_argument("--execute", action="store_true")
    parser.add_argument("--preflight", action="store_true")
    parser.add_argument("--device", choices=("auto", "cpu", "cuda"), default="auto")
    parser.add_argument("--resume", type=Path)
    args = parser.parse_args()
    root = Path(__file__).resolve().parents[4]
    result = run(
        root, root / args.config, execute=args.execute, preflight_only=args.preflight,
        device_name=args.device, resume_directory=args.resume,
    )
    print(json.dumps({
        key: value for key, value in result.items() if key not in {"rows", "preflight"}
    }, indent=2))


if __name__ == "__main__":
    main()
