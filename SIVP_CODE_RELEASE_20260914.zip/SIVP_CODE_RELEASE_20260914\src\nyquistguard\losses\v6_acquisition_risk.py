"""Exact finite acquisition risk and compute-matched reductions.

Loss inputs are [G,B] CE values. Weights sum to one for each example.
The max tie convention is the first operator, a valid finite-max subgradient.
"""
from __future__ import annotations
import torch
from torch import Tensor, nn

MODES = ("ce", "mean", "envelope", "group_dro", "batch_max")


class AcquisitionRisk(nn.Module):
    def __init__(self, groups: int = 4, mode: str = "envelope", step_size: float = .01):
        super().__init__()
        if groups < 1 or mode not in MODES or not 0 < step_size <= 1:
            raise ValueError("invalid acquisition risk settings")
        self.groups, self.mode, self.step_size = groups, mode, step_size
        self.register_buffer("log_group_weights", torch.full((groups,), -torch.log(torch.tensor(float(groups))).item()))

    def weights(self, losses: Tensor, *, update: bool = False) -> Tensor:
        if losses.ndim != 2 or losses.shape[0] != self.groups or losses.shape[1] < 1 or not torch.isfinite(losses).all():
            raise ValueError("expected finite [operators,batch] losses")
        detached = losses.detach()
        if self.mode == "envelope":
            return torch.nn.functional.one_hot(detached.argmax(0), self.groups).T.to(losses)
        if self.mode == "batch_max":
            operator = detached.mean(1).argmax()
            return torch.nn.functional.one_hot(operator, self.groups).to(losses)[:, None].expand_as(losses)
        if self.mode == "group_dro":
            if update:
                with torch.no_grad():
                    updated = self.log_group_weights + self.step_size * detached.mean(1).to(self.log_group_weights)
                    self.log_group_weights.copy_(updated - updated.logsumexp(0))
            return self.log_group_weights.softmax(0).to(losses)[:, None].expand_as(losses)
        if self.mode == "ce":
            # Diagnostic single canonical low-rate view, handled by the runner.
            raise ValueError("CE view weights are scheduled explicitly by the runner")
        return torch.full_like(losses, 1 / self.groups)

    def forward(self, losses: Tensor, *, update: bool = False) -> Tensor:
        return (self.weights(losses, update=update) * losses).sum(0).mean()
