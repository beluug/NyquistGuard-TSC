"""Stream exact gradients with shared, replayed dropout across operator views."""
from __future__ import annotations
import torch
from torch import Tensor, nn
import torch.nn.functional as F
from nyquistguard.losses.v6_acquisition_risk import AcquisitionRisk
from .operators import nominal_view, operator_family


def rng_state():
    return (torch.get_rng_state(), torch.cuda.get_rng_state_all() if torch.cuda.is_available() else [])


def restore_rng(state):
    torch.set_rng_state(state[0])
    if state[1]:
        torch.cuda.set_rng_state_all(state[1])


def backward_acquisition(model: nn.Module, x: Tensor, y: Tensor, source_rate: float,
                         ratio: float, risk: AcquisitionRisk, *, step: int = 0) -> dict:
    """Accumulate .5 nominal CE + .5 acquisition-risk gradients; caller steps.

    GroupNorm/LayerNorm are sample-local; mutable BatchNorm is not supported.
    The four main arms ALL run 4 no-grad scans + 4 full-batch gradient replays.
    Thus envelope has no extra model evaluations; only one graph lives at once.
    """
    if any(isinstance(m, nn.modules.batchnorm._BatchNorm) for m in model.modules()):
        raise ValueError("stateful BatchNorm would invalidate exact replay")
    model.train()
    high = model(nominal_view(x), source_rate)["logits"].float()
    nominal_loss = F.cross_entropy(high, y)
    (.5 * nominal_loss).backward()
    specs = operator_family(ratio)
    if risk.mode == "ce":
        # Single canonical low view: phase0/rolloff.8, at the scheduled rate.
        viewed, rate, _ = specs[0].apply(x, source_rate)
        low_loss = F.cross_entropy(model(viewed, rate)["logits"].float(), y)
        (.5 * low_loss).backward()
        return {"total": float(.5 * (nominal_loss.detach() + low_loss.detach())),
                "nominal": float(nominal_loss.detach()), "risk": float(low_loss.detach()),
                "forward_passes": 2, "backward_passes": 2, "max_replay_error": 0.,
                "worst_operator_counts": [len(y), 0, 0, 0]}
    low_rng = rng_state()
    scans = []
    with torch.no_grad():
        for spec in specs:
            restore_rng(low_rng)
            viewed, rate, _ = spec.apply(x, source_rate)
            scans.append(F.cross_entropy(model(viewed, rate)["logits"].float(), y, reduction="none"))
    end_rng = rng_state()
    matrix = torch.stack(scans)
    weights = risk.weights(matrix, update=True)
    max_error = 0.
    for j, spec in enumerate(specs):
        restore_rng(low_rng)
        viewed, rate, _ = spec.apply(x, source_rate)
        losses = F.cross_entropy(model(viewed, rate)["logits"].float(), y, reduction="none")
        error = (losses.detach() - matrix[j]).abs().max().item()
        max_error = max(max_error, error)
        # Same masks and inputs must reproduce scan values; never silently optimize
        # a different operator after max selection.
        if not torch.allclose(losses.detach(), matrix[j], atol=2e-6, rtol=2e-5):
            raise RuntimeError("operator/dropout replay mismatch")
        (.5 * (weights[j] * losses).mean()).backward()
    restore_rng(end_rng)
    acquisition = (weights * matrix).sum(0).mean()
    return {"total": float(.5 * (nominal_loss.detach() + acquisition)),
            "nominal": float(nominal_loss.detach()), "risk": float(acquisition),
            "forward_passes": 9, "backward_passes": 5, "max_replay_error": max_error,
            "worst_operator_counts": torch.bincount(matrix.argmax(0), minlength=4).tolist()}
