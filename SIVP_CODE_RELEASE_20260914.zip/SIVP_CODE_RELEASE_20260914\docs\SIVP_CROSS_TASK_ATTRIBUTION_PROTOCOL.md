# SIVP cross-task TRAIN-only OOF attribution protocol

Frozen on 2026-09-14 before any MHEALTH or EEGMMI OOF prediction from this extension was produced. Protocol version: `sivp_cross_task_attribution_train_oof_v1`.

## Scientific question

Does the fixed-reference error decomposition observed on PAMAP2 describe other sensing tasks, or are rate-added errors and linear-reconstruction effects strongly task-dependent?

This experiment broadens error attribution. It is not a new method test, an untouched confirmation, or a route to reopen the blocked decisive-control TEST stage.

## Task selection

The tasks are fixed as MHEALTH and EEGMMI before their extension predictions are inspected.

- MHEALTH represents multichannel wearable sensing: 21 channels, 50 Hz, 12 classes, and six subject groups in TRAIN.
- EEGMMI represents electrophysiological sensing: 64 channels, 160 Hz, two classes, and 76 subject groups in TRAIN.

Selection used dataset metadata, TRAIN identifiers, and already completed TRAIN/validation control results. No TEST prediction or TEST score was used. BasicMotions and PAMAP2 are excluded because they already have the corrected diagnostic; Hydraulic is near ceiling; Sleep-EDF and MIT-BIH showed weak ordinary-model validation performance. The two selected tasks cannot be replaced after their results are observed.

## Data and independent units

Only `train_x`, `train_y`, `train_ids`, `dataset_id`, `sampling_rate_hz`, and `class_names` may be materialized from each registered NPZ. Access to any key beginning with `validation` or `test` is forbidden.

Each task uses a deterministic class-balanced cap of 512 TRAIN records with seed 60914.

- MHEALTH: leave one `mHealth_subjectN` group out, giving six subject-disjoint folds.
- EEGMMI: extract `SNNN` from each `SNNNRMM` record identifier and use five seeded stratified group folds. No subject may cross a fold boundary.

Every selected record receives predictions from one model that did not fit that record. Subject is the independent descriptive unit. Windows, rate ratios, and the two training arms are paired observations rather than independent replicates.

## Models, arms, and training

The model is the same ordinary rich-summary, fixed-fusion, signed-path backbone used by the corrected PAMAP2/BasicMotions OOF diagnostic. Its parameter-matching construction is retained. The two arms share each fold's initial state, fit/held split, minibatch order, scheduled rate sequence, update count, optimizer, and fixed final-update rule.

- `nominal_ce`: nominal cropped-view cross-entropy.
- `multirate_mean`: 0.5 nominal cross-entropy plus 0.5 equal-weight mean over the four registered phase/roll-off acquisition operators at one scheduled rate.

Each cell uses 64 updates, batch size 16, AdamW with learning rate 0.001 and weight decay 0.0001, and gradient clipping at 1. The multirate arm uses more forward/backward evaluations than nominal CE; no equal-compute claim is permitted.

## Fixed-reference evaluation

Evaluation ratios are 0.9, 0.6, 0.4, and 0.3. For every held-out window, the longest endpoint-aligned common support is computed using the least common multiple of the registered rational-ratio denominators. One high-rate input and prediction are evaluated once. Every ratio-specific canonical low-rate grid begins and ends at the same physical coordinates.

The saved views are: fixed high reference, filtered dense grid, canonical low rate, piecewise-linear reconstruction, phase-only perturbation, filter-only perturbation, joint phase/filter perturbation, and Hann-window perturbation. Reconstruction uses only canonical low-rate samples and cannot add class information.

## Required outputs

For every window and ratio, save dataset, subject, fold, model arm, true label, predictions, and full probability vectors for every view. Report:

1. the high/canonical-low 2x2 transition table by ratio and in aggregate;
2. the four hierarchical attribution counts;
3. reconstruction repairs, introduced errors, and net change;
4. macro-F1 for canonical and reconstructed inputs by ratio;
5. complete subject-level results;
6. fit accuracy and OOF fixed-high accuracy health checks.

No window-level or ratio-level inferential p-value is allowed. MHEALTH has only six independent subjects and is primarily descriptive. Results from both tasks remain in the record regardless of direction.

## Health and stopping rules

The primary diagnostic arm is `multirate_mean`. A task supports error attribution only if every fold has nominal fit accuracy at least 0.85 and its OOF fixed-high accuracy is at least 0.65. Failure produces `BASELINE_OR_GROUP_SHIFT_LIMITATION`; all results remain reported, and the task is not replaced.

The run ends after all 22 cells: 6 MHEALTH folds and 5 EEGMMI folds, each with two arms. There is no early selection, epoch extension, TEST stage, or automatic follow-up. A failed or interrupted cell may be rerun from the same frozen split and initialization; completed cells are reused and never overwritten.

## Interpretation

Agreement with PAMAP2 would strengthen cross-task evidence for grid sensitivity. A different pattern would support task dependence. Neither outcome establishes SOTA performance, general reconstruction benefit, physical-front-end superiority, or untouched confirmation.
