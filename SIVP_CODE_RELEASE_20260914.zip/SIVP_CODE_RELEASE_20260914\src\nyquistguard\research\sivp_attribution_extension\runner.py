"""Run the frozen MHEALTH/EEGMMI TRAIN-only fixed-reference OOF extension."""

from __future__ import annotations

import argparse
import csv
from datetime import datetime, timezone
import json
import math
from pathlib import Path
import random
import shutil
import time

import numpy as np
from sklearn.metrics import f1_score
import torch
import torch.nn.functional as F
import yaml

from nyquistguard.losses.v6_acquisition_risk import AcquisitionRisk
from nyquistguard.research.v6.runner import make_model
from nyquistguard.research.v6_envelope.operators import nominal_view
from nyquistguard.research.v6_envelope.runner import OPTIONS, guard
from nyquistguard.research.v6_envelope.training import backward_acquisition
from nyquistguard.research.v6_train_probe.core import error_masks, standardize_fit
from nyquistguard.research.v6_train_probe.fixed_reference import (
    CommonSupport,
    fixed_common_support_views,
)

from .data import TrainOnlyData, grouped_folds, load_train_only


ARMS = ("nominal_ce", "multirate_mean")
RATIO_VIEWS = (
    "filtered_dense",
    "canonical_low",
    "lifted_low",
    "phase_only",
    "filter_only",
    "joint",
    "window_only",
)
PARTITION_KEYS = ("baseline_wrong", "rate_added", "nuisance_added", "stable")


def _json(path: Path, value: object) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(
        json.dumps(value, indent=2, ensure_ascii=False, allow_nan=False),
        encoding="utf-8",
    )
    temporary.replace(path)


def _seed(value: int) -> None:
    random.seed(value)
    np.random.seed(value)
    torch.manual_seed(value)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(value)


def validate_config(config: dict) -> None:
    expected = {
        "protocol_version": "sivp_cross_task_attribution_train_oof_v1",
        "scope": "train_only_grouped_oof",
        "automatic_followup": False,
        "output_root": "runs/sivp_cross_task_attribution",
        "preflight_output": "reports/sivp_cross_task_attribution/preflight.json",
        "cap_seed": 60914,
        "split_seed": 60929,
        "model_seed": 61000,
        "arms": list(ARMS),
        "primary_diagnostic_arm": "multirate_mean",
        "updates": 64,
        "batch_size": 16,
        "learning_rate": 0.001,
        "weight_decay": 0.0001,
        "gradient_clip": 1.0,
        "train_rates": [0.35, 0.5, 0.7],
        "evaluation_rates": [0.9, 0.6, 0.4, 0.3],
        "common_support_rule": "longest_endpoint_aligned_span_on_ratio_denominator_lcm",
        "checkpoint_rule": "fixed_final_update",
        "minimum_fit_nominal_accuracy": 0.85,
        "minimum_oof_high_reference_accuracy": 0.65,
        "wall_seconds": 5400,
        "threads": 4,
        "maximum_rss_gib": 8,
        "maximum_cuda_allocated_gib": 4,
    }
    for key, value in expected.items():
        if config.get(key) != value:
            raise ValueError(f"cross-task attribution config changed: {key}")
    expected_datasets = {
        "mhealth_uci": {
            "cache_path": "data/processed/pilot_v1/mhealth_uci.npz",
            "grouping": "mhealth_subject_prefix",
            "folds": "leave_one_subject_out",
            "train_cap": 512,
        },
        "eegmmi_physionet": {
            "cache_path": "data/processed/full_v1/eegmmi_physionet.npz",
            "grouping": "eegmmi_subject_prefix",
            "folds": "stratified_group_5fold",
            "train_cap": 512,
        },
    }
    if config.get("datasets") != expected_datasets:
        raise ValueError("cross-task dataset selection or grouping changed")
    boundaries = config.get("scientific_boundaries", {})
    required_true = {
        "train_arrays_only",
        "fixed_task_list_before_prediction",
        "no_task_substitution_after_prediction",
        "reference_evaluated_once_per_window",
        "all_low_rate_grids_share_reference_endpoints",
        "retain_all_predictions",
        "no_inferential_window_level_p_values",
        "no_automatic_test_stage",
        "no_hash_recomputation",
    }
    if any(boundaries.get(key) is not True for key in required_true):
        raise ValueError("cross-task scientific boundary changed")
    if boundaries.get("validation_read") is not False or boundaries.get("test_read") is not False:
        raise ValueError("validation and TEST access must remain false")
    model = config.get("model", {})
    if model != {
        "hidden_dim": 64,
        "num_bands": 16,
        "spatial_channels": 24,
        "pooled_positions": 32,
        "depth": 3,
        "dropout": 0.05,
    }:
        raise ValueError("ordinary OOF model changed")
    if config.get("gates") != {"maximum_parameter_gap": 0.02}:
        raise ValueError("parameter-matching tolerance changed")


def _preflight(root: Path, config: dict) -> tuple[dict[str, TrainOnlyData], dict]:
    datasets: dict[str, TrainOnlyData] = {}
    information: dict[str, dict] = {}
    for dataset_id, specification in config["datasets"].items():
        data = load_train_only(
            root / specification["cache_path"],
            dataset_id,
            int(specification["train_cap"]),
            int(config["cap_seed"]),
        )
        partitions = grouped_folds(data, specification["folds"], int(config["split_seed"]))
        information[dataset_id] = {
            "cache_path": specification["cache_path"],
            "shape": list(data.train_x.shape),
            "sampling_rate_hz": data.rate,
            "class_count": len(data.classes),
            "class_names": list(data.classes),
            "class_counts": np.bincount(data.train_y, minlength=len(data.classes)).tolist(),
            "subject_count": len(set(data.groups.tolist())),
            "selected_ids": data.train_ids.tolist(),
            "selected_groups": data.groups.tolist(),
            "folds": [
                {
                    "index": index,
                    "name": name,
                    "fit_count": len(fit),
                    "held_count": len(held),
                    "fit_class_counts": np.bincount(
                        data.train_y[fit], minlength=len(data.classes)
                    ).tolist(),
                    "held_class_counts": np.bincount(
                        data.train_y[held], minlength=len(data.classes)
                    ).tolist(),
                    "held_subjects": sorted(set(data.groups[held].tolist())),
                    "fit_ids": data.train_ids[fit].tolist(),
                    "held_ids": data.train_ids[held].tolist(),
                }
                for index, (fit, held, name) in enumerate(partitions)
            ],
            "training_started": False,
            "validation_read": False,
            "test_read": False,
        }
        datasets[dataset_id] = data
    return datasets, information


def _metrics(probabilities: np.ndarray, labels: np.ndarray, class_count: int) -> dict:
    predictions = probabilities.argmax(axis=1)
    return {
        "probabilities": probabilities.tolist(),
        "predictions": predictions.tolist(),
        "accuracy": float(np.mean(predictions == labels)),
        "macro_f1": float(
            f1_score(
                labels,
                predictions,
                labels=np.arange(class_count),
                average="macro",
                zero_division=0,
            )
        ),
        "nll": float(
            -np.log(np.maximum(probabilities[np.arange(len(labels)), labels], 1e-8)).mean()
        ),
    }


@torch.inference_mode()
def _evaluate_nominal(
    model: torch.nn.Module,
    values: np.ndarray,
    labels: np.ndarray,
    rate: float,
    batch_size: int,
    device: torch.device,
    deadline: float,
    config: dict,
) -> dict:
    model.eval()
    collected = []
    for start in range(0, len(labels), batch_size):
        guard(deadline, config, device)
        batch = torch.from_numpy(values[start : start + batch_size]).to(device)
        collected.append(model(nominal_view(batch), rate)["logits"].float().softmax(-1).cpu().numpy())
    return _metrics(np.concatenate(collected), labels, model.num_classes)


@torch.inference_mode()
def _evaluate_fixed_reference(
    model: torch.nn.Module,
    values: np.ndarray,
    labels: np.ndarray,
    rate: float,
    ratios: tuple[float, ...],
    batch_size: int,
    device: torch.device,
    deadline: float,
    config: dict,
) -> tuple[dict, CommonSupport]:
    model.eval()
    collected: dict[str, list[np.ndarray]] = {"high_reference": []}
    layout: CommonSupport | None = None
    for start in range(0, len(labels), batch_size):
        guard(deadline, config, device)
        batch = torch.from_numpy(values[start : start + batch_size]).to(device)
        high, by_ratio, current_layout = fixed_common_support_views(batch, rate, ratios)
        if layout is None:
            layout = current_layout
        elif layout != current_layout:
            raise RuntimeError("fixed common support changed across held-out batches")
        collected["high_reference"].append(
            model(high[0], high[1])["logits"].float().softmax(-1).cpu().numpy()
        )
        for ratio in ratios:
            for view, (observed, observed_rate) in by_ratio[ratio].items():
                key = f"{ratio}/{view}"
                collected.setdefault(key, []).append(
                    model(observed, observed_rate)["logits"].float().softmax(-1).cpu().numpy()
                )
    if layout is None:
        raise ValueError("empty held-out fold")
    return {
        key: _metrics(np.concatenate(parts), labels, model.num_classes)
        for key, parts in collected.items()
    }, layout


def _train_cell(
    data: TrainOnlyData,
    fold_index: int,
    partition: tuple[np.ndarray, np.ndarray, str],
    arm: str,
    config: dict,
    directory: Path,
    device: torch.device,
    deadline: float,
    seed: int,
    initial_state: dict[str, torch.Tensor],
) -> dict:
    fit, held, fold_name = partition
    normalized, scaling = standardize_fit(data.train_x, fit)
    directory.mkdir(parents=True, exist_ok=False)
    _seed(seed + 505)
    model = make_model(data, config, OPTIONS, seed).to(device)
    model.load_state_dict(initial_state, strict=True)
    optimizer = torch.optim.AdamW(
        model.parameters(),
        lr=float(config["learning_rate"]),
        weight_decay=float(config["weight_decay"]),
    )
    risk = AcquisitionRisk(4, "mean").to(device)
    generator = np.random.default_rng(seed + 811)
    queue: list[int] = []
    history: list[dict] = []
    schedule: list[dict] = []
    peak_rss = 0
    if device.type == "cuda":
        torch.cuda.reset_peak_memory_stats(device)
    started = time.monotonic()
    try:
        for update in range(int(config["updates"])):
            peak_rss = max(peak_rss, guard(deadline, config, device) or 0)
            if len(queue) < int(config["batch_size"]):
                queue.extend(generator.permutation(fit).tolist())
            indices = np.asarray(queue[: int(config["batch_size"])], dtype=np.int64)
            del queue[: int(config["batch_size"])]
            ratio = float(generator.choice(config["train_rates"]))
            batch_x = torch.from_numpy(normalized[indices]).to(device)
            batch_y = torch.from_numpy(data.train_y[indices]).long().to(device)
            optimizer.zero_grad(set_to_none=True)
            if arm == "multirate_mean":
                entry = backward_acquisition(model, batch_x, batch_y, data.rate, ratio, risk)
            elif arm == "nominal_ce":
                model.train()
                loss = F.cross_entropy(model(nominal_view(batch_x), data.rate)["logits"].float(), batch_y)
                loss.backward()
                entry = {
                    "total": float(loss.detach()),
                    "forward_passes": 1,
                    "backward_passes": 1,
                }
            else:
                raise ValueError("unknown training arm")
            if not math.isfinite(float(entry["total"])):
                raise FloatingPointError("nonfinite cross-task training loss")
            if any(
                parameter.grad is not None and not torch.isfinite(parameter.grad).all()
                for parameter in model.parameters()
            ):
                raise FloatingPointError("nonfinite cross-task training gradient")
            gradient_norm = torch.nn.utils.clip_grad_norm_(
                model.parameters(), float(config["gradient_clip"]), error_if_nonfinite=True
            )
            optimizer.step()
            history.append({**entry, "gradient_norm_before_clip": float(gradient_norm)})
            schedule.append({"ids": data.train_ids[indices].tolist(), "ratio": ratio})
            if (update + 1) % 16 == 0:
                print(
                    f"{data.dataset_id} {fold_name} {arm} update {update + 1}/{config['updates']}: "
                    f"loss={entry['total']:.4f}",
                    flush=True,
                )

        fit_metrics = _evaluate_nominal(
            model,
            normalized[fit],
            data.train_y[fit],
            data.rate,
            int(config["batch_size"]),
            device,
            deadline,
            config,
        )
        conditions, layout = _evaluate_fixed_reference(
            model,
            normalized[held],
            data.train_y[held],
            data.rate,
            tuple(float(value) for value in config["evaluation_rates"]),
            int(config["batch_size"]),
            device,
            deadline,
            config,
        )
        result = {
            "status": "completed",
            "protocol_version": config["protocol_version"],
            "dataset_id": data.dataset_id,
            "fold": fold_index,
            "fold_name": fold_name,
            "arm": arm,
            "seed": seed,
            "fit_ids": data.train_ids[fit].tolist(),
            "held_ids": data.train_ids[held].tolist(),
            "held_groups": data.groups[held].tolist(),
            "held_labels": data.train_y[held].tolist(),
            "updates": len(history),
            "schedule": schedule,
            "history": history,
            "fit_nominal": {key: value for key, value in fit_metrics.items() if key not in {"probabilities", "predictions"}},
            "conditions": conditions,
            "common_support": layout.to_dict(),
            "standardization": scaling,
            "parameters": sum(parameter.numel() for parameter in model.parameters() if parameter.requires_grad),
            "parameter_match": model.parameter_match,
            "seconds": time.monotonic() - started,
            "peak_rss_observed_mib": peak_rss / 2**20,
            "peak_cuda_allocated_mib": (
                torch.cuda.max_memory_allocated(device) / 2**20 if device.type == "cuda" else 0.0
            ),
            "model_eval_for_predictions": True,
            "validation_read": False,
            "test_read": False,
        }
        torch.save(
            {
                "model": model.state_dict(),
                "optimizer": optimizer.state_dict(),
                "updates": len(history),
                "protocol_version": config["protocol_version"],
                "dataset_id": data.dataset_id,
                "fold": fold_index,
                "arm": arm,
            },
            directory / "final.pt",
        )
        _json(directory / "metrics.json", result)
        return result
    except BaseException as error:
        torch.save(
            {
                "model": model.state_dict(),
                "optimizer": optimizer.state_dict(),
                "completed_updates": len(history),
                "protocol_version": config["protocol_version"],
            },
            directory / "interrupted.pt",
        )
        _json(
            directory / "failure.json",
            {
                "error": repr(error),
                "completed_updates": len(history),
                "history": history,
                "validation_read": False,
                "test_read": False,
            },
        )
        raise


def _validate_completed_cell(
    result: dict,
    data: TrainOnlyData,
    fold_index: int,
    partition: tuple[np.ndarray, np.ndarray, str],
    arm: str,
    config: dict,
    seed: int,
) -> None:
    fit, held, fold_name = partition
    expected = {
        "status": "completed",
        "protocol_version": config["protocol_version"],
        "dataset_id": data.dataset_id,
        "fold": fold_index,
        "fold_name": fold_name,
        "arm": arm,
        "seed": seed,
        "fit_ids": data.train_ids[fit].tolist(),
        "held_ids": data.train_ids[held].tolist(),
        "held_groups": data.groups[held].tolist(),
        "held_labels": data.train_y[held].tolist(),
        "updates": int(config["updates"]),
        "validation_read": False,
        "test_read": False,
    }
    for key, value in expected.items():
        if result.get(key) != value:
            raise ValueError(f"completed cell identity mismatch: {key}")
    if len(result.get("schedule", [])) != int(config["updates"]):
        raise ValueError("completed cell has an incomplete schedule")


def _archive_incomplete(run_directory: Path, cell: Path) -> None:
    boundary = run_directory.resolve()
    resolved = cell.resolve()
    if boundary not in resolved.parents:
        raise ValueError("incomplete cell escapes run boundary")
    archive = run_directory / "incomplete_attempts"
    archive.mkdir(exist_ok=True)
    stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S%fZ")
    destination = archive / f"{cell.name}__{stamp}"
    cell.rename(destination)


def _summarize_dataset_arm(cells: list[dict], ratios: tuple[float, ...], class_count: int, config: dict) -> tuple[dict, list[dict]]:
    cells = sorted(cells, key=lambda item: int(item["fold"]))
    labels = np.concatenate([np.asarray(cell["held_labels"], dtype=np.int64) for cell in cells])
    ids = np.concatenate([np.asarray(cell["held_ids"], dtype=str) for cell in cells])
    groups = np.concatenate([np.asarray(cell["held_groups"], dtype=str) for cell in cells])
    folds = np.concatenate([np.repeat(int(cell["fold"]), len(cell["held_ids"])) for cell in cells])
    if len(set(ids.tolist())) != len(ids):
        raise ValueError("OOF summary contains repeated records")
    high_probabilities = np.concatenate([
        np.asarray(cell["conditions"]["high_reference"]["probabilities"], dtype=np.float64)
        for cell in cells
    ])
    high_predictions = high_probabilities.argmax(axis=1)
    high_correct = high_predictions == labels
    per_rate: dict[str, dict] = {}
    records: list[dict] = []
    accumulated = {key: [] for key in (*PARTITION_KEYS, "baseline_rescued", "rate_lift_repaired", "rate_filter_wrong", "rate_filter_correct_lift_repaired")}
    subject_values: dict[str, dict[str, list]] = {}
    repair_total = 0
    introduced_total = 0

    for ratio in ratios:
        probabilities = {"high_reference": high_probabilities}
        for view in RATIO_VIEWS:
            probabilities[view] = np.concatenate([
                np.asarray(cell["conditions"][f"{ratio}/{view}"]["probabilities"], dtype=np.float64)
                for cell in cells
            ])
        predictions = {name: values.argmax(axis=1) for name, values in probabilities.items()}
        correct = {name: values == labels for name, values in predictions.items()}
        masks = error_masks(correct)
        for name, values in masks.items():
            accumulated[name].append(values)
        low_correct = correct["canonical_low"]
        lifted_correct = correct["lifted_low"]
        repaired = ~low_correct & lifted_correct
        introduced = low_correct & ~lifted_correct
        repair_total += int(repaired.sum())
        introduced_total += int(introduced.sum())
        transition = {
            "high_right_low_right": int((high_correct & low_correct).sum()),
            "high_right_low_wrong": int((high_correct & ~low_correct).sum()),
            "high_wrong_low_right": int((~high_correct & low_correct).sum()),
            "high_wrong_low_wrong": int((~high_correct & ~low_correct).sum()),
        }
        per_rate[str(ratio)] = {
            "n_windows": len(labels),
            "transition_high_vs_canonical_low": transition,
            "partition": {name: int(masks[name].sum()) for name in PARTITION_KEYS},
            "views": {
                name: {
                    "accuracy": float(np.mean(values == labels)),
                    "macro_f1": float(
                        f1_score(
                            labels,
                            values,
                            labels=np.arange(class_count),
                            average="macro",
                            zero_division=0,
                        )
                    ),
                }
                for name, values in predictions.items()
            },
            "reconstruction_repairs": int(repaired.sum()),
            "reconstruction_introduced_errors": int(introduced.sum()),
            "reconstruction_net_error_reduction": int(repaired.sum() - introduced.sum()),
        }
        for index, record_id in enumerate(ids):
            record = {
                "dataset_id": cells[0]["dataset_id"],
                "arm": cells[0]["arm"],
                "fold": int(folds[index]),
                "group": str(groups[index]),
                "window_id": str(record_id),
                "ratio": ratio,
                "true_label": int(labels[index]),
                "high_reference_prediction": int(high_predictions[index]),
                "high_reference_probabilities": high_probabilities[index].tolist(),
            }
            for view in RATIO_VIEWS:
                record[f"{view}_prediction"] = int(predictions[view][index])
                record[f"{view}_probabilities"] = probabilities[view][index].tolist()
            for name, values in masks.items():
                record[name] = bool(values[index])
            record["reconstruction_repaired"] = bool(repaired[index])
            record["reconstruction_introduced_error"] = bool(introduced[index])
            records.append(record)
            subject = subject_values.setdefault(str(groups[index]), {
                "labels": [], "canonical": [], "lifted": [], "repaired": [], "introduced": [],
            })
            subject["labels"].append(int(labels[index]))
            subject["canonical"].append(int(predictions["canonical_low"][index]))
            subject["lifted"].append(int(predictions["lifted_low"][index]))
            subject["repaired"].append(bool(repaired[index]))
            subject["introduced"].append(bool(introduced[index]))

    combined = {name: np.concatenate(values) for name, values in accumulated.items()}
    observations = len(labels) * len(ratios)
    partition = {name: int(combined[name].sum()) for name in PARTITION_KEYS}
    if sum(partition.values()) != observations:
        raise RuntimeError("attribution partition is not complete")
    if partition["baseline_wrong"] % len(ratios) != 0:
        raise RuntimeError("high reference is not fixed across ratios")
    high_rows = np.tile(high_correct, len(ratios))
    group_summary = {}
    for group, values in sorted(subject_values.items()):
        subject_labels = np.asarray(values["labels"], dtype=np.int64)
        canonical = np.asarray(values["canonical"], dtype=np.int64)
        lifted = np.asarray(values["lifted"], dtype=np.int64)
        repaired = int(np.sum(values["repaired"]))
        introduced = int(np.sum(values["introduced"]))
        group_summary[group] = {
            "window_rate_observations": len(subject_labels),
            "reconstruction_repairs": repaired,
            "reconstruction_introduced_errors": introduced,
            "reconstruction_net_error_reduction": repaired - introduced,
            "canonical_low_macro_f1": float(
                f1_score(subject_labels, canonical, labels=np.arange(class_count), average="macro", zero_division=0)
            ),
            "lifted_low_macro_f1": float(
                f1_score(subject_labels, lifted, labels=np.arange(class_count), average="macro", zero_division=0)
            ),
        }
    fit_accuracies = [float(cell["fit_nominal"]["accuracy"]) for cell in cells]
    oof_high_accuracy = float(np.mean(high_correct))
    healthy = (
        min(fit_accuracies) >= float(config["minimum_fit_nominal_accuracy"])
        and oof_high_accuracy >= float(config["minimum_oof_high_reference_accuracy"])
    )
    mean_low = float(np.mean([per_rate[str(ratio)]["views"]["canonical_low"]["macro_f1"] for ratio in ratios]))
    mean_lifted = float(np.mean([per_rate[str(ratio)]["views"]["lifted_low"]["macro_f1"] for ratio in ratios]))
    return {
        "independent_windows": len(labels),
        "independent_subjects": len(set(groups.tolist())),
        "dependent_window_rate_observations": observations,
        "health": {
            "status": "HEALTHY_FOR_ATTRIBUTION" if healthy else "BASELINE_OR_GROUP_SHIFT_LIMITATION",
            "passed": healthy,
            "minimum_fit_nominal_accuracy": min(fit_accuracies),
            "oof_fixed_high_accuracy": oof_high_accuracy,
        },
        "partition": partition,
        "aggregate_transition_high_vs_canonical_low": {
            key: sum(per_rate[str(ratio)]["transition_high_vs_canonical_low"][key] for ratio in ratios)
            for key in (
                "high_right_low_right",
                "high_right_low_wrong",
                "high_wrong_low_right",
                "high_wrong_low_wrong",
            )
        },
        "high_correct_window_rate_observations": int(high_rows.sum()),
        "rate_added_fraction_given_high_correct": float(combined["rate_added"].sum() / max(1, high_rows.sum())),
        "reconstruction": {
            "repairs": repair_total,
            "introduced_errors": introduced_total,
            "net_error_reduction": repair_total - introduced_total,
            "rate_added_repairs": int(combined["rate_lift_repaired"].sum()),
            "rate_added_total": int(combined["rate_added"].sum()),
            "filtered_dense_wrong_among_rate_added": int(combined["rate_filter_wrong"].sum()),
            "canonical_low_mean_macro_f1": mean_low,
            "lifted_low_mean_macro_f1": mean_lifted,
            "mean_macro_f1_change": mean_lifted - mean_low,
        },
        "per_rate": per_rate,
        "by_subject": group_summary,
    }, records


def _write_records(output: Path, records: list[dict]) -> None:
    with (output / "predictions.jsonl").open("w", encoding="utf-8") as handle:
        for record in records:
            handle.write(json.dumps(record, ensure_ascii=False, allow_nan=False) + "\n")
    with (output / "predictions.csv").open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(records[0]))
        writer.writeheader()
        for record in records:
            writer.writerow({
                key: json.dumps(value, separators=(",", ":")) if isinstance(value, list) else value
                for key, value in record.items()
            })


def _markdown_report(result: dict) -> str:
    lines = [
        "# SIVP cross-task TRAIN-only OOF attribution",
        "",
        f"Status: `{result['status']}`. TEST accessed: `{str(result['test_accessed']).lower()}`. ",
        "The tables are descriptive; windows and rate ratios are not treated as independent replicates.",
        "",
    ]
    for dataset_id in result["dataset_order"]:
        lines.extend([f"## {dataset_id}", ""])
        for arm in ARMS:
            summary = result["summaries"][f"{dataset_id}/{arm}"]
            health = summary["health"]
            reconstruction = summary["reconstruction"]
            transition = summary["aggregate_transition_high_vs_canonical_low"]
            lines.extend([
                f"### {arm}",
                "",
                f"Health: `{health['status']}`; minimum fit accuracy {health['minimum_fit_nominal_accuracy']:.4f}; "
                f"OOF fixed-high accuracy {health['oof_fixed_high_accuracy']:.4f}.",
                "",
                "| Transition over four paired ratios | Count |",
                "|---|---:|",
                f"| High correct, low correct | {transition['high_right_low_right']} |",
                f"| High correct, low wrong | {transition['high_right_low_wrong']} |",
                f"| High wrong, low correct | {transition['high_wrong_low_right']} |",
                f"| High wrong, low wrong | {transition['high_wrong_low_wrong']} |",
                "",
                "| Ratio | Canonical-low F1 | Reconstructed F1 | Repairs | Introduced | Net |",
                "|---:|---:|---:|---:|---:|---:|",
            ])
            for ratio, values in summary["per_rate"].items():
                low = values["views"]["canonical_low"]["macro_f1"]
                lifted = values["views"]["lifted_low"]["macro_f1"]
                lines.append(
                    f"| {ratio} | {low:.6f} | {lifted:.6f} | "
                    f"{values['reconstruction_repairs']} | {values['reconstruction_introduced_errors']} | "
                    f"{values['reconstruction_net_error_reduction']:+d} |"
                )
            lines.extend([
                "",
                f"Across ratios, reconstruction repaired {reconstruction['repairs']} errors, introduced "
                f"{reconstruction['introduced_errors']}, and changed mean macro-F1 by "
                f"{reconstruction['mean_macro_f1_change']:+.6f}.",
                "",
            ])
    lines.extend([
        "## Interpretation boundary",
        "",
        "Both prespecified tasks remain in this report regardless of result direction. A failed health gate limits attribution and does not permit task replacement. This TRAIN-only extension is not independent confirmation and cannot reopen the blocked decisive-control TEST stage.",
        "",
    ])
    return "\n".join(lines)


def _latest_run(boundary: Path) -> Path:
    candidates = sorted(
        [path for path in boundary.glob("train_oof__*") if path.is_dir()],
        key=lambda path: path.stat().st_mtime,
        reverse=True,
    )
    if not candidates:
        raise FileNotFoundError("no cross-task run is available to resume")
    return candidates[0]


def run(
    root: Path,
    config_path: Path,
    *,
    execute: bool = False,
    preflight_only: bool = False,
    resume_directory: Path | None = None,
    resume_latest: bool = False,
    device_name: str = "auto",
) -> dict:
    root = root.resolve()
    config_path = config_path.resolve()
    config = yaml.safe_load(config_path.read_text(encoding="utf-8"))
    validate_config(config)
    plan = {
        "protocol_version": config["protocol_version"],
        "scope": config["scope"],
        "dataset_order": list(config["datasets"]),
        "expected_cells": 22,
        "execution_requested": execute,
        "preflight_requested": preflight_only,
        "automatic_followup": False,
        "validation_read": False,
        "test_read": False,
        "hashes_recomputed": False,
    }
    if not execute and not preflight_only:
        return plan
    if execute and preflight_only:
        raise ValueError("choose preflight or execute")
    if (resume_directory is not None or resume_latest) and not execute:
        raise ValueError("resume requires --execute")
    datasets, preflight = _preflight(root, config)
    plan["preflight"] = preflight
    if preflight_only:
        result = {**plan, "status": "passed", "training_started": False}
        _json(root / config["preflight_output"], result)
        return result

    dashboard = root / "runs" / "dashboard_status.json"
    if dashboard.exists():
        state = json.loads(dashboard.read_text(encoding="utf-8"))
        if state.get("status") == "running":
            raise RuntimeError("another experiment is running; dashboard was not modified")

    boundary = (root / config["output_root"]).resolve()
    boundary.mkdir(parents=True, exist_ok=True)
    if resume_latest:
        resume_directory = _latest_run(boundary)
    if resume_directory is None:
        stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S%fZ")
        run_directory = boundary / f"train_oof__{stamp}"
        run_directory.mkdir(parents=False, exist_ok=False)
        shutil.copy2(config_path, run_directory / "config_frozen.yaml")
    else:
        run_directory = resume_directory.resolve()
        if run_directory != boundary and boundary not in run_directory.parents:
            raise ValueError("resume directory escapes the cross-task output boundary")
        manifest = json.loads((run_directory / "manifest.json").read_text(encoding="utf-8"))
        if manifest.get("protocol_version") != config["protocol_version"]:
            raise ValueError("resume protocol version changed")
        if manifest.get("preflight") != preflight:
            raise ValueError("resume TRAIN selection or fold layout changed")

    torch.set_num_threads(int(config["threads"]))
    device = torch.device(
        "cuda" if device_name == "auto" and torch.cuda.is_available()
        else "cpu" if device_name == "auto" else device_name
    )
    if device.type == "cuda" and not torch.cuda.is_available():
        raise RuntimeError("CUDA was requested but is unavailable")
    deadline = time.monotonic() + float(config["wall_seconds"])
    started = time.monotonic()
    plan.update({
        "status": "running",
        "run_directory": str(run_directory),
        "device": str(device),
        "torch_version": torch.__version__,
    })
    _json(run_directory / "manifest.json", {**plan, "preflight": preflight, "completed_cells": 0})
    print(f"run_directory={run_directory}", flush=True)
    print("planned_cells=22", flush=True)
    rows: list[dict] = []
    try:
        for dataset_index, (dataset_id, specification) in enumerate(config["datasets"].items()):
            data = datasets[dataset_id]
            partitions = grouped_folds(data, specification["folds"], int(config["split_seed"]))
            for fold_index, partition in enumerate(partitions):
                seed = int(config["model_seed"]) + 100 * dataset_index + fold_index
                _seed(seed)
                template = make_model(data, config, OPTIONS, seed)
                initial_state = {
                    name: value.detach().cpu().clone() for name, value in template.state_dict().items()
                }
                del template
                paired: list[dict] = []
                for arm in ARMS:
                    cell = run_directory / f"{dataset_id}__fold{fold_index}__{arm}"
                    if cell.exists() and (cell / "metrics.json").exists():
                        result = json.loads((cell / "metrics.json").read_text(encoding="utf-8"))
                        _validate_completed_cell(result, data, fold_index, partition, arm, config, seed)
                    else:
                        if cell.exists():
                            _archive_incomplete(run_directory, cell)
                        result = _train_cell(
                            data,
                            fold_index,
                            partition,
                            arm,
                            config,
                            cell,
                            device,
                            deadline,
                            seed,
                            initial_state,
                        )
                    rows.append(result)
                    paired.append(result)
                    _json(run_directory / "partial.json", {"rows": rows})
                    _json(
                        run_directory / "manifest.json",
                        {**plan, "preflight": preflight, "completed_cells": len(rows)},
                    )
                    print(f"completed_cells={len(rows)}/22", flush=True)
                for key in ("fit_ids", "held_ids", "held_groups", "held_labels", "updates", "schedule", "parameters"):
                    if paired[0][key] != paired[1][key]:
                        raise RuntimeError(f"paired training arms differ: {key}")

        ratios = tuple(float(value) for value in config["evaluation_rates"])
        summaries: dict[str, dict] = {}
        records: list[dict] = []
        for dataset_id in config["datasets"]:
            for arm in ARMS:
                selected = [row for row in rows if row["dataset_id"] == dataset_id and row["arm"] == arm]
                summary, current_records = _summarize_dataset_arm(
                    selected, ratios, len(datasets[dataset_id].classes), config
                )
                summaries[f"{dataset_id}/{arm}"] = summary
                records.extend(current_records)
        _write_records(run_directory, records)
        primary_health = {
            dataset_id: summaries[f"{dataset_id}/{config['primary_diagnostic_arm']}"]["health"]
            for dataset_id in config["datasets"]
        }
        completed_status = (
            "completed_healthy" if all(value["passed"] for value in primary_health.values())
            else "completed_health_limited"
        )
        result = {
            **plan,
            "status": completed_status,
            "preflight": preflight,
            "completed_cells": len(rows),
            "rows": rows,
            "summaries": summaries,
            "primary_health": primary_health,
            "seconds": time.monotonic() - started,
            "validation_read": False,
            "test_read": False,
            "test_accessed": False,
            "hashes_recomputed": False,
        }
        _json(run_directory / "report.json", result)
        (run_directory / "REPORT.md").write_text(_markdown_report(result), encoding="utf-8")
        _json(
            run_directory / "manifest.json",
            {
                **plan,
                "status": completed_status,
                "preflight": preflight,
                "completed_cells": len(rows),
                "test_accessed": False,
                "hashes_recomputed": False,
            },
        )
        return result
    except BaseException as error:
        _json(
            run_directory / "manifest.json",
            {
                **plan,
                "status": "failed",
                "preflight": preflight,
                "completed_cells": len(rows),
                "error": repr(error),
                "validation_read": False,
                "test_read": False,
                "test_accessed": False,
                "hashes_recomputed": False,
            },
        )
        raise


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--config",
        type=Path,
        default=Path("configs/experiments/sivp_cross_task_attribution_train_oof.yaml"),
    )
    parser.add_argument("--preflight", action="store_true")
    parser.add_argument("--execute", action="store_true")
    parser.add_argument("--resume", type=Path)
    parser.add_argument("--resume-latest", action="store_true")
    parser.add_argument("--device", choices=("auto", "cpu", "cuda"), default="auto")
    args = parser.parse_args()
    root = Path(__file__).resolve().parents[4]
    result = run(
        root,
        root / args.config,
        execute=args.execute,
        preflight_only=args.preflight,
        resume_directory=args.resume,
        resume_latest=args.resume_latest,
        device_name=args.device,
    )
    compact = {
        key: value
        for key, value in result.items()
        if key not in {"rows", "summaries", "preflight"}
    }
    print(json.dumps(compact, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
