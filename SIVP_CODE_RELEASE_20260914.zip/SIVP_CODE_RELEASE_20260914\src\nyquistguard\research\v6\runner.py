"""Bounded validation-only V6 runner. No test parser or dashboard writer.

Default CLI is a plan, not execution. Each phase is a separate invocation.
Real development is never run by import or by completion of another phase.
"""
from __future__ import annotations

import argparse
from collections import OrderedDict
from dataclasses import dataclass
from datetime import datetime, timezone
import hashlib
import json
import math
from pathlib import Path
import random
import time
import zipfile

import numpy as np
import torch
from torch import nn
from sklearn.metrics import f1_score
from sklearn.model_selection import StratifiedGroupKFold
import yaml

from nyquistguard.losses.filter_regularization import FilterBankRegularization
from nyquistguard.losses.v6_posterior_transport import PosteriorTransportLoss
from .backbone import V6Backbone, matched_ordinary_backbone, parameter_count
from .operators import ObservationSpec
from .posterior import SpectralPushforwardTeacher

DATASETS = ("basicmotions_uea", "pamap2_uci")
FACTORIAL = {
    "rich_adaptive": {"summary": "rich", "fusion": "adaptive"},
    "mean_adaptive": {"summary": "mean", "fusion": "adaptive"},
    "rich_fixed": {"summary": "rich", "fusion": "fixed"},
    "mean_fixed": {"summary": "mean", "fusion": "fixed"},
}


@dataclass(frozen=True)
class DevelopmentData:
    dataset_id: str
    rate: float
    classes: tuple
    train_x: np.ndarray
    train_y: np.ndarray
    train_ids: np.ndarray
    validation_x: np.ndarray
    validation_y: np.ndarray
    validation_ids: np.ndarray


def _cap(y: np.ndarray, limit: int, seed: int) -> np.ndarray:
    if limit < 2 * len(np.unique(y)):
        raise ValueError("sample cap too small for class coverage")
    rng = np.random.default_rng(seed)
    buckets = [list(rng.permutation(np.where(y == k)[0])) for k in sorted(np.unique(y))]
    selected = []
    while len(selected) < min(limit, len(y)):
        for bucket in buckets:
            if bucket and len(selected) < limit:
                selected.append(bucket.pop())
    return np.asarray(sorted(selected), dtype=np.int64)


def load_development(path: Path, config: dict) -> DevelopmentData:
    # np.load is lazy: only the listed TRAIN/validation members are requested.
    # No whole-cache conversion, fallback parser, or TEST member access.
    # Inspect only development headers before materializing arrays; never TEST.
    required = [f"{split}_{field}" for split in ("train", "validation") for field in ("x", "y", "ids")]
    input_bytes = 0
    with zipfile.ZipFile(path) as archive:
        for name in required:
            with archive.open(name + ".npy") as member:
                version = np.lib.format.read_magic(member)
                if version == (1, 0):
                    shape, _, dtype = np.lib.format.read_array_header_1_0(member)
                elif version == (2, 0):
                    shape, _, dtype = np.lib.format.read_array_header_2_0(member)
                else:
                    raise ValueError("unsupported development array header")
                if dtype.hasobject:
                    raise ValueError("object data is not allowed")
                input_bytes += math.prod(shape) * dtype.itemsize
    if input_bytes > 2 * 2**30:
        raise MemoryError("development cache exceeds 2 GiB input budget; use a separately frozen train-only cache")
    with np.load(path, allow_pickle=False) as p:
        dataset_id = str(p["dataset_id"].item())
        rate = float(p["sampling_rate_hz"].item())
        classes = tuple(p["class_names"].astype(str).tolist())
        arrays = {f"{split}_{field}": p[f"{split}_{field}"]
                  for split in ("train", "validation") for field in ("x", "y", "ids")}
    if dataset_id not in DATASETS:
        raise ValueError("micro data outside the two registered development datasets")
    if not math.isfinite(rate) or rate <= 0 or len(classes) < 2:
        raise ValueError("invalid source rate/classes")
    if set(arrays["train_ids"]) & set(arrays["validation_ids"]):
        raise ValueError("TRAIN/validation IDs overlap")
    for split in ("train", "validation"):
        x, y, ids = (arrays[f"{split}_{field}"] for field in ("x", "y", "ids"))
        if x.ndim != 3 or y.ndim != 1 or ids.ndim != 1 or len(y) == 0 or x.dtype != np.float32 or len(x) != len(y) or len(ids) != len(y) or not np.isfinite(x).all() or not np.issubdtype(y.dtype, np.integer):
            raise ValueError(f"{dataset_id} {split}: invalid development arrays")
        if len(np.unique(ids)) != len(ids):
            raise ValueError("duplicate source window IDs")
        observed, expected = set(np.unique(y).tolist()), set(range(len(classes)))
        unexpected = sorted(observed - expected)
        if unexpected:
            raise ValueError(f"{dataset_id} {split}: labels outside TRAIN class vocabulary: {unexpected}")
        # A subject-held-out validation split need not contain every TRAIN class.
        # Keep the full classifier vocabulary and fixed-K macro F1 unchanged.
        if split == "train" and observed != expected:
            missing = [classes[k] for k in sorted(expected - observed)]
            raise ValueError(f"{dataset_id} train: missing configured classes: {missing}")
        indices = _cap(y, config[f"{split}_cap"], 60908)
        for field in ("x", "y", "ids"):
            arrays[f"{split}_{field}"] = arrays[f"{split}_{field}"][indices]
    return DevelopmentData(dataset_id, rate, classes, **arrays)


def preflight_development(root: Path, config: dict, phase: str) -> dict:
    """Check all development inputs before any cell trains; never create a model.

    Materialize one bounded cache at a time, then release it. Execution reloads
    each dataset and verifies its development hash against this preflight.
    """
    checks = {}
    for dataset_id in config["datasets"]:
        data = load_development(root / config["cache_root"] / f"{dataset_id}.npz", config)
        if data.dataset_id != dataset_id:
            raise ValueError(f"cache dataset ID mismatch: expected {dataset_id}, got {data.dataset_id}")
        k = len(data.classes)
        train_counts = np.bincount(data.train_y, minlength=k)
        validation_counts = np.bincount(data.validation_y, minlength=k)
        missing = np.flatnonzero(validation_counts == 0).tolist()
        checks[dataset_id] = {
            "development_hash": development_hash(data),
            "class_names": list(data.classes), "sampling_rate_hz": data.rate,
            "train_shape_after_cap": list(data.train_x.shape),
            "validation_shape_after_cap": list(data.validation_x.shape),
            "train_class_counts_after_cap": train_counts.tolist(),
            "validation_class_counts_after_cap": validation_counts.tolist(),
            "validation_missing_class_indices": missing,
            "validation_missing_class_names": [data.classes[i] for i in missing],
            "macro_f1_class_count": k,
            "validation_macro_f1_upper_bound": float(np.count_nonzero(validation_counts) / k),
            "crossfit_checked": phase == "mechanism",
        }
        if phase == "mechanism":
            crossfit_folds(data.train_y, data.train_ids, config["seeds"][0])
        del data
    return {"status": "passed", "test_accessed": False, "training_started": False,
            "scope": "TRAIN_and_validation_only", "datasets": checks}


def crossfit_folds(y: np.ndarray, ids: np.ndarray, seed: int) -> np.ndarray:
    # Overlapping windows from the same source recording MUST stay together.
    groups = np.asarray([str(value).split(":")[0] for value in ids])
    splitter = StratifiedGroupKFold(n_splits=2, shuffle=True, random_state=seed)
    folds = np.full(len(y), -1, dtype=np.int64)
    for fold, (training, heldout) in enumerate(splitter.split(np.zeros(len(y)), y, groups)):
        if set(groups[training]) & set(groups[heldout]):
            raise RuntimeError("cross-fit source group leakage")
        if any(np.sum(y[training] == k) < 2 for k in np.unique(y)):
            raise ValueError("teacher fold lacks >=2 TRAIN observations per class; no seed retry")
        folds[heldout] = fold
    if np.any(folds < 0):
        raise RuntimeError("incomplete cross-fit partition")
    return folds


def _json(path: Path, value: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(json.dumps(value, indent=2, ensure_ascii=False, allow_nan=False), encoding="utf-8")
    temporary.replace(path)


def development_hash(data: DevelopmentData) -> str:
    digest = hashlib.sha256(f"{data.dataset_id}:{data.rate}:{data.classes}".encode())
    for field in ("train_x", "train_y", "train_ids", "validation_x", "validation_y", "validation_ids"):
        value = np.ascontiguousarray(getattr(data, field))
        digest.update(f"{field}:{value.dtype}:{value.shape}".encode())
        digest.update(value.tobytes())
    return digest.hexdigest()


def _bounded(root: Path, path: Path, *, output: bool = False) -> Path:
    path = path.resolve()
    boundary = (root / "runs/v6").resolve() if output else root.resolve()
    if path != boundary and boundary not in path.parents:
        raise ValueError("path escapes V6 boundary")
    return path


def validate_config(config: dict) -> None:
    if config.get("scope") != "validation_only" or config.get("automatic_followup") is not False:
        raise ValueError("V6 micro must remain validation-only with no followup")
    if tuple(config.get("datasets", [])) != DATASETS or config.get("seeds") != [60908]:
        raise ValueError("registered micro datasets/seeds changed")
    if config.get("cache_root") != "data/processed/pilot_v1":
        raise ValueError("micro only reads existing pilot TRAIN/validation members")
    for key, maximum in (("wall_seconds", 600), ("epochs", 8), ("train_cap", 256),
                         ("validation_cap", 128), ("max_batches_per_epoch", 2), ("batch_size", 16)):
        if not isinstance(config.get(key), int) or not 1 <= config[key] <= maximum:
            raise ValueError(f"micro bound violated: {key}")
    if config.get("validation_rates") != [1., .9, .6, .4, .3]:
        raise ValueError("micro validation rate grid changed")
    if config.get("mechanism_arms") != ["ce", "opdt", "zero_difference", "direct_teacher", "wrong_operator", "label_smoothing", "all_pairs_difference"]:
        raise ValueError("registered mechanism controls changed")


def protocol_hash(root: Path, config_path: Path) -> str:
    paths = [config_path, *sorted((root / "src/nyquistguard/research/v6").glob("*.py")),
             root / "scripts/run_v6_validation.py",
             root / "docs/V6_EXPERIMENTAL_PROTOCOL_DRAFT.md",
             root / "src/nyquistguard/losses/v6_posterior_transport.py",
             root / "src/nyquistguard/data/resampling.py",
             *sorted((root / "src/nyquistguard/models").glob("*.py")),
             root / "src/nyquistguard/losses/filter_regularization.py"]
    digest = hashlib.sha256()
    for path in paths:
        digest.update(str(path.relative_to(root)).encode())
        digest.update(path.read_bytes())
    return digest.hexdigest()


def _deadline(deadline: float) -> None:
    if time.monotonic() >= deadline:
        raise TimeoutError("V6 micro wall limit; completed cells/checkpoints retained")


def _spec(data: DevelopmentData, ratio: float, config: dict, mode: str = "antialias") -> ObservationSpec:
    return ObservationSpec(data.rate, ratio, config["antialias_taps"], config["antialias_rolloff"], mode)


def make_model(data: DevelopmentData, config: dict, options: dict, seed: int) -> V6Backbone:
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    template = V6Backbone(data.train_x.shape[1], len(data.classes), source_rate_hz=data.rate,
                          summary="rich", fusion="adaptive", **config["model"])
    reference = template.state_dict()
    if options.get("frontend") == "ordinary":
        selected = {k: v for k, v in options.items() if k not in {"frontend", "gate", "signed"}}
        base = V6Backbone(data.train_x.shape[1], len(data.classes), source_rate_hz=data.rate,
                         **selected, **config["model"])
        kwargs = {k: v for k, v in config["model"].items() if k != "hidden_dim"}
        model, match = matched_ordinary_backbone(base, **selected, **kwargs)
        if match["relative_gap"] > config["gates"]["maximum_parameter_gap"]:
            raise ValueError("active parameter matching exceeds registered tolerance")
        model.parameter_match = match
    else:
        torch.manual_seed(seed + 1)
        model = V6Backbone(data.train_x.shape[1], len(data.classes), source_rate_hz=data.rate,
                           **options, **config["model"])
    state = model.state_dict()
    for key in state:
        if key in reference and state[key].shape == reference[key].shape:
            state[key] = reference[key].clone()
    model.load_state_dict(state)
    torch.manual_seed(seed + 505)
    return model


@torch.no_grad()
def evaluate(model: nn.Module, data: DevelopmentData, config: dict, device: torch.device,
             deadline: float, teacher: SpectralPushforwardTeacher | None = None) -> dict:
    model.eval()
    metrics, predictions, teacher_scores = {}, {}, {}
    for ratio in config["validation_rates"]:
        probs, qprobs = [], []
        spec = _spec(data, ratio, config)
        observation = teacher.prepare(spec) if teacher is not None else None
        for start in range(0, len(data.validation_y), config["batch_size"]):
            _deadline(deadline)
            x = torch.from_numpy(data.validation_x[start:start + config["batch_size"]]).to(device)
            viewed, rate = spec.apply(x)
            probs.append(model(viewed, rate)["logits"].float().softmax(-1).cpu())
            if teacher is not None:
                qprobs.append(teacher(viewed, spec, sampling_rate_hz=rate, observation=observation)["probabilities"].cpu())
        p = torch.cat(probs).numpy()
        ids = np.arange(len(data.validation_y))
        metrics[str(ratio)] = {"macro_f1": float(f1_score(data.validation_y, p.argmax(-1), labels=np.arange(len(data.classes)), average="macro", zero_division=0)),
            "nll": float(-np.log(np.maximum(p[ids, data.validation_y], 1e-8)).mean()),
            "prediction_class_count": int(len(np.unique(p.argmax(-1))))}
        predictions[str(ratio)] = p
        if qprobs:
            q = torch.cat(qprobs).numpy()
            teacher_scores[str(ratio)] = q
            metrics[str(ratio)]["teacher_nll"] = float(-np.log(np.maximum(q[ids, data.validation_y], 1e-8)).mean())
    unseen = [metrics[str(r)]["macro_f1"] for r in config["validation_rates"][1:]]
    result = {"per_rate": metrics, "full_rate_macro_f1": metrics["1.0"]["macro_f1"],
              "mean_unseen_macro_f1": float(np.mean(unseen)), "worst_unseen_macro_f1": min(unseen)}
    if teacher_scores:
        result["posterior_change_error"] = float(np.mean([np.square((predictions[str(r)] - predictions["1.0"]) - (teacher_scores[str(r)] - teacher_scores["1.0"])).sum(-1).mean() for r in config["validation_rates"][1:]]))
        result["teacher_mean_nll"] = float(np.mean([v["teacher_nll"] for v in metrics.values()]))
        prior = teacher.priors.cpu().numpy()
        result["prior_nll"] = float(-np.log(prior[data.validation_y]).mean())
    return result


def train_cell(data: DevelopmentData, config: dict, options: dict, arm: str, seed: int,
               directory: Path, device: torch.device, deadline: float, digest: str, resume: bool) -> dict:
    directory.mkdir(parents=True, exist_ok=True)
    final = directory / "metrics.json"
    data_hash = development_hash(data)
    if resume and final.exists():
        result = json.loads(final.read_text(encoding="utf-8"))
        if result["protocol_hash"] != digest or result.get("development_hash") != data_hash or result["options"] != options or result["arm"] != arm:
            raise ValueError("resume source hash mismatch")
        return result
    if final.exists() and not resume:
        raise FileExistsError("completed V6 cell must not be overwritten")
    started = time.monotonic()
    model = make_model(data, config, options, seed).to(device)
    initial_hash = hashlib.sha256(b"".join(v.detach().cpu().numpy().tobytes() for v in model.state_dict().values())).hexdigest()
    optimizer = torch.optim.AdamW(model.parameters(), lr=config["learning_rate"], weight_decay=config["weight_decay"])
    mode = "ce" if arm == "backbone_ce" else ("opdt" if arm == "wrong_operator" else arm)
    loss_fn = PosteriorTransportLoss(config["transport_weight"], mode)
    filter_loss = None
    if model.frontend == "physical":
        bank = model.filterbank
        filter_loss = FilterBankRegularization(min_center_hz=bank.min_center_hz, max_center_hz=bank.max_center_hz,
            min_sigma_seconds=bank.min_sigma_seconds, max_sigma_seconds=bank.max_sigma_seconds,
            gate_degeneracy_weight=0.)
    train_x, train_y = torch.from_numpy(data.train_x), torch.from_numpy(data.train_y).long()
    teachers, folds, validation_teacher = [], None, None
    # All mechanism arms fit the same teacher, including CE, for compute accounting
    # and the same held-out posterior-change diagnostic. No target label enters it.
    if arm != "backbone_ce":
        folds = crossfit_folds(data.train_y, data.train_ids, seed)
        for fold in range(2):
            subset = folds != fold
            teachers.append(SpectralPushforwardTeacher.fit(train_x[subset], train_y[subset], len(data.classes), **config["teacher"]).to(device))
        validation_teacher = SpectralPushforwardTeacher.fit(train_x, train_y, len(data.classes), **config["teacher"]).to(device)
    # The special backbone cell uses CE without fitting density or scoring teacher.
    cache = OrderedDict()
    history, best, stale, start_epoch = [], -1., 0, 0
    checkpoint = directory / "last.pt"
    if resume and checkpoint.exists():
        saved = torch.load(checkpoint, map_location=device, weights_only=False)
        if saved["protocol_hash"] != digest or saved.get("development_hash") != data_hash or saved.get("options") != options or saved.get("arm") != arm:
            raise ValueError("checkpoint protocol mismatch")
        model.load_state_dict(saved["model"])
        optimizer.load_state_dict(saved["optimizer"])
        history, best, stale, start_epoch = saved["history"], saved["best"], saved["stale"], saved["epoch"]
        torch.set_rng_state(saved["rng"].cpu())
        if device.type == "cuda":
            torch.cuda.set_rng_state_all([v.cpu() for v in saved["cuda_rng"]])
    if device.type == "cuda":
        torch.cuda.reset_peak_memory_stats(device)
    try:
        for epoch in range(start_epoch, config["epochs"]):
            model.train()
            generator = np.random.default_rng(seed + epoch)
            indices = generator.permutation(len(train_y))
            row_losses = []
            for batch, start in enumerate(range(0, len(indices), config["batch_size"])):
                if batch >= config["max_batches_per_epoch"]:
                    break
                _deadline(deadline)
                idx = indices[start:start + config["batch_size"]]
                x, y = train_x[idx].to(device), train_y[idx].to(device)
                ratio = 1. if batch % 3 == 0 else float(generator.uniform(config["train_secondary_min"], config["train_secondary_max"]))
                high_spec, low_spec = _spec(data, 1., config), _spec(data, ratio, config)
                high, hr = high_spec.apply(x)
                low, lr = low_spec.apply(x)
                qh = ql = None
                if teachers:
                    qh, ql = torch.empty(len(idx), len(data.classes), device=device), torch.empty(len(idx), len(data.classes), device=device)
                    for values, spec, rate, output in ((high, high_spec, hr, qh), (low, low_spec, lr, ql)):
                        teacher_spec = _spec(data, spec.ratio, config, "naive" if arm == "wrong_operator" else "antialias")
                        key = (values.shape[-1], teacher_spec.mode)
                        if key not in cache:
                            cache[key] = teachers[0].prepare(teacher_spec)
                            if len(cache) > 8:
                                cache.popitem(last=False)
                        with torch.no_grad():
                            for fold in range(2):
                                selected = torch.as_tensor(folds[idx] == fold, device=device)
                                if selected.any():
                                    output[selected] = teachers[fold](values[selected], teacher_spec, sampling_rate_hz=rate, observation=cache[key])["probabilities"]
                optimizer.zero_grad(set_to_none=True)
                h, l = model(high, hr), model(low, lr)
                losses = loss_fn(h["logits"], l["logits"], y, qh, ql)
                regularization = losses["total"] * 0
                if filter_loss is not None:
                    regularization = filter_loss(model.filterbank.center_frequencies_hz, model.filterbank.time_scales_seconds)["total"]
                total = losses["total"] + 0.01 * regularization
                if not torch.isfinite(total):
                    raise FloatingPointError("nonfinite V6 loss")
                total.backward()
                if any(p.grad is not None and not torch.isfinite(p.grad).all() for p in model.parameters()):
                    raise FloatingPointError("nonfinite V6 gradient")
                nn.utils.clip_grad_norm_(model.parameters(), config["gradient_clip"])
                optimizer.step()
                row_losses.append({k: float(v.detach()) for k, v in losses.items()})
            validation = evaluate(model, data, config, device, deadline)
            score = 0.5 * (validation["full_rate_macro_f1"] + validation["mean_unseen_macro_f1"])
            if score > best + 1e-12:
                best, stale = score, 0
                torch.save(model.state_dict(), directory / "best.pt")
            else:
                stale += 1
            history.append({"epoch": epoch + 1, "losses": row_losses, "validation": validation, "selection_score": score})
            torch.save({"model": model.state_dict(), "optimizer": optimizer.state_dict(), "epoch": epoch + 1,
                        "history": history, "best": best, "stale": stale, "protocol_hash": digest,
                        "development_hash": data_hash, "options": options, "arm": arm,
                        "rng": torch.get_rng_state(), "cuda_rng": torch.cuda.get_rng_state_all() if device.type == "cuda" else []}, checkpoint)
            _json(directory / "history.json", {"history": history})
            print(f"{data.dataset_id} {arm} epoch {epoch+1}: val={score:.4f}", flush=True)
            if stale >= config["patience"]:
                break
        model.load_state_dict(torch.load(directory / "best.pt", map_location=device, weights_only=True))
        validation = evaluate(model, data, config, device, deadline, validation_teacher)
        result = {"status": "completed", "protocol_hash": digest, "development_hash": data_hash, "dataset_id": data.dataset_id, "seed": seed,
                  "arm": arm, "options": options, "parameters": parameter_count(model),
                  "initial_state_hash": initial_hash, "validation": validation, "epochs": len(history),
                  "teacher_folds": None if folds is None else folds.tolist(), "train_ids": data.train_ids.tolist(),
                  "validation_ids": data.validation_ids.tolist(), "test_accessed": False,
                  "seconds_this_session": time.monotonic() - started,
                  "peak_cuda_allocated_mib": torch.cuda.max_memory_allocated(device) / 2**20 if device.type == "cuda" else 0.,
                  "parameter_match": getattr(model, "parameter_match", None)}
        _json(final, result)
        return result
    except BaseException as error:
        _json(directory / "failure.json", {"error": repr(error), "protocol_hash": digest,
               "test_accessed": False, "seconds_this_session": time.monotonic() - started})
        raise


def select_backbone(rows: list[dict], config: dict) -> str:
    by_arm = {}
    for row in rows:
        v = row["validation"]
        by_arm.setdefault(row["cell"], []).append((0.5 * (v["full_rate_macro_f1"] + v["mean_unseen_macro_f1"]), row["parameters"]))
    means = {name: np.mean([v[0] for v in values]) for name, values in by_arm.items()}
    best = max(means.values())
    eligible = [name for name in means if means[name] >= best - config["selection_tolerance"]]
    return min(eligible, key=lambda name: (np.mean([v[1] for v in by_arm[name]]), name))


def factorial_effects(rows: list[dict]) -> dict:
    """Paired descriptive effects; datasets, not rates/seeds, are the blocks."""
    result = {}
    for dataset in DATASETS:
        values = {r["cell"]: .5 * (r["validation"]["full_rate_macro_f1"] + r["validation"]["mean_unseen_macro_f1"])
                  for r in rows if r["dataset_id"] == dataset}
        ra, ma, rf, mf = (values[name] for name in FACTORIAL)
        result[dataset] = {"mean_summary_main_effect": .5 * ((ma - ra) + (mf - rf)),
                           "fixed_fusion_main_effect": .5 * ((rf - ra) + (mf - ma)),
                           "difference_in_differences_interaction": mf - rf - ma + ra}
    return result


def mechanism_decision(rows: list[dict], config: dict) -> dict:
    by = {(row["dataset_id"], row["arm"]): row for row in rows}
    checks, deltas = {}, []
    for dataset in DATASETS:
        v6, ce = by[(dataset, "opdt")], by[(dataset, "ce")]
        for arm in config["mechanism_arms"]:
            if by[(dataset, arm)]["initial_state_hash"] != ce["initial_state_hash"]:
                raise ValueError("mechanism arms did not start with identical student weights")
        delta = v6["validation"]["mean_unseen_macro_f1"] - ce["validation"]["mean_unseen_macro_f1"]
        deltas.append(delta)
        teacher = v6["validation"]
        checks[f"{dataset}_noncollapsed"] = all(v["prediction_class_count"] > 1 for v in teacher["per_rate"].values())
        checks[f"{dataset}_teacher"] = teacher["teacher_mean_nll"] < teacher["prior_nll"] - config["gates"]["teacher_nll_gain_vs_prior"]
        baseline_error = ce["validation"]["posterior_change_error"]
        checks[f"{dataset}_change_error"] = baseline_error > 1e-8 and teacher["posterior_change_error"] <= (1 - config["gates"]["posterior_change_error_reduction"]) * baseline_error
    checks["mean_unseen_gain"] = np.mean(deltas) >= config["gates"]["mean_unseen_gain"]
    checks["positive_datasets"] = sum(d > 0 for d in deltas) >= config["gates"]["minimum_positive_datasets"]
    checks["single_dataset_floor"] = min(deltas) >= config["gates"]["single_dataset_floor"]
    checks["mean_full_floor"] = np.mean([by[(d,"opdt")]["validation"]["full_rate_macro_f1"] - by[(d,"ce")]["validation"]["full_rate_macro_f1"] for d in DATASETS]) >= config["gates"]["mean_full_floor"]
    for arm in ("zero_difference", "direct_teacher", "wrong_operator", "label_smoothing", "all_pairs_difference"):
        checks[f"better_than_{arm}"] = np.mean([by[(d,"opdt")]["validation"]["mean_unseen_macro_f1"] - by[(d,arm)]["validation"]["mean_unseen_macro_f1"] for d in DATASETS]) > 0
    return {"passed": all(checks.values()), "checks": {k: bool(v) for k,v in checks.items()},
            "mean_unseen_delta": float(np.mean(deltas)), "scope": "provisional_micro_only",
            "automatic_next_stage": False}


def screen_health(rows: list[dict], selected: str) -> dict:
    selected_rows = {d: [row for row in rows if row["dataset_id"] == d and row["cell"] == selected] for d in DATASETS}
    checks = {d: bool(selected_rows[d]) and all(v["prediction_class_count"] > 1 for row in selected_rows[d]
                     for v in row["validation"]["per_rate"].values()) for d in DATASETS}
    return {"passed": all(checks.values()), "selected_noncollapsed_by_dataset": checks,
            "failure_meaning": "engineering_or_budget_no_go_not_theory_falsification"}


def run(root: Path, config_path: Path, phase: str, *, execute: bool = False,
        parent_report: Path | None = None, resume: Path | None = None, device_name: str = "auto",
        preflight_only: bool = False) -> dict:
    root = root.resolve()
    config_path = _bounded(root, config_path)
    config = yaml.safe_load(config_path.read_text(encoding="utf-8"))
    validate_config(config)
    if phase not in {"factorial", "backbone_checks", "mechanism"}:
        raise ValueError("unknown phase")
    if preflight_only and (execute or resume is not None):
        raise ValueError("preflight is read-only and cannot execute or resume training")
    digest = protocol_hash(root, config_path)
    options = FACTORIAL
    parent = None
    if phase != "factorial":
        if parent_report is None:
            raise ValueError("this phase requires the completed preceding V6 report")
        parent = json.loads(_bounded(root, parent_report, output=True).read_text(encoding="utf-8"))
        if parent.get("status") != "completed" or parent.get("protocol_hash") != digest or parent.get("test_accessed") is not False:
            raise ValueError("parent incomplete, contaminated or source hash changed")
        expected = "factorial" if phase == "backbone_checks" else "backbone_checks"
        if parent.get("phase") != expected:
            raise ValueError("wrong parent phase")
        if not parent.get("screen_health", {}).get("passed", False):
            raise ValueError("selected backbone collapsed or screen health absent; do not advance")
        selected = parent["selected_options"]
        if phase == "backbone_checks":
            options = {"selected": selected, "no_signed": {**selected, "signed": False},
                       "no_gate": {**selected, "gate": "none"},
                       "ordinary_matched": {**selected, "gate": "none", "frontend": "ordinary"}}
        else:
            options = {arm: selected for arm in config["mechanism_arms"]}
    plan = {"phase": phase, "cells": list(options), "datasets": config["datasets"],
            "seeds": config["seeds"], "protocol_hash": digest, "scope": "validation_only",
            "wall_seconds": config["wall_seconds"], "execution_requested": execute,
            "cell_options": options, "parent_report": str(parent_report) if parent_report else None}
    if not execute:
        if preflight_only:
            plan["data_preflight"] = preflight_development(root, config, phase)
        return plan
    status = root / "runs/dashboard_status.json"
    if status.exists() and json.loads(status.read_text(encoding="utf-8")).get("status") == "running":
        raise RuntimeError("another experiment is running; dashboard left untouched")
    stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S%fZ")
    directory = _bounded(root, resume if resume else root / "runs/v6" / f"{phase}__{stamp}", output=True)
    if resume:
        prior = json.loads((directory / "manifest.json").read_text(encoding="utf-8"))
        if prior["protocol_hash"] != digest or prior["phase"] != phase or prior.get("cell_options") != options or prior.get("parent_report") != plan["parent_report"]:
            raise ValueError("resume protocol mismatch")
    deadline = time.monotonic() + config["wall_seconds"]
    plan["data_preflight"] = preflight_development(root, config, phase)
    _deadline(deadline)
    directory.mkdir(parents=True, exist_ok=resume is not None)
    (directory / "config_frozen.yaml").write_bytes(config_path.read_bytes())
    _json(directory / "manifest.json", {**plan, "status": "running", "test_accessed": False,
                                       "parent_report": str(parent_report) if parent_report else None})
    torch.set_num_threads(config["threads"])
    device = torch.device("cuda" if device_name == "auto" and torch.cuda.is_available() else "cpu" if device_name == "auto" else device_name)
    plan["runtime"] = {"device": str(device), "torch": torch.__version__, "numpy": np.__version__,
                       "cuda_build": torch.version.cuda, "threads": torch.get_num_threads(),
                       "deterministic_algorithms": torch.are_deterministic_algorithms_enabled()}
    rows = []
    # Fixed seed randomization of arm order, blocked by dataset; no multiple workers.
    order = list(options)
    random.Random(60908).shuffle(order)
    try:
        for dataset_id in config["datasets"]:
            _deadline(deadline)
            data = load_development(root / config["cache_root"] / f"{dataset_id}.npz", config)
            if development_hash(data) != plan["data_preflight"]["datasets"][dataset_id]["development_hash"]:
                raise ValueError(f"{dataset_id}: development cache changed after preflight")
            for seed in config["seeds"]:
                for cell in order:
                    arm = cell if phase == "mechanism" else "backbone_ce"
                    row = train_cell(data, config, options[cell], arm, seed,
                            directory / f"{dataset_id}__{cell}__{seed}", device, deadline, digest, resume is not None)
                    rows.append({**row, "cell": cell})
                    _json(directory / "partial.json", {"rows": rows, "test_accessed": False})
        report = {**plan, "status": "completed", "rows": rows, "test_accessed": False,
                  "selection_status": "provisional_micro_only", "automatic_followup": False,
                  "run_directory": str(directory)}
        if phase == "mechanism":
            report["decision"] = mechanism_decision(rows, config)
            report["selected_options"] = parent["selected_options"]
        else:
            choice = select_backbone(rows, config)
            report.update(selected_cell=choice, selected_options=options[choice])
            report["screen_health"] = screen_health(rows, choice)
            if phase == "factorial":
                report["factorial_effects"] = factorial_effects(rows)
        _json(directory / "report.json", report)
        _json(directory / "manifest.json", {**plan, "status": "completed", "test_accessed": False})
        return report
    except BaseException as error:
        _json(directory / "manifest.json", {**plan, "status": "bounded_stop" if isinstance(error, TimeoutError) else "failed",
              "error": repr(error), "test_accessed": False, "completed_cells": len(rows)})
        raise


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", default="configs/experiments/v6_validation_micro.yaml")
    parser.add_argument("--phase", choices=("factorial", "backbone_checks", "mechanism"), default="factorial")
    parser.add_argument("--execute", action="store_true", help="explicitly run bounded TRAIN/validation work")
    parser.add_argument("--preflight", action="store_true", help="check TRAIN/validation inputs only; no training or run directory")
    parser.add_argument("--parent-report", type=Path)
    parser.add_argument("--resume", type=Path)
    parser.add_argument("--device", choices=("auto", "cpu", "cuda"), default="auto")
    args = parser.parse_args()
    root = Path(__file__).resolve().parents[4]
    result = run(root, root / args.config, args.phase, execute=args.execute,
                 parent_report=args.parent_report, resume=args.resume, device_name=args.device,
                 preflight_only=args.preflight)
    print(json.dumps({k:v for k,v in result.items() if k != "rows"}, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
