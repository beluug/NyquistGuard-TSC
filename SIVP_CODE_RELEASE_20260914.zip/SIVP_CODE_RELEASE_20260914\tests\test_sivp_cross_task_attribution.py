from __future__ import annotations

from pathlib import Path
import time

import numpy as np
import pytest
import torch
import yaml

from nyquistguard.research.sivp_attribution_extension import data as extension_data
from nyquistguard.research.sivp_attribution_extension import runner


ROOT = Path(__file__).resolve().parents[1]
CONFIG = ROOT / "configs/experiments/sivp_cross_task_attribution_train_oof.yaml"


def _configuration() -> dict:
    return yaml.safe_load(CONFIG.read_text(encoding="utf-8"))


def _data(dataset_id: str, groups: list[str], labels: list[int]) -> extension_data.TrainOnlyData:
    count = len(labels)
    return extension_data.TrainOnlyData(
        dataset_id=dataset_id,
        rate=50.0,
        classes=("zero", "one"),
        train_x=np.zeros((count, 2, 100), dtype=np.float32),
        train_y=np.asarray(labels, dtype=np.int64),
        train_ids=np.asarray([f"record_{index}" for index in range(count)]),
        groups=np.asarray(groups),
    )


def test_default_call_is_a_no_data_plan(monkeypatch: pytest.MonkeyPatch):
    monkeypatch.setattr(
        runner,
        "_preflight",
        lambda *_: pytest.fail("default plan must not materialize any dataset"),
    )
    result = runner.run(ROOT, CONFIG)
    assert result["expected_cells"] == 22
    assert not result["execution_requested"]
    assert not result["validation_read"] and not result["test_read"]
    assert not result["hashes_recomputed"]


def test_frozen_config_rejects_posthoc_task_or_rate_change():
    config = _configuration()
    config["evaluation_rates"] = [0.9, 0.6, 0.4]
    with pytest.raises(ValueError, match="evaluation_rates"):
        runner.validate_config(config)

    config = _configuration()
    config["datasets"].pop("eegmmi_physionet")
    with pytest.raises(ValueError, match="dataset selection"):
        runner.validate_config(config)


def test_loader_materializes_train_members_with_poisoned_test_member(tmp_path: Path):
    labels = np.tile(np.arange(12, dtype=np.int64), 2)
    identifiers = np.asarray(
        [f"mHealth_subject{index % 6 + 1}:{index}:0" for index in range(len(labels))]
    )
    path = tmp_path / "mhealth.npz"
    np.savez(
        path,
        dataset_id=np.asarray("mhealth_uci"),
        sampling_rate_hz=np.asarray(50.0),
        class_names=np.asarray([f"class_{index}" for index in range(12)]),
        train_x=np.zeros((len(labels), 21, 100), dtype=np.float32),
        train_y=labels,
        train_ids=identifiers,
        # Loading this member with allow_pickle=False would raise. Successful
        # TRAIN loading therefore demonstrates that the TEST member stayed lazy.
        test_x=np.asarray([object()], dtype=object),
    )
    loaded = extension_data.load_train_only(path, "mhealth_uci", len(labels), 60914)
    assert loaded.train_x.shape == (24, 21, 100)
    assert len(set(loaded.groups.tolist())) == 6


def test_registered_oof_folds_are_subject_disjoint_and_cover_each_record_once():
    mhealth_groups = [f"mHealth_subject{subject}" for subject in range(1, 7) for _ in range(4)]
    mhealth_labels = [label for _ in range(6) for label in (0, 1, 0, 1)]
    mhealth = _data("mhealth_uci", mhealth_groups, mhealth_labels)
    mhealth_folds = extension_data.grouped_folds(mhealth, "leave_one_subject_out", 60929)
    assert len(mhealth_folds) == 6

    eeg_groups = [f"S{subject:03d}" for subject in range(1, 26) for _ in range(2)]
    eeg_labels = [label for _ in range(25) for label in (0, 1)]
    eeg = _data("eegmmi_physionet", eeg_groups, eeg_labels)
    eeg_folds = extension_data.grouped_folds(eeg, "stratified_group_5fold", 60929)
    assert len(eeg_folds) == 5

    for current, folds in ((mhealth, mhealth_folds), (eeg, eeg_folds)):
        held = np.concatenate([indices for _, indices, _ in folds])
        assert sorted(held.tolist()) == list(range(len(current.train_y)))
        for fit, test, _ in folds:
            assert set(current.groups[fit]) .isdisjoint(set(current.groups[test]))


class _CountingModel(torch.nn.Module):
    num_classes = 2

    def __init__(self):
        super().__init__()
        self.calls = 0

    def forward(self, values: torch.Tensor, rate: float) -> dict[str, torch.Tensor]:
        self.calls += 1
        score = values.mean(dim=(1, 2))
        return {"logits": torch.stack((score, -score), dim=1)}


def test_fixed_reference_is_evaluated_once_per_batch_not_once_per_ratio():
    model = _CountingModel()
    values = np.random.default_rng(7).normal(size=(5, 2, 100)).astype(np.float32)
    labels = np.asarray([0, 1, 0, 1, 0], dtype=np.int64)
    config = _configuration()
    conditions, layout = runner._evaluate_fixed_reference(
        model,
        values,
        labels,
        50.0,
        tuple(config["evaluation_rates"]),
        2,
        torch.device("cpu"),
        time.monotonic() + 30,
        config,
    )
    # Each of three batches uses one high reference plus seven views at four ratios.
    assert model.calls == 3 * (1 + 7 * 4)
    assert len(conditions["high_reference"]["predictions"]) == len(labels)
    assert len(conditions) == 1 + 7 * 4
    assert layout.dense_length == 51


def test_one_update_paired_smoke_has_finite_gradients_and_identical_schedule(tmp_path: Path):
    config = _configuration()
    config.update(updates=1, batch_size=4, wall_seconds=120, threads=2)
    config["model"] = {
        "hidden_dim": 8,
        "num_bands": 4,
        "spatial_channels": 4,
        "pooled_positions": 8,
        "depth": 1,
        "dropout": 0.0,
    }
    config["gates"] = {"maximum_parameter_gap": 0.5}
    generator = np.random.default_rng(13)
    data = extension_data.TrainOnlyData(
        dataset_id="mhealth_uci",
        rate=50.0,
        classes=("zero", "one"),
        train_x=generator.normal(size=(24, 2, 100)).astype(np.float32),
        train_y=np.tile(np.asarray([0, 1], dtype=np.int64), 12),
        train_ids=np.asarray([f"id_{index}" for index in range(24)]),
        groups=np.asarray([f"group_{index // 4}" for index in range(24)]),
    )
    partition = (np.arange(20), np.arange(20, 24), "smoke")
    seed = 77
    template = runner.make_model(data, config, runner.OPTIONS, seed)
    initial_state = {
        name: value.detach().cpu().clone() for name, value in template.state_dict().items()
    }
    results = [
        runner._train_cell(
            data,
            0,
            partition,
            arm,
            config,
            tmp_path / arm,
            torch.device("cpu"),
            time.monotonic() + 120,
            seed,
            initial_state,
        )
        for arm in runner.ARMS
    ]
    assert results[0]["schedule"] == results[1]["schedule"]
    assert all(result["status"] == "completed" for result in results)
    assert all(np.isfinite(result["history"][0]["total"]) for result in results)
    assert all(len(result["conditions"]) == 29 for result in results)
