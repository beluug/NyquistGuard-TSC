"""Factorial-screen backbone. Standard components, NOT the V6 novelty claim."""
from __future__ import annotations

import torch
from torch import Tensor, nn
import torch.nn.functional as F

from nyquistguard.models.nyquist_gate import NyquistObservabilityGate
from nyquistguard.models.physical_filterbank import PhysicalGaborFilterBank, normalize_sampling_rates, validate_padding_mask
from nyquistguard.models.temporal_encoder import TemporalEncoder, NormalizedPhysicalTimePool, _group_count


class Summary(nn.Module):
    def __init__(self, hidden: int, rich: bool, dropout: float):
        super().__init__()
        self.rich = rich
        self.projection = nn.Sequential(nn.Linear(hidden * (3 if rich else 1), hidden), nn.SiLU(),
                                        nn.Dropout(dropout), nn.LayerNorm(hidden))

    def forward(self, x: Tensor) -> Tensor:
        mean = x.mean(-1)
        values = torch.cat((mean, (x - mean[..., None]).square().mean(-1).clamp_min(1e-8).sqrt(), x.amax(-1)), -1) if self.rich else mean
        return self.projection(values)


class V6Backbone(nn.Module):
    """Stable forward(x, sampling_rate_hz, padding_mask=None, timestamps=None).

    The four factorial cells all start with signed path and residual gate.
    OPDT never changes this model's forward or inference parameter count.
    """
    def __init__(self, input_channels: int, num_classes: int, *, source_rate_hz: float,
                 summary: str = "mean", fusion: str = "fixed", signed: bool = True,
                 gate: str = "residual", frontend: str = "physical", hidden_dim: int = 64,
                 num_bands: int = 16, spatial_channels: int = 24, pooled_positions: int = 32,
                 depth: int = 3, dropout: float = 0.05):
        super().__init__()
        if summary not in {"mean", "rich"} or fusion not in {"fixed", "adaptive"} or gate not in {"residual", "hard", "none"} or frontend not in {"physical", "ordinary"}:
            raise ValueError("invalid backbone option")
        if input_channels < 1 or num_classes < 2 or source_rate_hz <= 0:
            raise ValueError("invalid dimensions/rate")
        if frontend == "ordinary" and gate != "none":
            raise ValueError("ordinary frontend has no physical gate")
        self.input_channels, self.num_classes = input_channels, num_classes
        self.frontend, self.signed, self.gate_mode, self.fusion_mode = frontend, signed, gate, fusion
        self.source_rate_hz, self.hidden_dim = source_rate_hz, hidden_dim
        if frontend == "physical":
            self.filterbank = PhysicalGaborFilterBank(input_channels, num_bands,
                min_center_hz=min(0.2, source_rate_hz * 0.01), max_center_hz=source_rate_hz * 0.45,
                min_sigma_seconds=0.015, max_sigma_seconds=0.50, max_kernel_seconds=1.)
            self.gate = NyquistObservabilityGate()
        else:
            self.filterbank = nn.Conv1d(input_channels, num_bands, 31, padding=15, bias=False)
        if gate == "residual":
            self.raw_floor = nn.Parameter(torch.zeros(num_bands))
        self.time_pool = NormalizedPhysicalTimePool(pooled_positions)
        self.encoder = TemporalEncoder(num_bands, hidden_dim, depth, dropout=dropout)
        self.physical_summary = Summary(hidden_dim, summary == "rich", dropout)
        if signed:
            self.spatial_projection = nn.Sequential(nn.Conv1d(input_channels, spatial_channels, 1, bias=False),
                nn.GroupNorm(_group_count(spatial_channels), spatial_channels), nn.SiLU())
            self.spatial_encoder = TemporalEncoder(spatial_channels, hidden_dim, depth, dropout=dropout)
            self.spatial_summary = Summary(hidden_dim, summary == "rich", dropout)
        if fusion == "adaptive" and signed:
            self.controller = nn.Sequential(nn.Linear(3, max(8, hidden_dim // 4)), nn.SiLU(), nn.Linear(max(8, hidden_dim // 4), 1))
            self.cross_residual = nn.Sequential(nn.Linear(2 * hidden_dim, hidden_dim), nn.SiLU(), nn.Dropout(dropout), nn.Linear(hidden_dim, hidden_dim))
            for layer in (self.controller[-1], self.cross_residual[-1]):
                nn.init.zeros_(layer.weight)
                nn.init.zeros_(layer.bias)
        self.fusion_norm = nn.LayerNorm(hidden_dim)
        self.classifier = nn.Linear(hidden_dim, num_classes)

    def _one_length(self, x: Tensor, rates: Tensor, times: Tensor | None) -> dict:
        mask = torch.zeros(x.shape[0], x.shape[-1], dtype=torch.bool, device=x.device)
        if times is not None:
            expected = 1 / rates[:, None]
            if not torch.isfinite(times).all() or torch.any(torch.abs(times.diff(dim=-1) - expected) > expected * 0.05):
                raise ValueError("V6 student supports uniform timestamps consistent with fs")
        if self.frontend == "physical":
            bands = self.filterbank(x, rates, mask)
            analytic = self.gate(rates, self.filterbank.center_frequencies_hz,
                                 self.filterbank.time_scales_seconds, batch_size=x.shape[0])
        else:
            bands = self.filterbank(x)
            analytic = x.new_ones(x.shape[0], bands.shape[1])
        gate = analytic if self.gate_mode == "hard" else torch.ones_like(analytic)
        if self.gate_mode == "residual":
            floor = self.raw_floor.sigmoid()[None]
            gate = floor + (1 - floor) * analytic
        features = self.time_pool(bands, mask, times)
        encoded, _ = self.encoder(features * gate[..., None])
        physical = self.physical_summary(encoded)
        weight = physical.new_ones((x.shape[0], 1))
        if self.signed:
            centered = x - x.mean(-1, keepdim=True)
            standardized = centered * (centered.square().mean(-1, keepdim=True) + 1e-5).rsqrt()
            spatial = self.time_pool(self.spatial_projection(standardized), mask, times)
            sequence, _ = self.spatial_encoder(spatial)
            signed = self.spatial_summary(sequence)
            if self.fusion_mode == "adaptive":
                descriptor_gate = analytic if self.gate_mode != "none" else torch.ones_like(analytic)
                descriptors = torch.stack((torch.log2(rates / 100.).clamp(-4, 4), descriptor_gate.mean(1), descriptor_gate.amin(1)), 1)
                weight = self.controller(descriptors.to(physical.dtype)).sigmoid()
                combined = weight * physical + (1 - weight) * signed + self.cross_residual(torch.cat((physical, signed), 1))
            else:
                weight = torch.full_like(weight, 0.5)
                combined = (physical + signed) * 0.5
        else:
            combined = physical
        embedding = self.fusion_norm(combined)
        logits = self.classifier(embedding)
        return {"logits": logits, "embedding": embedding, "band_features": features,
                "nyquist_gate": analytic, "effective_gate_multiplier": gate,
                "fusion_physical_weight": weight[:, 0],
                "accept_probability": logits.float().softmax(-1).amax(-1)}

    def forward(self, x: Tensor, sampling_rate_hz: float | Tensor,
                padding_mask: Tensor | None = None, timestamps: Tensor | None = None) -> dict:
        if x.ndim != 3 or x.shape[1] != self.input_channels or not x.is_floating_point() or x.shape[-1] < 1:
            raise ValueError("x must be floating [B,C,T>=1]")
        rates = normalize_sampling_rates(sampling_rate_hz, x.shape[0], device=x.device)
        mask = validate_padding_mask(x, padding_mask)
        if not torch.isfinite(x.masked_fill(mask[:, None], 0.)).all():
            raise ValueError("valid input must be finite")
        if timestamps is not None and (timestamps.shape != mask.shape or not timestamps.is_floating_point()):
            raise ValueError("timestamps must be floating [B,T]")
        # Crop BEFORE GroupNorm. Masking values alone does not remove padding's
        # contribution to GroupNorm's temporal moments.
        lengths = (~mask).sum(1)
        pieces, indices = [], []
        for length in lengths.unique(sorted=True):
            idx = torch.where(lengths == length)[0]
            n = int(length)
            pieces.append(self._one_length(x[idx, :, :n], rates[idx], None if timestamps is None else timestamps[idx, :n].to(x.device)))
            indices.append(idx)
        order = torch.cat(indices).argsort()
        output = {key: torch.cat([p[key] for p in pieces], 0)[order] for key in pieces[0]}
        output["aux"] = {"sampling_rate_hz": rates, "valid_lengths": lengths,
                         "v6_backbone_only": True, "opdt_changes_forward": False}
        return output


def parameter_count(model: nn.Module) -> int:
    return sum(p.numel() for p in model.parameters() if p.requires_grad)


def matched_ordinary_backbone(reference: V6Backbone, **options) -> tuple[V6Backbone, dict]:
    """Match ACTIVE trainable parameters by deterministic width search, no dummies."""
    target = parameter_count(reference)
    best, gap = None, float("inf")
    for width in range(8, 129):
        candidate = V6Backbone(reference.input_channels, reference.num_classes,
            source_rate_hz=reference.source_rate_hz, frontend="ordinary", gate="none", hidden_dim=width, **options)
        error = abs(parameter_count(candidate) - target)
        if error < gap:
            best, gap = candidate, error
    return best, {"target": target, "actual": parameter_count(best), "relative_gap": gap / target,
                  "hidden_dim": best.hidden_dim, "dummy_parameters": 0}
